Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices


<Assembly: AssemblyVersion("7.9.0000.0")> 
<Assembly: AssemblyFileVersion("7.9.4300.0000")> 

