using SuperOffice.Configuration;
using SuperOffice.CRM.Data;
using SuperOffice.CRM.Globalization;
using SuperOffice.CRM.Rows;
using SuperOffice.Data;
using SuperOffice.Data.Dictionary;
using SuperOffice.Security.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace SuperOffice.CRM.Documents
{
    #region "Utility & Helper methods"

    /// <summary>
    /// Helper class containing utility methods (e.g to retrieve data from ForeignKey Table)
    /// </summary>
    public class SoArc2Helper
    {

        //Plugin device id
        private int _docPluginDeviceId;
        //Table id of Document table
        private short _docTableId;

        public int DocPluginDeviceId
        {
            get { return _docPluginDeviceId; }
        }

        /// <summary>
        /// Constructor of the helper class. This will populate the PluginDeviceId property
        /// </summary>
        /// <returns></returns>
        public SoArc2Helper(string foreignAppName)
        {
            _docPluginDeviceId = GetFkDeviceIdForPlugin(foreignAppName);

            //Set the table id of document table
            DocumentTableInfo docTableInfo = TablesInfo.GetDocumentTableInfo();
            SoDictionary dictionary = SoDatabase.GetCurrent().Dictionary;
            _docTableId = Convert.ToInt16(dictionary[docTableInfo.TableName].TableNumber);
        }

        /// <summary>
        /// Path to the main document archive.
        /// </summary>
        /// <returns>"\\server\so_arc"</returns>
        public string GetArchivePath()
        {
            return ConfigFile.Documents.ArchivePath;
        }

        /// <summary>
        /// Path to the document archives, including the main document archive.
        /// </summary>
        /// <returns>("\\server\so_arc", "\\other\so_arc2")</returns>
        public string[] GetArchivePaths()
        {
            return ConfigFile.Documents.AllArchivePaths;
        }

        /// <summary>
        /// This method will return the physical location of the given document based on the provided IDocumentInfo.
        /// </summary>
        /// <param name="documentInfo">DocumentInfo object containing the document information </param>
        /// <param name="versionId"></param>
        /// <returns>Full Archive Path</returns>
        public string GetFullArchivePath(IDocumentInfo documentInfo, string versionId)
        {
            string archivePath; // this is the path of the document identified by the above documentId and versionId
            string currentDocumentFolder;
                // this is the folder name of the current version of the document identified by documentId 

            currentDocumentFolder = GetCurrentVersionFolderPath(documentInfo);

            if (string.IsNullOrEmpty(versionId))
            {
                archivePath = Path.Combine(currentDocumentFolder, documentInfo.Name);
            }
            else
            {
                archivePath = GetVersionHistoryFolderPath(documentInfo, string.Empty);
                string versionFileName = this.GetVersionFileName(documentInfo.Name, versionId);
                archivePath = Path.Combine(archivePath, versionFileName);
            }

            // normalize the filename
            archivePath = new FileInfo(archivePath).FullName;
            return archivePath;
        }

        /// <summary>
        /// This method will return the physical location of the given document based on the provided IDocumentInfo.
        /// </summary>
        /// <param name="documentRow">DocumentRow object containing the document information </param>
        /// <param name="versionId"></param>
        /// <returns>Full Archive Path</returns>
        public string GetFullArchivePath(DocumentRow documentRow, string versionId)
        {
            string archivePath; // this is the path of the document identified by the above documentId and versionId
            string currentDocumentFolder;
                // this is the folder name of the current version of the document identified by documentId 

            currentDocumentFolder = GetCurrentVersionFolderPath(documentRow);

            if (string.IsNullOrEmpty(versionId))
            {
                archivePath = Path.Combine(currentDocumentFolder, documentRow.Name);
                ;
            }
            else
            {
                archivePath = GetVersionHistoryFolderPath(documentRow, string.Empty);
                string versionFileName = this.GetVersionFileName(documentRow.Name, versionId);
                archivePath = Path.Combine(archivePath, versionFileName);
            }

            using (new DocumentArchiveFileImpersonationContext())
            {
                // normalize the filename
                archivePath = new FileInfo(archivePath).FullName;
            }
            return archivePath;

        }

        /// <summary>
        /// Verify that a directory exists, and if not, create all missing folders
        /// </summary>
        /// <param name="dirInfo"></param>
        public static void EnsureDirectoryExists(System.IO.DirectoryInfo dirInfo)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (dirInfo.Parent != null)
                    EnsureDirectoryExists(dirInfo.Parent);
                if (!dirInfo.Exists)
                    dirInfo.Create();
            }
        }


        /// <summary>
        /// This will get a unique file name in the given path.
        /// </summary>
        /// <remarks>
        /// this will ensure to return an unique file name for the given location If it finds a file(s)
        /// with the same name it will create a filename with a suffix with a proper index.
        /// e.g It'll create Test[2].docx (if it finds the Test.docx &amp; Test[1].docx in the requested location
        /// </remarks>
        /// <param name="completeFilePath">Complete file path including the file name</param>
        /// <returns>A string to a unique filename with no path which is guaranteed not to exist in the path provided.</returns>
        public static string GetUniqueFileName(string completeFilePath)
        {
            string uniquePath = GetUniqueFilePath(completeFilePath);
            string uniqueName = Path.GetFileName(uniquePath);
            return uniqueName;
        }

        /// <summary>
        /// This will get a unique file name and path in the given path.
        /// </summary>
        /// <remarks>
        /// this will ensure to return an unique file name for the given location If it finds a file(s)
        /// with the same name it will create a filename with a suffix with a proper index.
        /// e.g It'll create Test[2].docx (if it finds the Test.docx &amp; Test[1].docx in the requested location
        /// </remarks>
        /// <param name="completeFilePath">Complete file path including the file name</param>
        /// <returns>A string to a complete filename and path which is guaranteed not to exist.</returns>
        public static string GetUniqueFilePath(string completeFilePath)
        {
            int ifile = 1;
            string uniqueName = string.Empty;

            string fileNameTemplate = Path.GetFileNameWithoutExtension(completeFilePath) + "[{0}]" +
                                      Path.GetExtension(completeFilePath);
            string directoryPath = Path.GetDirectoryName(completeFilePath);

            string filename = Path.GetFileName(completeFilePath);

            using (new DocumentArchiveFileImpersonationContext())
            {
                while (string.IsNullOrEmpty(uniqueName))
                {
                    if (File.Exists(Path.Combine(directoryPath, filename)))
                    {
                        if (ifile > 0)
                        {
                            filename = string.Format(fileNameTemplate, ifile);
                            ifile++;
                        }
                    }
                    else
                    {
                        filename = Path.Combine(directoryPath, filename);
                        break;
                    }

                }
            }
            return filename;
        }

        /// <summary>
        /// Given a suggested file name (typically derived from a document.header), and make it legal;
        /// create directories on the way
        /// </summary>
        /// <param name="suggestedFullPathWithExtension"></param>
        /// <returns></returns>
        public static string MakeLegalFileNameAndDirectory(string suggestedFullPathWithExtension)
        {
            string fileName = Path.GetFileName(suggestedFullPathWithExtension);
            string fileDirectoryPath = Path.GetDirectoryName(suggestedFullPathWithExtension);

            char[] invalidChars = Path.GetInvalidFileNameChars();
            string invalidString = Regex.Escape(new string(invalidChars));
            fileName = Regex.Replace(fileName, "[" + invalidString + "]", string.Empty);

            //Generate the document full path
            string suggestedFullPath = Path.Combine(fileDirectoryPath, fileName);

            // Check whether the expected file directory is existed, if not create.
            EnsureDirectoryExists(new DirectoryInfo(fileDirectoryPath));

            return suggestedFullPath;
        }

        /// <summary>
        /// This method will return the correctly formatted file name of a particular version of a file.
        /// </summary>
        /// <param name="fileName">Orginal file name</param>
        /// <param name="versionId">version Id to be added to the name as a postfix</param>
        /// <returns>The file name of the particular version</returns> 
        public string GetVersionFileName(string fileName, string versionId)
        {
            versionId = versionId.PadLeft(3, '0');

            return Path.GetFileNameWithoutExtension(fileName) + "-" + versionId + Path.GetExtension(fileName);


        }

        /// <summary>
        /// This method will return the ForeignKeyDevice Id from the ForeignDeviceTable which corresponds to the specific ForeignAppName.
		/// If the foreignapp/foreigndevice rows do not exist, they will be created.
        /// </summary>
        /// <param name="ForeignAppName">ForeignApp Name given in ForeignApp Table</param>
        /// <returns>returns the foreignDevice Id from the ForeignDevice Table</returns>
        public int GetFkDeviceIdForPlugin(string foreignAppName)
        {
			var appId = S.NewSelect<ForeignAppTableInfo>(t => t.Name.Equal(foreignAppName)).
				Records(t => t.ForeignappId).
				Select(r => r.Table.ForeignappId[r]).
				FirstOrDefault();
			if (appId == 0)
			{
				var appRow = ForeignAppRow.CreateNew();
				appRow.Name = foreignAppName;
				appRow.Save();
				appId = appRow.ForeignappId;
			}

			var devId = S.NewSelect<ForeignDeviceTableInfo>(t => t.ForeignappId.Equal(appId)).
				Records(t => t.ForeigndeviceId).
				Select(r => r.Table.ForeigndeviceId[r]).
				FirstOrDefault();
			if (devId == 0)
			{
				var devRow = ForeignDeviceRow.CreateNew();
				devRow.Name = foreignAppName;	// nothing better to put here
				devRow.ForeignappId = appId;
				devRow.Save();
				devId = devRow.ForeigndeviceId;
			}

			return devId;
        }

        /// <summary>
        /// Retrievs the version information for a given version.
        /// </summary>
        /// <remarks>
        /// This will return the foreing key rows for the requested document &amp; requested version
        /// </remarks>
        /// <param name="DocumentId">Document Id</param>
        /// <param name="VersionId">Version Id of the Document</param>
        /// <returns>ForeignKeyRows Object containing all the foreing key raws for the requested document</returns>
        public ForeignKeyRows GetForeignKeyVersionInfo(int documentId, string versionId)
        {
            if (versionId.Equals(string.Empty))
            {
                versionId = "0";
            }

            string versionPrefix = versionId.PadLeft(3, '0');

            ForeignKeyRows.CustomSearch searchSql = new ForeignKeyRows.CustomSearch();

            searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                             .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                             .And(searchSql.TableInfo.RecordId.Equal(S.Parameter(documentId)))
                                             .And(searchSql.TableInfo.Subkey.Like(S.Parameter(versionPrefix + ".%")))
                                             .And(
                                                 searchSql.TableInfo.Subkey.NotLike(
                                                     S.Parameter("%" + DocumentInfoKeys.CheckOutState)))
                                             .And(
                                                 searchSql.TableInfo.Subkey.NotLike(
                                                     S.Parameter("%" + DocumentInfoKeys.CheckOutByAssociateId)))
                                             .And(
                                                 searchSql.TableInfo.Subkey.NotLike(
                                                     S.Parameter("%" + DocumentInfoKeys.NumVersions)));

            ForeignKeyRows rows = searchSql.ToForeignKeyRows();

            return rows;
        }

        /// <summary>
        /// Retrievs the document level foreignkey rows for a given document.
        /// </summary>            
        /// <param name="DocumentId">Document Id</param>           
        /// <returns>ForeignKeyRows Object containing all the foreing key raws for the requested document</returns>
        public ForeignKeyRows GetForeignKeyDocumentInfo(int documentId)
        {
            ForeignKeyRows.CustomSearch searchSql = new ForeignKeyRows.CustomSearch();

            searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                             .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                             .And(searchSql.TableInfo.RecordId.Equal(S.Parameter(documentId)))
                                             .And(searchSql.TableInfo.Subkey.Like(S.Parameter("000.%")));

            ForeignKeyRows rows = searchSql.ToForeignKeyRows();
            return rows;
        }

        /// <summary>
        /// Get the value for a plugin-level key from ForeignKey table.
        /// </summary>
        /// <param name="key">Plugin-Level Key</param>
        /// <returns>Plugin-Level Value</returns>
        public string GetPluginCapability(string key)
        {
            ForeignKeyRow.CustomSearch searchSql = new ForeignKeyRow.CustomSearch();

            searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                             .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                             .And(searchSql.TableInfo.Subkey.Equal(S.Parameter(key)));

            ForeignKeyRow row = searchSql.ToForeignKeyRow();
            return row.Subvalue;
        }

        /// <summary>
        /// Get the associate name for a given associate id
        /// </summary>
        /// <param name="associateId">Associate Id</param>
        /// <returns>Associate Name</returns>
        public string GetAssociateName(int associateId)
        {
            AssociateTableInfo associate = TablesInfo.GetAssociateTableInfo();

            PersonRows.CustomSearch searchSql = new PersonRows.CustomSearch();
            searchSql.JoinRestriction.InnerJoin(associate.PersonId.Equal(searchSql.TableInfo.PersonId));
            searchSql.Restriction = associate.AssociateId.Equal(S.Parameter(associateId));
            PersonRow row = searchSql.ToPersonRow();
            return row.Firstname + " " + row.Lastname;
        }

        /// <summary>
        /// Get the value for a document-level key from ForeignKey table.
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="docLevelKey">Document-Level Key</param>
        /// <returns>Document-Level Value</returns>
        public string GetDocumentLevelProperty(int documentId, string docLevelKey)
        {
            ForeignKeyRow.CustomSearch searchSql = new ForeignKeyRow.CustomSearch();

            searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                             .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                             .And(searchSql.TableInfo.RecordId.Equal(S.Parameter(documentId)))
                                             .And(searchSql.TableInfo.Subkey.Equal(S.Parameter("000." + docLevelKey)));

            ForeignKeyRow row = searchSql.ToForeignKeyRow();
            return row.Subvalue;
        }

        /// <summary>
        /// Get the checked out associate id for a given document
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <returns>Checked out Associate Id</returns>
        public int GetCheckOutAssociateId(int documentId)
        {
            string checkOutAssociateId = GetDocumentLevelProperty(documentId, DocumentInfoKeys.CheckOutByAssociateId);
            try
            {
                return Convert.ToInt32(checkOutAssociateId);
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// Check whether locking is supported for a given document. 
        /// </summary>
        /// <remarks>
        /// Here, both plugin level and document level locking is considered.
        /// </remarks>
        /// <param name="documentId">Document Id</param>
        /// <param name="pluginLocking">Plugin level locking</param>
        /// <returns>Locking status</returns>
        public bool IsLockingSupported(int documentId, string pluginLocking)
        {
            if (pluginLocking == Constants.Values.False)
            {
                return false;
            }
            else if (pluginLocking == Constants.Values.Mandatory)
            {
                return true;
            }
            else if (pluginLocking == Constants.Values.Optional)
            {
                //Get the document level locking status
                DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentId);
                if (docRow.LockSemantics == DocumentLockSemantics.None)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                //If the locking key is not in DB, pluginLocking = ""
                return false;
            }
        }

        /// <summary>
        /// Check whether versioning is supported for a given document. 
        /// </summary>
        /// <remarks>
        /// Here, both plugin level and document level versioning is considered.
        /// </remarks>
        /// <param name="documentId">Document Id</param>
        /// <param name="pluginLocking">Plugin level versioning</param>
        /// <returns>Versioning status</returns>
        public bool IsVersioningSupported(int documentId, string pluginVersioning)
        {
            if (pluginVersioning == Constants.Values.False)
            {
                return false;
            }
            else if (pluginVersioning == Constants.Values.Mandatory)
            {
                return true;
            }
            else if (pluginVersioning == Constants.Values.Optional)
            {
                //Get the document level versioning status
                DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentId);
                if (docRow.LockSemantics == DocumentLockSemantics.Versioning)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                //If the versioning key is not in DB, pluginVersioning = ""
                return false;
            }
        }

        /// <summary>
        /// Get the no. of versions for a given document
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <returns>No. of versions</returns>
        public int GetNumberOfVersions(int documentId)
        {
            string versions = GetDocumentLevelProperty(documentId, DocumentInfoKeys.NumVersions);
            try
            {
                return Convert.ToInt32(versions);
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// Get a VersionInfo array. 
        /// </summary>
        /// <remarks>
        /// Here, information of all the versions and current document (0 th version) are included.
        /// </remarks>
        /// <param name="documentId">Document Id</param>
        /// <returns>VersionInfo Array</returns>
        public VersionInfo[] GetVersions(int documentId)
        {
            int noOfVersions = GetNumberOfVersions(documentId);

            ForeignKeyRows.CustomSearch searchSql = new ForeignKeyRows.CustomSearch();

            //Get all the foreignKey records related to a particular document
            searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                             .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                             .And(searchSql.TableInfo.RecordId.Equal(S.Parameter(documentId)));

            ForeignKeyRows rows = searchSql.ToForeignKeyRows();
            VersionInfo[] versionInfoArray = new VersionInfo[noOfVersions + 1];

            for (int versionNo = 0; versionNo <= noOfVersions; versionNo++)
            {
                //Add VersionInfo objects to VersionInfoArray
                VersionInfo versionInfo = new VersionInfo();
                versionInfoArray[versionNo] = versionInfo;
                versionInfo.DocumentId = documentId;
                versionInfo.VersionId = "0";
            }

            return FillVersionInfoArray(rows, versionInfoArray, documentId);
        }

        /// <summary>
        /// Fill version information
        /// <remarks>            
        /// This is a efficient way of extracting row level values into a VersionInfo array.
        /// Here row collection is looped through for only one cycle.
        /// </remarks>
        /// </summary>
        /// <param name="rows">all the foreignKey rows related to a particular document</param>
        /// <param name="versionInfoArray">Array of VersionInfo objects </param>
        /// <param name="documentId">Document Id</param>
        /// <returns>Filled VersionInfo Array</returns>
        private VersionInfo[] FillVersionInfoArray(ForeignKeyRows rows, VersionInfo[] versionInfoArray, int documentId)
        {
            foreach (ForeignKeyRow row in rows)
            {
                int versionNo = GetVersionNumber(row, VersionInfoKeys.CheckInByAssociateId);
                if (versionNo != -1)
                {
                    versionInfoArray[versionNo].CheckedInByAssociateId = Convert.ToInt32(row.Subvalue);
                    //Can set VersionId and CheckedInAssociateName in this branch                       
                    versionInfoArray[versionNo].VersionId = versionNo.ToString();
                    versionInfoArray[versionNo].CheckedInByName
                        = GetAssociateName(versionInfoArray[versionNo].CheckedInByAssociateId);
                    continue;
                }

                versionNo = GetVersionNumber(row, VersionInfoKeys.CheckInDate);
                if (versionNo != -1)
                {
                    versionInfoArray[versionNo].CheckedInDate = CultureDataFormatter.ParseEncodedDate(row.Subvalue);
                    continue;
                }

                versionNo = GetVersionNumber(row, VersionInfoKeys.Description);
                if (versionNo != -1)
                {
                    versionInfoArray[versionNo].Description = row.Subvalue;
                    continue;
                }

                versionNo = GetVersionNumber(row, VersionInfoKeys.DisplayText);
                if (versionNo != -1)
                {
                    versionInfoArray[versionNo].DisplayText = row.Subvalue;
                    continue;
                }

                versionNo = GetVersionNumber(row, VersionInfoKeys.ExtraFields);
                if (versionNo != -1)
                {
                    versionInfoArray[versionNo].ExtraFields = GetStringArrayFromString(row.Subvalue);
                    continue;
                }
            }
            return versionInfoArray;
        }

        /// <summary>
        /// Extract the version id from a subkey
        /// </summary>
        /// <param name="row">ForeignKey row</param>
        /// <param name="key">Subkey</param>
        /// <returns>Version Id</returns>
        private int GetVersionNumber(ForeignKeyRow row, string key)
        {
            string rowKey = row.Subkey.Substring(4);
            if (rowKey == key)
            {
                int versionNo;
                bool result = Int32.TryParse(row.Subkey.Substring(0, 3), out versionNo);

                if (result)
                {
                    return versionNo;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }

        /// <summary>
        /// Set checkout state to false when undo checkout
        /// </summary>
        /// <param name="documentId">Document id</param>
        private void ResetDocumentLevelInfo(int documentId)
        {
            ForeignKeyRows.CustomSearch searchSql = new ForeignKeyRows.CustomSearch();

            searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                             .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                             .And(searchSql.TableInfo.RecordId.Equal(S.Parameter(documentId)))
                                             .And(searchSql.TableInfo.Subkey.Equal(
                                                 S.Parameter("000." + DocumentInfoKeys.CheckOutState))
                                                           .Or(
                                                               searchSql.TableInfo.Subkey.Equal(
                                                                   S.Parameter("000." +
                                                                               DocumentInfoKeys.CheckOutByAssociateId))
                                                      ));

            ForeignKeyRows rows = ForeignKeyRows.GetFromCustomSearch(searchSql);
            foreach (ForeignKeyRow row in rows)
            {
                string subkeyWithoutVersion = row.Subkey.Substring(row.Subkey.IndexOf('.') + 1);
                switch (subkeyWithoutVersion)
                {
                    case DocumentInfoKeys.CheckOutState:
                        row.Subvalue = Constants.Values.False;
                        break;
                    case DocumentInfoKeys.CheckOutByAssociateId:
                        row.Subvalue = "0";
                        break;
                    default:
                        break;
                }
            }
            rows.Save();
        }

        /// <summary>
        /// Delete the temparory file, when undo checkout
        /// </summary>
        /// <param name="documentId">Document Id</param>
        private void DeleteTempDocument(int documentId)
        {
            string fileName = GetTempFilePath(documentId);
            using (new DocumentArchiveFileImpersonationContext())
            {
                File.Delete(fileName);
            }
        }

        /// <summary>
        /// Delete temparory document and reset database changes, when undo checkout
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="externalReference">External Reference</param>
        /// <returns>ReturnInfo</returns>
        public ReturnInfo UndoCheckout(int documentId, string externalReference)
        {
            bool success;
            string message = string.Empty;
            try
            {
                DeleteTempDocument(documentId);
                ResetDocumentLevelInfo(documentId);
                success = true;
            }
            catch (FileNotFoundException)
            {
                success = false;
                message = "Temparary file not found";
            }
            return CreateReturnInfo(success, externalReference, string.Empty, ReturnType.None, message, String.Empty);
        }

        /// <summary>
        /// Create a ReturnInfo object
        /// </summary>
        /// <param name="success">success/failure status</param>
        /// <param name="externalReference">External Reference</param>
        /// <param name="versionId">Version Id</param>
        /// <param name="type">Return type</param>
        /// <param name="value">Return value</param>
        /// <param name="additionalInfo">Additional Info</param>
        /// <returns>ReturnInfo</returns>
        public ReturnInfo CreateReturnInfo(bool success, string externalReference, string versionId,
                                           ReturnType type, string value, string additionalInfo)
        {
            ReturnInfo returnInfo = new ReturnInfo();
            returnInfo.Success = success;
            returnInfo.ExternalReference = externalReference;
            returnInfo.VersionId = versionId;
            returnInfo.Type = type;
            returnInfo.Value = value;
            returnInfo.AdditionalInfo = additionalInfo;
            return returnInfo;
        }

        /// <summary>
        /// Create a CheckoutInfo object
        /// </summary>
        /// <param name="associateId">Associate Id</param>
        /// <param name="name">Associate Name</param>
        /// <param name="state">Checkout State</param>
        /// <returns>CheckoutInfo</returns>
        public CheckoutInfo CreateCheckoutInfo(int associateId, string name, CheckoutState state)
        {
            CheckoutInfo checkoutInfo = new CheckoutInfo();
            checkoutInfo.AssociateId = associateId;
            checkoutInfo.Name = name;
            checkoutInfo.State = state;
            return checkoutInfo;
        }

        /// <summary>
        /// This is a generalized, efficient way of getting one value from string array
        /// having keyvalue pairs
        /// </summary>
        /// <param name="keyValueArray">Original keyvalue array</param>
        /// <param name="key">key</param>
        /// <returns>value</returns>
        public string GetOneValueFromKeyValueArray(string[] keyValueArray, string key)
        {
            string value = string.Empty;

            foreach (string keyValue in keyValueArray)
            {
                string[] splittedkeyValue = SplitKeyValue(keyValue);

                if (splittedkeyValue[0] == key)
                {
                    value = splittedkeyValue[1];
                    break;
                }
            }
            return value;
        }

        /// <summary>
        /// Create a dictionary from Key=Value string array
        /// </summary>
        /// <param name="keyValueArray">Key=Value string array</param>
        /// <returns>Dictionary</returns>
        public Dictionary<string, string> CreateKeyValueDictionary(string[] keyValueArray)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            foreach (string keyValue in keyValueArray)
            {
                string[] splittedkeyValue = SplitKeyValue(keyValue);
                dictionary.Add(splittedkeyValue[0], splittedkeyValue[1]);
            }

            return dictionary;
        }

        /// <summary>
        /// Load document information.            
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <returns>Array of key=value pairs</returns>
        public string[] LoadDocumentInfo(int documentId)
        {
            ArrayList documentData = new ArrayList();

            //Get all document-level key/value rows
            ForeignKeyRows rows = GetForeignKeyDocumentInfo(documentId);

            foreach (ForeignKeyRow row in rows)
            {
                string subkeyWithoutVersion = row.Subkey.Substring(row.Subkey.IndexOf('.') + 1);

                if (CheckWhetherAValidKey(subkeyWithoutVersion))
                    documentData.Add(String.Format("{0}={1}", subkeyWithoutVersion, row.Subvalue));
                else
                    continue;
            }
            string[] docDataArr = (string[]) documentData.ToArray();
            return docDataArr;
        }

        /// <summary>
        /// Save or update document level information
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="documentData">key value pairs</param>
        public void SaveDocumentInfo(int documentId, string[] documentData)
        {
            ForeignKeyRows rows = GetForeignKeyDocumentInfo(documentId);

            if (rows.Count == 0)
            {
                //This is the first time of saving this document's information
                SaveInitialDocumentInfo(documentId, documentData, rows);
            }
            else
            {
                //Data already exists; therefore update the values
                Dictionary<string, string> docDictionary = new Dictionary<string, string>();
                foreach (string data in documentData)
                {
                    string[] keyvalueArray = SplitKeyValue(data);
                    docDictionary.Add(keyvalueArray[0], keyvalueArray[1]);
                }

                UpdateDocumentInfo(documentId, docDictionary, rows);
            }

            rows.Save();
        }

        /// <summary>
        /// Save document level keys for a particular document for the first time
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="documentData">key value pairs</param>
        /// <param name="rows">row colection (zero length)</param>
        public void SaveInitialDocumentInfo(int documentId, string[] documentData, ForeignKeyRows rows)
        {
            foreach (string data in documentData)
            {
                string[] keyvalueArray = SplitKeyValue(data);

                if (keyvalueArray.Length == 2)
                {
                    if (CheckWhetherAValidKey(keyvalueArray[0]))
                        AddDataRow(documentId, "000." + keyvalueArray[0], keyvalueArray[1], rows);
                    else
                        continue;
                }
            }
        }

        public bool CheckWhetherAValidKey(string key)
        {
            switch (key)
            {
                case DocumentInfoKeys.CheckOutState:
                case DocumentInfoKeys.CheckOutByAssociateId:
                case DocumentInfoKeys.NumVersions:

                case Constants.Properties.FileType:
                case Constants.Properties.HasLocking:
                case Constants.Properties.HasVersioning:
                case Constants.Properties.PreferredOpen:
                case Constants.Properties.Tooltip:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Update document level values.
        /// If a particular key is not there in row collection, that key will not be updated although it is in the dictionary.
        /// This kind of situation can only be happened, if all the document level keys were not saved in initial saving.
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="docDictionary">key value dictionary</param>
        /// <param name="rows">row collection retrieved</param>
        public void UpdateDocumentInfo(int documentId, Dictionary<string, string> docDictionary, ForeignKeyRows rows)
        {
            foreach (ForeignKeyRow row in rows)
            {
                //Remove version prefix (eg. '001.')
                string SubkeyWithoutVersion = row.Subkey.Substring(row.Subkey.IndexOf('.') + 1);

                switch (SubkeyWithoutVersion)
                {
                    case DocumentInfoKeys.CheckOutState:
                        if (docDictionary.ContainsKey(DocumentInfoKeys.CheckOutState))
                            row.Subvalue = docDictionary[DocumentInfoKeys.CheckOutState];
                        break;
                    case DocumentInfoKeys.CheckOutByAssociateId:
                        if (docDictionary.ContainsKey(DocumentInfoKeys.CheckOutByAssociateId))
                            row.Subvalue = docDictionary[DocumentInfoKeys.CheckOutByAssociateId];
                        break;
                    case DocumentInfoKeys.NumVersions:
                        if (docDictionary.ContainsKey(DocumentInfoKeys.NumVersions))
                            row.Subvalue = docDictionary[DocumentInfoKeys.NumVersions];
                        break;
                    case Constants.Properties.FileType:
                        if (docDictionary.ContainsKey(Constants.Properties.FileType))
                            row.Subvalue = docDictionary[Constants.Properties.FileType];
                        break;
                    case Constants.Properties.HasLocking:
                        if (docDictionary.ContainsKey(Constants.Properties.HasLocking))
                            row.Subvalue = docDictionary[Constants.Properties.HasLocking];
                        break;
                    case Constants.Properties.HasVersioning:
                        if (docDictionary.ContainsKey(Constants.Properties.HasVersioning))
                            row.Subvalue = docDictionary[Constants.Properties.HasVersioning];
                        break;
                    case Constants.Properties.PreferredOpen:
                        if (docDictionary.ContainsKey(Constants.Properties.PreferredOpen))
                            row.Subvalue = docDictionary[Constants.Properties.PreferredOpen];
                        break;
                    case Constants.Properties.Tooltip:
                        if (docDictionary.ContainsKey(Constants.Properties.Tooltip))
                            row.Subvalue = docDictionary[Constants.Properties.Tooltip];
                        break;
                    default:
                        break;
                }
            }
        }


        /// <summary>
        /// Obtain a DocumentInfo object through the generic SuperOffice factory system
        /// </summary>
        /// <param name="documentId"></param>
        /// <returns></returns>
        public IDocumentInfo GetDocumentInfoFromId(int documentId)
        {
            return SuperOffice.Factory.ClassFactory.Create<IDocumentInfo>(documentId);
        }


        /// <summary>
        /// Get the Document row of the given documentId
        /// </summary>
        /// <param name="documentId">document Id</param>
        /// <returns>document Row of the given id</returns>
        public DocumentRow GetDocumentRowFromId(int documentId)
        {
            return DocumentRow.GetFromIdxDocumentId(documentId);
        }


        /// <summary>
        /// Adding data row to row collection
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="key">key</param>
        /// <param name="value">value</param>
        /// <param name="rows">row collection</param>
        public void AddDataRow(int documentId, string key, string value, ForeignKeyRows rows)
        {
            ForeignKeyRow row = ForeignKeyRow.CreateNew();
            row.ForeigndeviceId = _docPluginDeviceId;
            row.TableId = _docTableId;
            row.RecordId = documentId;
            row.Subkey = key;
            row.Subvalue = value;
            rows.Add(row);
        }

        /// <summary>
        /// Split keys &amp; values
        /// </summary>
        /// <param name="keyValue">original string</param>
        /// <returns>string[0] = key, string[1] = value</returns>
        private string[] SplitKeyValue(string keyValue)
        {
            if ((keyValue != null) && (keyValue != string.Empty))
                return keyValue.Split('=');
            else
                return new string[0];
        }

        /// <summary>
        /// This is the folder path where the latest document is in 
        /// </summary>
        /// <param name="documentInfo">document id/name/heading</param>
        /// <returns>\\server\so_arc\user\1999.1</returns>
        public string GetCurrentVersionFolderPath(IDocumentInfo documentInfo)
        {
            string currentDocumentFolder = "";

            string subFolder = documentInfo.Registered.Year.ToString();
            if (documentInfo.Registered.Month <= 7)
                subFolder += ".1";
            else
                subFolder += ".2";

            // impersonate since we are checking if document exists
            using (new DocumentArchiveFileImpersonationContext())
            {
                foreach (string archivePath in GetArchivePaths())
                {
                    currentDocumentFolder = archivePath;
                    currentDocumentFolder = Path.Combine(currentDocumentFolder, documentInfo.AssociateLoginName);
                    currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);
                    string docPath = Path.Combine(currentDocumentFolder, documentInfo.Name);
                    if (File.Exists(docPath))
                        return currentDocumentFolder;
                }
            }

            // if no paths match, then create new files in the main SOARC folder
            currentDocumentFolder = GetArchivePath();
            currentDocumentFolder = Path.Combine(currentDocumentFolder, documentInfo.AssociateLoginName);
            currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);

            return currentDocumentFolder;
        }

        /// <summary>
        /// This is the folder path where the latest document is located.
        /// </summary>
        /// <param name="documentRow">document id, name, heading etc</param>
        /// <returns>\\server\so_arc\user\1999.2</returns>
        public string GetCurrentVersionFolderPath(DocumentRow documentRow)
        {
            AssociateRow associateRow = AssociateRow.GetFromIdxAssociateId(documentRow.RegisteredAssociateId);

            string currentDocumentFolder = "";

            string subFolder = documentRow.Registered.Year.ToString();
            if (documentRow.Registered.Month <= 7)
                subFolder += ".1";
            else
                subFolder += ".2";

            // impersonate since we are checking if document exists
            using (new DocumentArchiveFileImpersonationContext())
            {
                foreach (string archivePath in GetArchivePaths())
                {
                    currentDocumentFolder = archivePath;
                    currentDocumentFolder = Path.Combine(currentDocumentFolder, associateRow.Name);
                    currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);
                    string docPath = Path.Combine(currentDocumentFolder, documentRow.Name);
                    if (File.Exists(docPath))
                        return currentDocumentFolder;
                }
            }
            // if no paths match, then create new files in the main SOARC folder
            currentDocumentFolder = GetArchivePath();
            currentDocumentFolder = Path.Combine(currentDocumentFolder, associateRow.Name);
            currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);

            return currentDocumentFolder;
        }

        /// <summary>
        /// Get the file path of temparory file used for check out
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <returns>file path: \\server\so_arc\1999.1\filename\filename.doc</returns>
        public string GetTempFilePath(int documentId)
        {
            DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentId);

            string tempFilePath = Path.Combine(GetCurrentVersionFolderPath(docRow),
                                               Path.GetFileNameWithoutExtension(docRow.Name));
            return Path.Combine(tempFilePath, Path.GetFileName(docRow.Name));
        }

        /// <summary>
        /// Create (if not created already) and get the version history folder.
        /// </summary>
        /// <param name="documentInfo">DocumentInfo</param>
        /// <param name="newFileName">New File Name</param>
        /// <returns>Version History Folder Path</returns>
        public string GetVersionHistoryFolderPath(IDocumentInfo documentInfo, string newFileName)
        {
            string historyFolderPath = Path.Combine(GetCurrentVersionFolderPath(documentInfo),
                                                    newFileName != string.Empty
                                                        ? Path.GetFileNameWithoutExtension(newFileName)
                                                        : Path.GetFileNameWithoutExtension(documentInfo.Name));

            using (new DocumentArchiveFileImpersonationContext())
            {
                if (!Directory.Exists(historyFolderPath))
                    Directory.CreateDirectory(historyFolderPath);
            }

            return historyFolderPath;
        }

        /// <summary>
        /// Create (if not created already) and get the version history folder.
        /// </summary>
        /// <param name="documentRow">DocumentRow</param>
        /// <param name="newFileName">New File Name</param>
        /// <returns>Version History Folder Path</returns>
        internal string GetVersionHistoryFolderPath(DocumentRow documentRow, string newFileName)
        {
            string historyFolderPath = Path.Combine(GetCurrentVersionFolderPath(documentRow),
                                                    newFileName != ""
                                                        ? Path.GetFileNameWithoutExtension(newFileName)
                                                        : Path.GetFileNameWithoutExtension(documentRow.Name));

            using (new DocumentArchiveFileImpersonationContext())
            {
                if (!Directory.Exists(historyFolderPath))
                    Directory.CreateDirectory(historyFolderPath);
            }

            return historyFolderPath;
        }

        /// <summary>
        /// Delete data from ForeignKey table and all physical files( i.e. including previous versions as well)
        /// </summary>
        /// <param name="documentID">Document Id</param>
        /// <returns>returns whether </returns>
        public bool DeleteDocumentData(int documentId)
        {
            try
            {
                DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentId);

                //Delete data from ForeignKey Table
                ForeignKeyRows.CustomSearch searchSql = new ForeignKeyRows.CustomSearch();
                searchSql.Restriction = searchSql.TableInfo.ForeigndeviceId.Equal(S.Parameter(_docPluginDeviceId))
                                                 .And(searchSql.TableInfo.TableId.Equal(S.Parameter(_docTableId)))
                                                 .And(searchSql.TableInfo.RecordId.Equal(S.Parameter(documentId)));

                ForeignKeyRows rows = searchSql.ToForeignKeyRows();
                rows.Delete();

                //Delete root file
                string currentFolderPath = GetCurrentVersionFolderPath(docRow);
                string filePath = Path.Combine(currentFolderPath, docRow.Name);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    if (File.Exists(filePath))
                    {
                        File.SetAttributes(filePath, FileAttributes.Normal);
                        File.Delete(filePath);
                    }

                    //Delete history folder
                    string fileName = string.Empty;
                    string versionFolder = GetVersionHistoryFolderPath(docRow, fileName);
                    if (Directory.Exists(versionFolder))
                    {
                        string[] files = Directory.GetFiles(versionFolder);

                        if (files.Length > 0)
                        {
                            for (int i = 0; i < files.Length; i++)
                            {
                                File.SetAttributes(files[i], FileAttributes.Normal);
                            }
                        }

                        Directory.Delete(versionFolder, true);
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }


        /// <summary>
        /// This method will return a VersionInfo object based on the paramaters given
        /// </summary>
        /// <param name="documentId">document Id</param>
        /// <param name="versionId">version Id</param>
        /// <param name="checkedInAssociateId">CheckedIn Associate Id</param>
        /// <param name="checkedInByName">CheckedIn Associate Name</param>
        /// <param name="versionDescription">version Description</param>
        /// <param name="checkedInDate">Checked in DateTime </param>
        /// <param name="displayText"> Display Text</param>
        /// <param name="externalRef">External Reference</param>
        /// <param name="extraFields">Extra fields</param>
        /// <returns>Populated VersionInfo object</returns>
        internal VersionInfo CreateVersionInfo(int documentId, string versionId, int checkedInAssociateId,
                                               string checkedInByName, string versionDescription, DateTime checkedInDate,
                                               string displayText, string externalRef, string[] extraFields)
        {
            VersionInfo verInfo = new VersionInfo();
            verInfo.DocumentId = documentId;
            verInfo.VersionId = versionId;
            verInfo.CheckedInByAssociateId = checkedInAssociateId;
            verInfo.CheckedInByName = checkedInByName;
            verInfo.Description = versionDescription;
            verInfo.CheckedInDate = checkedInDate;
            verInfo.DisplayText = displayText;
            verInfo.ExternalReference = externalRef;
            verInfo.ExtraFields = extraFields;
            return verInfo;
        }

        /// <summary>
        /// This method will return a VersionInfo object which is filled with the parameters 
        /// and data retrieved from the data base
        /// </summary>
        /// <param name="versionId">version Id</param>
        /// <param name="documentId">document Id</param>
        /// <param name="externalRef">external Reference</param>
        /// <returns>Return the VersionInfo Object filled with the given data</returns>
        internal VersionInfo CreateVersionInfo(int documentId, string externalRef, string versionId)
        {
            VersionInfo versionInfo = new VersionInfo();
            string description = string.Empty;
            string checkedInAssociateName = string.Empty;
            string displayText = string.Empty;
            string[] extraFields = new string[] {};
            int checkedInAssocaiteId = 0;
            DateTime checkedInDateTime = DateTime.MinValue;

            ForeignKeyRows rows = GetForeignKeyVersionInfo(documentId, versionId);

            if (rows.Count > 0)
            {
                foreach (ForeignKeyRow row in rows)
                {
                    string SubkeyWithoutVersion = row.Subkey.Substring(row.Subkey.IndexOf('.') + 1);

                    switch (SubkeyWithoutVersion)
                    {
                        case VersionInfoKeys.Description:
                            description = row.Subvalue;
                            break;
                        case VersionInfoKeys.CheckInByAssociateId:
                            checkedInAssocaiteId = Convert.ToInt32(row.Subvalue);
                            checkedInAssociateName = GetAssociateName(checkedInAssocaiteId);
                            break;
                        case VersionInfoKeys.CheckInDate:
                            checkedInDateTime = CultureDataFormatter.ParseEncodedDate(row.Subvalue);
                            break;
                        case VersionInfoKeys.DisplayText:
                            displayText = row.Subvalue;
                            break;
                        case VersionInfoKeys.ExtraFields:
                            extraFields = GetStringArrayFromString(row.Subvalue);
                            break;
                        default:
                            break;
                    }
                }

                versionInfo = CreateVersionInfo(documentId, versionId, checkedInAssocaiteId, checkedInAssociateName,
                                                description, checkedInDateTime, displayText, externalRef, extraFields);
            }
            else
            {
                versionInfo = null;
            }

            return versionInfo;
        }


        /// <summary>
        /// This method will manage the physical document in the CheckIn command.
        /// i.e. make the correct file visible and set file attributes
        /// </summary>
        /// <param name="documentId">Document Id</param>
        /// <param name="isVersionable">value to determine whether this document support versioning</param>
        /// <param name="numVersions">number of versions of the document in the database</param>
        /// <returns>returns the new version number 
        /// ( this will be 0 if this document does not support versioning or this is a newly created file checkin) </returns> 
        internal int SetDocumentsOnCheckin(int documentId, bool isVersionable, int numVersions)
        {
            DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentId);
            string documentName = docRow.Name;

            string documentRootPath = GetCurrentVersionFolderPath(docRow);
            string documentHistoryFolderPath = GetVersionHistoryFolderPath(docRow, string.Empty);
            string tempCurrentDocumentFullPath = Path.Combine(documentRootPath,
                                                              String.Concat(
                                                                  Path.GetFileNameWithoutExtension(documentName),
                                                                  "_temp", Path.GetExtension(documentName)));

            int nextVersion = 0;

            using (new DocumentArchiveFileImpersonationContext())
            {
                try
                {
                    if (isVersionable && (numVersions != -1))
                        //Document is not a new one & has checked in before at least one time.
                    {
                        //copy the latest version into a temp file.
                        File.Copy(Path.Combine(documentRootPath, documentName), tempCurrentDocumentFullPath, true);
                    }

                    // Set the edited file(read only) to be writable before moving to root folder
                    string tempFilePath = Path.Combine(documentHistoryFolderPath, documentName);
                    File.SetAttributes(tempFilePath, FileAttributes.Normal);

                    // Set the checked out file(read only) to be writable before replaced by the checking in version
                    string rootFilePath = Path.Combine(documentRootPath, documentName);
                    File.SetAttributes(rootFilePath, FileAttributes.Normal);

                    // Move the document being edited as the latest version. 
                    // This will replace the existing current version if there is one already exists(which was copied into a temp file).
                    File.Copy(Path.Combine(documentHistoryFolderPath, documentName),
                              Path.Combine(documentRootPath, documentName), true);
                    File.Delete(Path.Combine(documentHistoryFolderPath, documentName));

                    if (isVersionable && (numVersions != -1))
                        //Document is not a new one & has checked in before at least one time.
                    {
                        // Increment the version number by one & copy the previously latest file as the version file into the version history table
                        nextVersion = numVersions + 1;
                        string nextVersionDocumentName = GetVersionFileName(documentName, nextVersion.ToString());

                        File.Move(tempCurrentDocumentFullPath,
                                  Path.Combine(documentHistoryFolderPath, nextVersionDocumentName));
                    }

                    // Set the checked in file to be readonly
                    FileAttributes CurrentAtts = File.GetAttributes(Path.Combine(documentRootPath, documentName));
                    File.SetAttributes(Path.Combine(documentRootPath, documentName),
                                       CurrentAtts | FileAttributes.ReadOnly);

                }
                catch (Exception ex)
                {
                    throw new Exception("Error occured at creating the physical checked in version of the document", ex);
                }
            }
            return nextVersion;
        }


        /// <summary>
        /// This method will update or add the version information to the database
        /// </summary>
        /// <param name="versionInfo">version information to be saved to the database</param>
        internal void SaveVersionInfo(VersionInfo versionInfo)
        {
            //keep a dictionary to track the rows returned by the database 
            //this will be used to add any missing fields of VersionInfo object
            Dictionary<string, bool> versionInfoKeyValues = new Dictionary<string, bool>();
            versionInfoKeyValues.Add(VersionInfoKeys.CheckInByAssociateId, false);
            versionInfoKeyValues.Add(VersionInfoKeys.CheckInDate, false);
            versionInfoKeyValues.Add(VersionInfoKeys.Description, false);
            versionInfoKeyValues.Add(VersionInfoKeys.DisplayText, false);
            versionInfoKeyValues.Add(VersionInfoKeys.ExtraFields, false);

            // Get version information rows from database if already exists
            ForeignKeyRows rows = GetForeignKeyVersionInfo(versionInfo.DocumentId, versionInfo.VersionId);

            if (rows.Count > 0)
            {
                //Data already exists; therefore update the values and keep a track of what is received in the dictionary
                foreach (ForeignKeyRow row in rows)
                {
                    string SubkeyWithoutVersion = row.Subkey.Substring(row.Subkey.IndexOf('.') + 1);

                    switch (SubkeyWithoutVersion)
                    {
                        case VersionInfoKeys.Description:
                            row.Subvalue = versionInfo.Description;
                            versionInfoKeyValues[VersionInfoKeys.Description] = true;
                            break;
                        case VersionInfoKeys.CheckInByAssociateId:
                            row.Subvalue = versionInfo.CheckedInByAssociateId.ToString();
                            versionInfoKeyValues[VersionInfoKeys.CheckInByAssociateId] = true;
                            break;
                        case VersionInfoKeys.CheckInDate:
                            row.Subvalue =
                                SuperOffice.CRM.Globalization.CultureDataFormatter.EncodeDateTime(
                                    versionInfo.CheckedInDate);
                            versionInfoKeyValues[VersionInfoKeys.CheckInDate] = true;
                            break;
                        case VersionInfoKeys.DisplayText:
                            row.Subvalue = versionInfo.DisplayText;
                            versionInfoKeyValues[VersionInfoKeys.DisplayText] = true;
                            break;
                        case VersionInfoKeys.ExtraFields:
                            row.Subvalue = GetStringFromStringArray(versionInfo.ExtraFields);
                            versionInfoKeyValues[VersionInfoKeys.ExtraFields] = true;
                            break;
                        default:
                            break;
                    }
                }
            }

            //Check the dictionary for missing values in the rows collection and add them
            if (versionInfoKeyValues.ContainsValue(false))
            {
                if (versionInfoKeyValues[VersionInfoKeys.Description] == false)
                {
                    AddDataRow(versionInfo.DocumentId,
                               versionInfo.VersionId.PadLeft(3, '0') + "." + VersionInfoKeys.Description,
                               versionInfo.Description, rows);
                }

                if (versionInfoKeyValues[VersionInfoKeys.CheckInByAssociateId] == false)
                {
                    AddDataRow(versionInfo.DocumentId,
                               versionInfo.VersionId.PadLeft(3, '0') + "." + VersionInfoKeys.CheckInByAssociateId,
                               versionInfo.CheckedInByAssociateId.ToString(), rows);
                }

                if (versionInfoKeyValues[VersionInfoKeys.CheckInDate] == false)
                {
                    AddDataRow(versionInfo.DocumentId,
                               versionInfo.VersionId.PadLeft(3, '0') + "." + VersionInfoKeys.CheckInDate,
                               CultureDataFormatter.EncodeDateTime(versionInfo.CheckedInDate), rows);
                }

                if (versionInfoKeyValues[VersionInfoKeys.DisplayText] == false)
                {
                    AddDataRow(versionInfo.DocumentId,
                               versionInfo.VersionId.PadLeft(3, '0') + "." + VersionInfoKeys.DisplayText,
                               versionInfo.DisplayText, rows);
                }

                if (versionInfoKeyValues[VersionInfoKeys.ExtraFields] == false)
                {
                    AddDataRow(versionInfo.DocumentId,
                               versionInfo.VersionId.PadLeft(3, '0') + "." + VersionInfoKeys.ExtraFields,
                               GetStringFromStringArray(versionInfo.ExtraFields), rows);
                }
            }

            rows.Save();
        }

        /// <summary>
        /// This method will handle the physical document movements required in the Checkout command
        /// </summary>
        /// <param name="documentId"></param>
        internal void SetDocumentsOnCheckout(int documentId)
        {
            DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentId);

            string sourceFile = GetFullArchivePath(docRow, string.Empty);
            string destinationFile = Path.Combine(GetVersionHistoryFolderPath(docRow, string.Empty), docRow.Name);

            using (new DocumentArchiveFileImpersonationContext())
            {
                // create a temporary document for editing
                File.Copy(sourceFile, destinationFile, true);
                //Set the temp file to be editable
                File.SetAttributes(destinationFile, FileAttributes.Normal);
                // Set the file to be readonly as it's checked out by the called user
                FileAttributes CurrentAtts = File.GetAttributes(sourceFile);
                File.SetAttributes(sourceFile, CurrentAtts | FileAttributes.ReadOnly);
            }
        }


        /// <summary>
        /// This method will return a string created by the values in the array
        /// return string will be in the format of value1&amp;value2&amp;... 
        /// </summary>
        /// <param name="extraFields">string array</param>
        /// <returns>The formatted string </returns>
        internal string GetStringFromStringArray(string[] stringArray)
        {
            StringBuilder arrayAsString = new StringBuilder(string.Empty);
            for (int i = 0; i <= stringArray.Length - 1; i++)
            {
                arrayAsString.Append(stringArray[i]).Append("&");
            }
            if (arrayAsString.Length > 0)
            {
                arrayAsString.Remove(arrayAsString.Length - 1, 1); // removing the last '&' added
            }

            return arrayAsString.ToString();
        }


        /// <summary>
        /// This method will return a string array from the received string where the values are seperated by &amp;
        /// </summary>
        /// <param name="arrayAsString">string with values seperated by &amp;</param>
        /// <returns>a string array . if the string is blank a blank array will be returned</returns>
        internal string[] GetStringArrayFromString(string arrayAsString)
        {
            string[] array = new string[0];
            if (!string.IsNullOrEmpty(arrayAsString))
            {
                if (arrayAsString.Contains("&"))
                {
                    array = arrayAsString.Split('&');
                }
            }

            return array;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentTemplateId"></param>
        /// <param name="languageCode"></param>
        /// <returns></returns>
        internal string GetDocumentTemplatePath(IDocumentTemplateInfo templateInfo, string languageCode,
                                                bool checkIfFileExists, string filenamePadding = "")
        {
            if (templateInfo != null) // normal templates
            {
                string templateName = templateInfo.ExternalReference;

                // Avoid padding + padding + padding + padding etc...
                // Avoid changing filename if we have a languageCode.
                if (!string.IsNullOrEmpty(filenamePadding)
                    && !templateInfo.ExternalReference.StartsWith(filenamePadding)
                    && string.IsNullOrEmpty(languageCode))
                {
                    templateName = filenamePadding + templateInfo.ExternalReference;
                }

                string soLang = CultureDataFormatter.MapCultureToSuperOfficeLanguage(languageCode);

                string filePath;

                // try the UI language SOARC\TEMPLATE\CZ\ folder
                if (!string.IsNullOrEmpty(languageCode) && !string.IsNullOrEmpty(soLang))
                {
                    filePath = Path.Combine(Path.Combine(ConfigFile.Documents.TemplatePath, soLang), templateName);
                }
                else
                {
                    filePath = Path.Combine(ConfigFile.Documents.TemplatePath, templateName);
                }

                if (!checkIfFileExists || File.Exists(filePath))
                    return filePath;
            }

            return null;

        }



        /// <summary>
        /// Contains the document level key names as constant values  
        /// </summary>
        public static class DocumentInfoKeys
        {
            public const string CheckOutState = "check-out-state";
            public const string CheckOutByAssociateId = "check-out-by-associate-id";
            public const string CheckOutByAssociateName = "check-out-by-associate-name";
            public const string NumVersions = "num-versions";
        }

        /// <summary>
        /// Contains the version level key names as constant values  
        /// </summary>
        public static class VersionInfoKeys
        {
            //public const string VersionNumber = "VersionNumber";

            public const string CheckInByAssociateId = "check-in-by-associate-id";
            public const string CheckInByAssociateName = "check-in-by-associate-name";
            public const string CheckInDate = "check-in-date";
            public const string Description = "description";

            public const string DisplayText = "display-text";
            public const string ExtraFields = "extra-fields";
        }

        #endregion
    }
}
