using SuperOffice.CRM.Globalization;
using SuperOffice.Configuration;
using SuperOffice.CRM.Rows;
using SuperOffice.Data;
using SuperOffice.Diagnostics;
using SuperOffice.Exceptions;
using SuperOffice.Security.Util;
using System;
using System.Collections;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;


namespace SuperOffice.CRM.Documents
{
    /// <summary>
	/// Document plugin for SuperOffice standard document archive (i.e SO_ARC) with Check-in/Check-out &amp; versioning features.
	/// </summary>
    [DocumentPlugin2("SO Archive", 0)]
    public class SoArc2 : IDocumentPlugin2
    {
        #region plugin level data, keys etc

		// this name must be kept in sync between:
		//  - Server\Source\SoDataBase\CRM\Documents\SoArc2.cs (declaration at top of class)
		//  - Clients\SM.win\Source\DbSetup\DbToSevenFiveUpgrader.cpp SDbToSevenFiveUpgrader::FixDocPluginForeignKeys
        private const string SOARC2_APP_NAME = "SOARC2";

        // Jens & Jostein: Only used for buffer when accessing file on file storage - change to default size
        //private const int PREFERRED_BUFFER_SIZE = 2;

        //SoArc2 Helper class providing the utility methods
        SoArc2Helper _helper;

        //variables to hold plugin level capabilities
        private string _locking;
        private string _fastLockStatus;
        private string _versioning;
        private string _fastVersionList;
        private string _fastExists;
        private int _maxDocumentSize;
        private int _timeout;
        private bool _customCommand;

        public string Locking
        {
            get { return _locking; }
        }

        public string FastLockStatus
        {
            get { return _fastLockStatus; }
        }
        
        public string Versioning
        {
            get { return _versioning; }
        }

        public string FastVersionList
        {
            get { return _fastVersionList; }
        }

        public string FastExists
        {
            get { return _fastExists; }
        }

        public int MaxDocumentSize
        {
            get { return _maxDocumentSize; }
        }

        public int Timeout
        {
            get { return _timeout; }
        }
        
        #endregion



        #region Plugin initialization & lifetime management etc.

        /// <summary>
        /// Create the document plugin. Check configuration to see if the TestCommand should be enabled?
        /// </summary>
        /// <param name="config">configuration settings</param>
        public SoArc2(IConfiguration config)
        {
            this.Initialize();
            _customCommand = config.GetConfigBool("SuperOffice/Documents/TestCommand");
        }
        
        private void Initialize()
        {
            //Initialize the helper
            _helper = new SoArc2Helper(SOARC2_APP_NAME);

            //Populate plugin level properties
            PopulatePluginProperties();
        }

        private void PopulatePluginProperties()
        {                
            _locking = _helper.GetPluginCapability(Constants.Capabilities.Locking);
            _fastLockStatus = _helper.GetPluginCapability(Constants.Capabilities.FastLockStatus);
            _versioning = _helper.GetPluginCapability(Constants.Capabilities.Versioning);
            _fastVersionList = _helper.GetPluginCapability(Constants.Capabilities.FastVersionList);
            _fastExists = _helper.GetPluginCapability(Constants.Capabilities.FastExists);

            //If DB does not have the key, result value is a blank string
            if (_helper.GetPluginCapability(Constants.Capabilities.MaxDocumentSize) != string.Empty )
                _maxDocumentSize = Convert.ToInt32(_helper.GetPluginCapability(Constants.Capabilities.MaxDocumentSize));
            if (_helper.GetPluginCapability(Constants.Capabilities.Timeout) != string.Empty)
                _timeout = Convert.ToInt32(_helper.GetPluginCapability(Constants.Capabilities.Timeout));           
        }


        #endregion


        #region Capabilities, properties, metadata and custom commands


        /// <summary>
        /// Get a list of capabilities (functionality) supported by this document plugin
        /// </summary>
        /// <remarks>
        /// The purpose of this call is to enable NetServer and clients to determine what functionality this plugin can offer. 
        /// Plugins should populate the return array with all capabilities they know about. NetServer will call this API only once.
        /// <para/>
        /// As an example of use, the Document archive provider inside NetServer will look at plugin capabilities, 
        /// and read document properties as appropriate. i.e. if �fast-lock-status=false�, then the archive provider 
        /// will not call the IsCheckedOut(externalReference) function. Otherwise it will make the call (if the client has requested
        /// the appropriate column in the GUI), so that the user can see which documents are checked out.
        /// <para/>
        /// String constants for capabilities are available in the <see cref="SuperOffice.CRM.Documents.Constants.Capabilities"/> static class.
        /// </remarks>
        /// <returns>Array of name=value strings listing all known capabilities and their values</returns>
        public Dictionary<string, string> GetPluginCapabilities()
        {
            var result = new Dictionary<string, string>(7);

            //locking
            result[ Constants.Capabilities.Locking ] = _locking;
            //fast-lock-status
            result[Constants.Capabilities.FastLockStatus] = _fastLockStatus;
            //versioning
            result[ Constants.Capabilities.Versioning ] = _versioning;
            //fast-version-list
            result[ Constants.Capabilities.FastVersionList] = _fastVersionList;
            //fast-exists
            result[ Constants.Capabilities.FastExists ] = _fastExists;
            //max-document-size
            result[ Constants.Capabilities.MaxDocumentSize ] = _maxDocumentSize.ToString();
            //timeout
            result[ Constants.Capabilities.Timeout ] = _timeout.ToString();

            return result;
        }

        /// <summary>
        /// Get the values of certain properties, for a given document
        /// </summary>
        /// <remarks>
        /// Each document can have a number of properties associated with it. A set of standard properties
        /// is defined in the <see cref="SuperOffice.CRM.Documents.Constants.Properties"/> class. Ideally, retrieving properties should
        /// be a lightweight operation.
        /// <para/>
        /// Note that 'properties' are a one-way mechanism where the document plugin provides information about
        /// the document or certain aspects of it. This is not the same as document-specific
        /// metadata, which is handled by the <see cref="LoadMetaData"/> and <see cref="SaveMetaData"/>
        /// methods.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="requestedProperties">Array of property strings, for which values are requested</param>
        /// <returns>Array of name=value pairs, where the name is one of the requested property strings, and the value
        /// is the value of that property for the given document.</returns>
        public Dictionary<string, string> GetDocumentProperties(IDocumentInfo documentInfo, string[] requestedProperties)
        {
            var result = new Dictionary<string,string>(requestedProperties.Length);
            int documentId = documentInfo.DocumentId;

            foreach (string documentProperty in requestedProperties)
            {
                string value = string.Empty;
                switch (documentProperty)
                {
                    case Constants.Properties.HasLocking:
                        value = _helper.GetDocumentLevelProperty(documentId, Constants.Properties.HasLocking);
                        break;
                    case Constants.Properties.HasVersioning:
                        value = _helper.GetDocumentLevelProperty(documentId, Constants.Properties.HasVersioning);
                        break;
                    case Constants.Properties.FileType:
                        DocumentRow document = new DocumentRow.IdxDocumentId(documentId);
                        value = document.Name.Substring(document.Name.LastIndexOf('.') + 1);
                        break;
                    case Constants.Properties.PreferredOpen:
                        value = Constants.Values.Stream;
                        break;
                    case Constants.Properties.LastModified:
                        DocumentRow documentRow = new DocumentRow.IdxDocumentId(documentId);
                        string archivePath = _helper.GetFullArchivePath( documentRow, "");
                        if( File.Exists( archivePath ) )
                        {
                            DateTime lastModified = File.GetLastWriteTimeUtc( archivePath );
                            value = SuperOffice.CRM.Globalization.CultureDataFormatter.EncodeDateTime( lastModified );
                        }
                        break;
                    default:
                        break;
                }
                result[documentProperty] = value;
            }
         
            return result;
        }


        /// <summary>
        /// Get a list of custom commands, applicable to a specific document. Note that commands related to
        /// standard locking and versioning operations have their own API calls and are not 'custom commands' in this sense.
        /// </summary>
        /// <remarks>
        /// This API is called before a menu, task button or other GUI item that gives access to document-specific commands is shown.
        /// It is used to populate the GUI with available commands for a particular document, the results are not cached by the GUI.
        /// <para/>
        /// Depending on the return type indicated in the command, the command might be filtered by GUI. More information can
        /// be found in the <see cref="CommandInfo"/> topic.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Array of command descriptions. If there are no custom commands available, an empty array should be returned.</returns>
        public CommandInfo[] GetDocumentCommands(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            if ( _customCommand )
            {
                CommandInfo cmd1 = new CommandInfo() { DisplayName = "Test URL", DisplayTooltip = "This is the tooltip", Name = "TEST-URL", ReturnType = ReturnType.URL };
                CommandInfo cmd2 = new CommandInfo() { DisplayName = "Test SO Protocol", DisplayTooltip = "[SR_QUOTE_SETTINGS_TOOLTIPRES_TOOLTIP]", Name = "TEST-SO", ReturnType = ReturnType.SoProtocol };
                CommandInfo cmd3 = new CommandInfo() { DisplayName = "Test Message", DisplayTooltip = "This is the message", Name = "TEST-MSG", ReturnType = ReturnType.Message };
                return new CommandInfo[3] { cmd1, cmd2, cmd3 };
            }
            return new CommandInfo[0];
        }


        /// <summary>
        /// Execute a custom command on a specified document and version
        /// </summary>
        /// <remarks>
        /// This command is called when the user chooses an action item from a dropdown/context menu. 
        /// It is also reflected in the DocumentAgent service interface, so that custom GUI�s and external 
        /// code can directly execute document plugin commands; this is useful if a plugin also has some 
        /// corresponding custom GUI that needs to execute commands depending on user interaction.
        /// <para/>
        /// The parameter <see cref="allowedReturnTypes"/> can be used by clients to hint to the plugin
        /// what kind of return value processing is available. For instance, a mobile client might
        /// only offer None and Message, and this information can be used by the document plugin to adapt
        /// the processing of a command, if it wants to (for instance, use default values instead of
        /// triggering some more advanced workflow).
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="versionId">Version identifier, blank implies 'latest' version</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <param name="command">Command name, taken from an earlier call to <see cref="GetDocumentCommands"/>
        /// - or any other command name that is understood by the provider. 'Private' commands that
        /// are not declared in GetDocumentCommands but are known to the authors of custom GUI code
        /// or OK.</param>
        /// <param name="additionalData">Array of strings containing whatever additional data the command
        /// may need. This parameter is intended for authors of more complex custom GUI's and works as
        /// a tunnel between the ultimate client and the document plugin. Standard GUI made by SuperOffice,
        /// such as a context menu connected to a document item in an archive, will not populate this
        /// member.<br/>It is strongly suggested that the convention of using name=value for each string
        /// array element be followed here.</param>
        /// <returns>Return value object, specifying failure or success plus any optional, additional processing to be triggered</returns>
        public ReturnInfo ExecuteDocumentCommand(IDocumentInfo documentInfo, string versionId, string[] allowedReturnTypes, string command, params string[] additionalData)
        {
            ReturnInfo ret = new ReturnInfo();
            if (_customCommand)
            {
                if (command == "TEST-URL")
                {
                    ret.Success = true;
                    ret.Type = ReturnType.URL;
                    ret.Value = "http://www.google.com/search?q=" + Uri.EscapeDataString(documentInfo.Header);
                }
                else if (command == "TEST-SO")
                {
                    ret.Success = true;
                    ret.Type = ReturnType.SoProtocol;
                    ret.Value = "contact.main?contact_id=" + documentInfo.ContactId.ToString();
                }
                else if (command == "TEST-MSG")
                {
                    ret.Success = true;
                    ret.Type = ReturnType.Message;
                    ret.Value = "[SR_LOGIN_UPGRADE_VERSION]";
                }
            }
            return ret;
        }


        /// <summary>
        /// Retrieve metadata owned by the plugin/repository, related to one document (excluding version-dependent metadata)
        /// </summary>
        /// <remarks>
        /// A document plugin may consume and provide an arbitrary number of metadata fields. These are placed
        /// in a string, string dictionary, representing name/value pairs. This call should <b>not</b>
        /// retrieve metadata related to any particular version, only data related to the document as a whole.
        /// <para/>
        /// The NetServer service call DocumentAgent.GetDocumentEntity will (among other things) result in a call 
        /// to this API to populate the ExtraFields property of the document entity carrier. Note, however, 
        /// that the carrier handed over to the client may contain other fields in addition to those 
        /// supplied by the document plugin, since the extrafields mechanism is generic and 
        /// there may be other metadata providers along the line.
        /// <para/>
        /// Attribute names should be prefixed with the name of the document plugin, to maintain global uniqueness.
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// </remarks>
        /// <param name="documentInfo">Document info used by the document plugin</param>
        /// <returns>Dictionary of name=value strings, each representing one key and one value.
        /// </returns>
        public Dictionary<string, string> LoadMetaData(IDocumentInfo documentInfo)
        {
            throw new Exception("The method or operation is not implemented.");
        }


        /// <summary>
        /// Retrieve metadata owned by the plugin/repository, related to one particular
        /// version of one document
        /// </summary>
        /// <remarks>
        /// A document plugin may consume and provide an arbitrary number of metadata fields. These are placed
        /// in a string, string dictionary, representing name/value pairs. This call should only retrieve
        /// metadata related to a version.
        /// <para/>
        /// The NetServer service call DocumentAgent.GetDocumentEntity will (among other things) result in a call 
        /// to this API to populate the VersionInfo property of the document entity carrier. 
        /// <para/>
        /// Attribute names should be prefixed with the name of the document plugin, to maintain global uniqueness.
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// <para/>
        /// To efficiently retrieve information about <b>all</b> versions, use the 
        /// <see cref="SuperOffice.CRM.Documents.IDocumentPlugin2.GetVersionList"/> method, instead of iterating
        /// over this method.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="versionId">Version identifier, blank implies 'latest' version</param>
        /// <returns>Fully populated version info structure</returns>
        public VersionInfo LoadVersionInfo(IDocumentInfo documentInfo, string versionId)
        {
            if (versionId.Equals(string.Empty))
            {
                versionId = "0";
            }
            VersionInfo versionInfo = new VersionInfo();

            if ((Versioning == Constants.Values.False) ||
                (Versioning == Constants.Values.Optional && documentInfo.LockSemantics != DocumentLockSemantics.Versioning))
            {
                //Populate blank version id if plugin/Document does not support Versioning
                versionInfo.VersionId = string.Empty;
            }
            else
            {
                versionInfo = _helper.CreateVersionInfo(documentInfo.DocumentId, documentInfo.ExternalReference, versionId);
            }

            return versionInfo;
        }

        /// <summary>
        /// Store/update plugin-dependent document metadata in the repository
        /// </summary>
        /// <remarks>
        /// This call is made when the document metadata should be stored, and is the complement of the
        /// <see cref="SuperOffice.CRM.Documents.IDocumentPlugin2.LoadMetaData"/> method.
        /// The document plugin should extract whatever elements it 
        /// recognizes from the pluginData name/value dictionary. Failure to recognize an element should not cause an exception, 
        /// as there may be other plugins along the line (not document plugins, but service-level field providers) that own the data. 
        /// Likewise, absence of a value should be taken to imply �no change� to that value - not "delete".
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// </remarks>
        /// <param name="incomingInfo">SuperOffice document information. Note that the plugin is <b>not</b> responsible
        /// for storing this data; however, it is allowed to look at it, in case it influences how the document
        /// is stored. However, it should always be possible to retrieve a document using the ExternalReference
        /// or DocumentId keys alone.</param>
        /// <param name="pluginData">Name/value dictionary containing metadata</param>
        public void SaveMetaData(IDocumentInfo incomingInfo, Dictionary<string,string> pluginData)
        {
            //Get the current status from the DB
            DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(incomingInfo.DocumentId);
            DocumentLockSemantics currentStatus = docRow.LockSemantics;
            DocumentLockSemantics newStatus = incomingInfo.LockSemantics;

            if ((int)currentStatus < (int)newStatus)
            {
                docRow.LockSemantics = newStatus;
                docRow.Save();

                if (currentStatus != DocumentLockSemantics.None)
                {
					SoArc2Helper.EnsureDirectoryExists(new DirectoryInfo(_helper.GetVersionHistoryFolderPath(docRow, string.Empty)));
                }
            }
        }


        /// <summary>
        /// Store/update plugin-dependent document version metadata in the repository
        /// </summary>
        /// <remarks>
        /// This call is made when the document <b>version</b> metadata should be stored, and is the complement of the
        /// <see cref="SuperOffice.CRM.Documents.IDocumentPlugin2.LoadVersionInfo"/> method.
        /// The document plugin should extract whatever elements it 
        /// recognizes from the pluginData name/value dictionary. Failure to recognize an element should not cause an exception, 
        /// as there may be other plugins along the line (not document plugins, but service-level field providers) that own the data. 
        /// Likewise, absence of a value should be taken to imply �no change� to that value - not "delete".
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// </remarks>
        /// <param name="versionInfo">Version information to be saved</param>
        public void SaveVersionInfo( IDocumentInfo docInfo, VersionInfo versionInfo)
        {
            DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(versionInfo.DocumentId);

            //Save version information only if Plugin & Document support versioning
            if ((Versioning == Constants.Values.Mandatory) ||
                (Versioning == Constants.Values.Optional && docRow.LockSemantics == DocumentLockSemantics.Versioning))
            {
                if (versionInfo.VersionId.Equals(string.Empty))
                {
                    versionInfo.VersionId = "0";
                }

                _helper.SaveVersionInfo( versionInfo);
       
            }
        }


        /// <summary>
        /// Determine if the document exists in the repository
        /// </summary>
        /// <remarks>
        /// The plugin should declare, through the <see cref="SuperOffice.CRM.Documents.Constants.Capabilities.FastExists"/> property,
        /// whether this call is highly efficient or not. If it is efficient, then document archive providers and similar code
        /// will call it when populating an archive, otherwise not.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <returns>true if the document exists in the repository, otherwise false</returns>
        public bool Exists(IDocumentInfo documentInfo)
        {
            string path = _helper.GetFullArchivePath(documentInfo, string.Empty);

            using (new DocumentArchiveFileImpersonationContext())
            {
                if (File.Exists(path))
                    return true;
                else
                    return false;
            }
        }


        /// <summary>
        /// Return the length of the physical document. This should be an efficient method
        /// </summary>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="versionId">Version identifier, blank implies 'latest' version</param>
        /// <returns>Physical document length in bytes - this should be the same as the length of the stream
        /// returned by the LoadDocumentStream method.</returns>
        public long GetLength(IDocumentInfo documentInfo, string versionId)
        {
            if (Exists(documentInfo))
            {
                string docFullPath = _helper.GetFullArchivePath(documentInfo, versionId);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    return new FileInfo(docFullPath).Length;
                }
            }

            return -1;
        }


        #endregion


        #region Document Templates




        /// <summary>
        /// Get the "extension" for the template, i.e., what the file extension would have been - to 
        /// help identify the stream content format
        /// </summary>
        /// <remarks>
        /// Template documents are generally created in text editors and stored as files of some kind. The
        /// file extension indicates the kind of document - doc, docx, xls, txt, and so on. While the template
        /// may be stored inside the document repository as any kind of data byte collection, a concept
        /// akin to the file extension is still needed to help identify the document format, ahead of actually
        /// reading the template content.
        /// </remarks>
        /// <param name="templateInfo">Document template info: contains the extref/filename, template id, mime type.</param>    
        /// <returns>String equivalent to a file extension, for instance ".docx"</returns>
        public string GetTemplateExtension(IDocumentTemplateInfo templateInfo)
        {
            string fileName = templateInfo.ExternalReference;
            return Path.GetExtension(fileName);
        }


        /// <summary>
        /// Get the document template content as a stream. NetServer will read-to-end and close this stream
        /// </summary>
        /// <remarks>
        /// Document templates may be stored in a repository, with or without special content tags.
        /// Because a document template does not have a corresponding document record within
        /// SuperOffice, there is no documentId to identify it.
        /// <para/>
        /// This call is used by NetServer to retrieve a document template based on either
        /// an externalreference value stored in the corresponding DocTmpl.Filename field,
        /// or the Id of the doctmpl record itself. The document plugin is free
        /// to use either method of identification.
        /// <para/>
        /// Mail templates are passed in using extref = "filename=xyz&amp;allowPersonal=1" and docTemplateId = 0
        /// </remarks>
        /// <param name="templateInfo">Document template info: contains the extref/filename, template id, mime type.
        /// TemplateInfo.Id = 0 when archiving mail messages. 
        /// </param>
        /// <param name="languageCode">Language (en-US, nb-NO, etc) that the user is using in the user interface. Can be used to select language-specific templates.</param>
        /// <returns>Stream containing the template content. Null if no suitable template found.</returns>
        public System.IO.Stream LoadDocumentTemplateStream(IDocumentTemplateInfo templateInfo, string languageCode)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                System.IO.Stream retval = null;
                if (templateInfo.Id != 0)    // normal templates
                {
					string filePath = _helper.GetDocumentTemplatePath(templateInfo, languageCode, true);

					retval = GetStream(filePath);
                }
                else // Mail templates and other things not stored in DocTmpl table
                {
                    string templateName = GetExternalReferenceValue("filename", templateInfo.ExternalReference);
                    bool allowPersonal = GetExternalReferenceValue("allowPersonal", templateInfo.ExternalReference) == "1";
                    string filePath = string.Empty;
                    if (allowPersonal)
                    {
                        filePath = Path.Combine(ConfigFile.Documents.ArchivePath, Path.Combine(SoContext.CurrentPrincipal.Associate, templateName));
                        retval = GetStream(filePath);
                    }

                    if (retval == null)
                    {
                        filePath = Path.Combine(ConfigFile.Documents.TemplatePath, templateName);
                        retval = GetStream(filePath);
                    }
                }

                return retval;
            }
        }		

        /// <summary>
        /// Get the value of a property from a custom crafted externalReference string.
        /// Separator = � or &
        /// </summary>
        /// <param name="property">Name of property to retrieve value for</param>
        /// <param name="externalReference">The externalReference string.
        /// Ex: "soarc�filename=myfile.txt�allowPersonal=1"</param>
        /// <returns>Value of the requested property</returns>
        private string GetExternalReferenceValue(string property, string externalReference)
        {
            string retval = string.Empty;
            if (!string.IsNullOrEmpty(externalReference))
            {
                Regex pattern = new Regex(property + "=" + "([^�&]+)", RegexOptions.IgnoreCase);
                Match value = pattern.Match(externalReference);
                if (value != null && value.Success && value.Groups.Count > 1)
                    retval = value.Groups[1].Value;
            }
            return retval;
        }

        /// <summary>
        /// Retrieve the content of a physical file
        /// </summary>
        /// <param name="filePath">Full path and filename of a file to retrieve</param>
        /// <returns>Content of file</returns>
        private System.IO.Stream GetStream(string filePath)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (!string.IsNullOrEmpty(filePath) && (File.Exists(filePath)))
                {
                    for (int retry = 1; retry <= 3; retry++)
                    {
                        try
                        {
                            return File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                        }
                        catch (Exception ex)
                        {
                            if (retry < 3)
                                SoLogger.LogWarning(typeof(SoArc2), "File.Open '{1}' create failure. Retrying {0}".FormatWith(retry, filePath), ex.SimpleMessageStack());
                            else
                            {
                                SoLogger.LogError(ex);
                                throw;
                            }
                        }
                    }
                }
                else
                    return null;
            }
            return null;
        }

        /// <summary>
        /// Create or update the document template contents. Usually used when uploading a file to a new document template.
        /// </summary>
        /// <param name="templateInfo">Name and tooltip from the document template record in the database. The ExtRef/Filename may be set if this is an edit rather than an add.</param>
        /// <param name="content">Stream containing file content</param>
        /// <param name="languageCode">Language variation on the template. May be ignored by the plugin, or used to keep language specific versions of the template.</param>
        /// <returns>Template information with ExtRef/Filename and MimeType filled in. These values are saved in the DocTmpl record.</returns>
        public TemplateInfo SaveDocumentTemplateStream(IDocumentTemplateInfo templateInfo, System.IO.Stream content, string languageCode)
		{
			DocTmplRow docTmplRow = DocTmplRow.GetFromIdxDocTmplId(templateInfo.Id);
            string filePath = null;

			// what should we do if there is no doc template with the given id?
			if (docTmplRow.DocTmplId > 0)
			{
				Stream archive = null;


                // pad filename with template-id to avoid name-based collisions
                // (and to preserve SOARC behaviour after underlying changes in 
                // DocumentTemplateEntityImplementation.SetDocumentTemplateStream.
                // Josteink: Changeset 17358)
                                
                string fileNamePadding = templateInfo.Id.ToString() + "_";
                filePath = _helper.GetDocumentTemplatePath(templateInfo, languageCode, false, fileNamePadding);

				using (new DocumentArchiveFileImpersonationContext())
				{
					try
					{
                        // We write to a temp .NEW file in SO_ARC, then rename the old file, rename the NEW file, then delete the old file.
                        string newFilePath = filePath + ".new";
                        string oldFilePath = filePath + ".old";

                        FileInfo newFi = new FileInfo(newFilePath);
                        FileInfo fi = new FileInfo(filePath);
                        
						if (!fi.Directory.Exists)
						{
							fi.Directory.Create();
						}
                        for (int retry = 1; archive == null && retry <= 3; retry++)
                        {
                            try
                            {
                                archive = newFi.Open(FileMode.Create);
                            }
                            catch (Exception ex)
                            {
                                if (retry < 3)
                                {
                                    SoLogger.LogWarning(typeof(SoArc2), "File.Open create '{1}' failure. Retrying {0}".FormatWith(retry, filePath), ex.SimpleMessageStack());
                                    System.Threading.Thread.Sleep(200 * retry);
                                }
                                else
                                {
                                    SoLogger.LogError(ex);
                                    throw;
                                }
                            }
                        }

                        content.WriteInChunksTo(archive);

                        content.Close();
                        archive.Flush();
                        archive.Close();

                        // files are now written and flushed to disk.
                        // time to rename and delete the old file
                        if (File.Exists(oldFilePath))
                            File.Delete(oldFilePath);
                        if (fi.Exists)
                            fi.MoveTo(oldFilePath);
                        newFi.MoveTo(filePath);
                        if (File.Exists(oldFilePath))
                            File.Delete(oldFilePath);
                    }
                    catch (Exception ex)
                    {
                        SoLogger.LogError(ex);
                        throw new Exception("Error occurred at saving the physical document", ex);
                    }
                    finally
					{
						content.Dispose();
						if (archive != null)
						{
							archive.Dispose();
						}
					}
				}
			}
			
			TemplateInfo template = new TemplateInfo();
            template.Name = docTmplRow.Name;
			template.Description = docTmplRow.Filename;
			template.PluginId = 0;  // SoArc is id = 0
            template.MimeType = templateInfo.MimeType;

            
            // Don't overwrite the external reference if this is the main template.
            if (string.IsNullOrEmpty(languageCode))
            {                
                template.ExternalReference = Path.GetFileName(filePath);
            }
            else
            {
                template.ExternalReference = docTmplRow.Filename;
            }

            return template;
		}

        #endregion


        #region Document Content and Lifetime


        /// <summary>
        /// Create a document in the repository, intially without content
        /// </summary>
        /// <remarks>
        /// Execution of this method should result in the creation of a document instance in the
        /// underlying repository, with empty content. If locking is supported, the status should
        /// be 'Checked-out'; the document should not be visible to other users. If locking is not 
        /// supported, a zero-length content sh.ould be the result.
        /// <para/>
        /// All metadata should be saved, an externalReference key should be assigned, and
        /// the file name/document name validated and reserved.
        /// <para/><b>Notes on semantics</b><br/>
        /// The IDocumentInfo.<see cref="SuperOffice.CRM.IDocumentInfo.Semantics"/> property is used to specify the
        /// locking/versioning semantics requested and implemented for a document. Semantics actually implemtned
        /// will be the lowest of what is requested and what is supported. Thus, a document may request 
        /// <see cref="SuperOffice.Data.DocumentSemantics.None"/> semantics even if versioning is optionally supported
        /// by the document plugin, and in that case no versioning or locking should be performed.
        /// <para/>
        /// On creation, if locking and/or versioning is supported and requested, then the document stream should
        /// be saved to a temporary area. Calls to GetDocumentStream should return an empty stream until the first
        /// call to CheckinDocument has succeeded. The result of that Checkin call will be the base version 
        /// (version 1).
        /// <para/>
        /// Locking semantics are set on creation and cannot be changed later.
        /// </remarks>
        /// <param name="incomingInfo">SuperOffice metadata for the document, including the document Id
        /// and locking/versioning sematics requested for this document.</param>
        /// <param name="fileName">Suggested file name/document name. The document plugin must validate this
        /// name and amend it if needed (this is a ref parameter). If the name needs to be changed
        /// for any reason, a new and valid name must be generated by the plugin, and returned
        /// to the caller.</param>
        /// <param name="extraFields">Plugin-dependent metadata for the document as a whole. The
        /// usual caveats apply, i.e., there may be name/value pairs in the parameter that
        /// belong to other parts of the system. Failure to recognize a name is not an error.</param>
        /// <param name="versionDecription">Description of the initial version, if versioning is supported
        /// and enabled for the document.</param>
        /// <param name="versionExtraFields">Plugin-dependent metadata for the initial version</param>
        /// <returns></returns>
        public string CreateDocument(SuperOffice.CRM.IDocumentInfo incomingInfo, ref string fileName, string[] extraFields, string versionDecription, string[] versionExtraFields)
        {
            //Document properties
            bool isLockable = ((this.Locking == Constants.Values.Mandatory) ||
                ((this.Locking == Constants.Values.Optional) & (incomingInfo.LockSemantics != DocumentLockSemantics.None)));

            int documentId = incomingInfo.DocumentId;

            //Generate the document full path
            try
            {
                // Create the file with a unique file name.(in Document's root folder)
                //set this file name to the ref parameter so that the caller knows the new name
				string suggestedFullPath = _helper.GetFullArchivePath(incomingInfo, string.Empty);
				string createdFilePath = SoArc2Helper.MakeLegalFileNameAndDirectory(suggestedFullPath);

				string uniqueFilePath = SoArc2Helper.GetUniqueFilePath(createdFilePath);	// resolve any duplicates
                
                // filename gets persisted to the DB, and should NOT have an absolute path ever.
                fileName = Path.GetFileName(uniqueFilePath);

                using (new DocumentArchiveFileImpersonationContext())
                {

                    FileStream fsCreatedFile = File.Create(uniqueFilePath);
                    fsCreatedFile.Close();

                    // Create the version history folder & the temp file if the document is lockable. Also sets the readonly property to mark it as checked out.
                    if (isLockable)
                    {
                        // Create or Get the version folder for the document
                        string versionFolder = _helper.GetVersionHistoryFolderPath(incomingInfo, fileName != incomingInfo.Name ? fileName : string.Empty);

                        // Copying the initial file into the folder.
                        File.Copy(createdFilePath, Path.Combine(versionFolder, fileName));

                        // Set the file to be readonly as it's checked out by the called user
                        FileAttributes CurrentAtts = File.GetAttributes(createdFilePath);
                        File.SetAttributes(createdFilePath, CurrentAtts | FileAttributes.ReadOnly);
                    }
                }
            }
            catch(Exception ex)
            {
                SoLogger.LogError(ex);
                throw new Exception("Error occurred at creating the physical document", ex);
            }

            //Save document level metadata for the new file.
            ArrayList docMetaData = new ArrayList();

            //fill the relevent keys
            docMetaData.Add(String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutState, isLockable ? Constants.Values.True : Constants.Values.False));
            docMetaData.Add(String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutByAssociateId, isLockable ? Convert.ToString(SoContext.CurrentPrincipal.AssociateId) : "0" ));
            docMetaData.Add(String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.NumVersions, isLockable ? "-1" : "0"));
            string[] docMetaDataArr = (string[])docMetaData.ToArray(typeof(string));

            _helper.SaveDocumentInfo(documentId, docMetaDataArr);

            VersionInfo initVersion = _helper.CreateVersionInfo(documentId, string.Empty, 0, null, versionDecription, DateTime.MinValue, null, null, versionExtraFields);

            SaveVersionInfo(incomingInfo, initVersion);
           
            //Returning empty string for the external reference
            return string.Empty;
        }


        /// <summary>
        /// Save the stream as the document content in the repository; depending on the state, this
        /// may imply creating a temporary save pending a final checkin, or an immediately visible result.
        /// </summary>
        /// <remarks>
        /// If the document is currently checked out to the current user, then the stream should be saved, 
        /// but this call does not imply the automatic creation of a new version (visible to other users) 
        /// or automatic checkin. However, it is an advantage if subsequent GetDocument calls made by 
        /// the same user using the same key return the latest known content � while other users see 
        /// the latest checked-in version.
        /// <para/>
        /// If the plugin does not support locking agnd versioning (or such semantics are not requested, see below), 
        /// then each call to this API overwrites 
        /// any prior content completely and becomes the new, official content immediately. The Save operation 
        /// should be atomic, and should not destroy earlier content if it fails.
        /// <para/>
        /// If locking is supported and requested, the document is checked out and some other associate than the one 
        /// that has checked it out calls this API, a failure message should be returned.
        /// </remarks>
        /// <param name="incomingInfo">Incoming document metadata, used to identify the document. Metadata
        /// changes are <b>not</b> to be checked or saved by this operation - only the document stream is saved.</param>
        /// <param name="content">Document content, a binary stream about which nothing is assumed. The
        /// document plugin should read-to-end and close this stream.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo SaveDocumentFromStream(SuperOffice.CRM.IDocumentInfo incomingInfo, string[] allowedReturnTypes, System.IO.Stream content)
        {
            Stream archive = null;
            string filePath ;

            if (_helper.IsLockingSupported(incomingInfo.DocumentId , Locking ))
            {
                CheckoutInfo checkoutInfo = GetCheckoutState(incomingInfo);
                if (checkoutInfo.State == CheckoutState.CheckedOutOwn)
                {
                    filePath = Path.Combine(_helper.GetVersionHistoryFolderPath(incomingInfo,string.Empty), incomingInfo.Name);
                }
                else
                {
                    return _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "Document is not checkout by the requested user.", string.Empty);
                }
            }
            else
            {
                filePath = _helper.GetFullArchivePath(incomingInfo, string.Empty);
            }

            using (new DocumentArchiveFileImpersonationContext())
            {
                // We write to a temp .NEW file in SO_ARC, then rename the old file, rename the NEW file, then delete the old file.
                string newFilePath = filePath + ".new";
                string oldFilePath = filePath + ".old";

                FileInfo newFi = new FileInfo(newFilePath);
                FileInfo fi = new FileInfo(filePath);
                try
                {
                    if (!fi.Directory.Exists)
                    {
                        fi.Directory.Create();
                    }

                    for (int retry = 1; archive == null && retry <= 3; retry++)
                    {
                        try
                        {
                            archive = newFi.Open(FileMode.Create);
                        }
                        catch (Exception ex)
                        {
                            if (retry < 3)
                            {
                                SoLogger.LogWarning(typeof(SoArc2), "File.Open '{1}' create failure. Retrying {0}".FormatWith(retry, filePath), ex.SimpleMessageStack());
                                System.Threading.Thread.Sleep(200 * retry);
                            }
                            else
                            {
                                SoLogger.LogError(ex);
                                throw;
                            }
                        }
                    }

                    content.WriteInChunksTo(archive);

                    content.Close();
                    archive.Flush();
                    archive.Close();

                    // files are now written and flushed to disk.
                    // time to rename and delete the old file
                    if (File.Exists(oldFilePath))
                        File.Delete(oldFilePath);
                    if (fi.Exists)
                        fi.MoveTo(oldFilePath);
                    newFi.MoveTo(filePath);
                    if( File.Exists( oldFilePath ) )
                        File.Delete(oldFilePath);

                    return _helper.CreateReturnInfo(true, string.Empty, string.Empty, ReturnType.None, string.Empty, string.Empty);
                }
                catch (Exception e)
                {
                    SoLogger.LogError(e);
                    return _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.None, "Failed to save file '" + filePath + "' " + e.Message, string.Empty);
                }
                finally
                {
                    content.Dispose();
                    if (archive != null)
                    {
                        archive.Dispose();
                    }
                }

            } // using DocumentArchiveFileImpersonationContext
        }

        /// <summary>
        /// Get document content as a stream. NetServer will read-to-end and close this stream.
        /// </summary>
        /// <remarks>
        /// It is up to the document plugin whether it can open a stream directly into the underlying repository, 
        /// or whether it has to extract the document to some temporary area and then stream that � 
        /// however, the fewer buffers the better.
        /// </remarks>
        /// <param name="incomingInfo">Fully populated document metadata, used to identify the document.</param>
        /// <param name="versionId">Optional version identifier, blank implies 'latest' version</param>
        /// <returns>Document content stream</returns>
        public System.IO.Stream LoadDocumentStream(SuperOffice.CRM.IDocumentInfo incomingInfo, string versionId)
        {
            int documentId = incomingInfo.DocumentId;

            string docPath = string.Empty;
            bool writable = false;

            if (!string.IsNullOrEmpty(versionId))
            {
                docPath = _helper.GetFullArchivePath(incomingInfo, versionId);
            }
            else
            {
                CheckoutInfo checkoutInfo = GetCheckoutState(incomingInfo);
                if (checkoutInfo.State == CheckoutState.CheckedOutOwn)
                {
                    string documentName = incomingInfo.Name;
                    string documentHistoryFolderPath = _helper.GetVersionHistoryFolderPath(incomingInfo, string.Empty); 
                    docPath = Path.Combine(documentHistoryFolderPath, documentName);
                    writable = true;
                }
                else
                {
                    docPath = _helper.GetFullArchivePath(incomingInfo, versionId);
                }
            }
            
            FileStream docFileStream = null;
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (!string.IsNullOrEmpty(docPath))
                {
                    try
                    {
                        docFileStream = new FileStream(docPath,
                            FileMode.Open,
                            writable ? FileAccess.ReadWrite : FileAccess.Read,
                            writable ? FileShare.ReadWrite : FileShare.Read);

                    }
                    catch (FileNotFoundException fileEx)
                    {
                        SuperOffice.Diagnostics.SoLogger.LogError(fileEx);
                        throw new SoException(string.Format("The document named '{0}', was not found in the document archive. " + 
                            "Please contact your administrator to rectify the problem.", incomingInfo.Name));
                    }
                    catch ( Exception e)
                    {
                        SuperOffice.Diagnostics.SoLogger.LogError(e);
                        //Do nothing. null will be returned;
                    }
                }
            }

            return (Stream)docFileStream;
        }

        /// <summary>
        /// Get a WebDAV-compliant URL referring to the given document
        /// </summary>
        /// <remarks>
        /// Document plugins may support document access via WebDAV. This call is used to retrieve a WebDAV url that 
        /// will give the specified access to the document. This URL will be passed to the ultimate client 
        /// (most probably a text editor application), and control will not return to NetServer.
        /// <para/>
        /// The string returned here should be a fully resolved URL that can be given directly to the editor application.
        /// </remarks>
        /// <param name="incomingInfo">Fully populated document metadata, used to identify the document.</param>
        /// <param name="versionId">Optional version identifier, blank implies 'latest' version</param>
        /// <param name="writeableUrl">If true, then the request URL should allow the document editor to write content
        /// back to the repository; otherwise, a url that does not support writeback should be supplied
        /// if possible.</param>
        /// <returns>"file:////fileserver/soarc/user/2013.2/file.ext"</returns>
        public string GetDocumentUrl(IDocumentInfo incomingInfo, string versionId, bool writeableUrl)
        {
            string path = _helper.GetFullArchivePath(incomingInfo, versionId);
            Uri uri = new Uri(path);
            return uri.AbsoluteUri; // file:////fileserver/share/dir/file.ext
        }

        /// <summary>
        /// Delete a document, all versions and all metadata from the repository
        /// </summary>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo DeleteDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            ReturnInfo returnInfo = new ReturnInfo();
            bool isDeleted = false;
            SuperOffice.CRM.Entities.Document doc = SuperOffice.CRM.Entities.Document.GetFromIdxDocumentId(documentInfo.DocumentId);

            if (!doc.Row.Sentries.CanTableDo(TablesInfo.GetDocumentTableInfo(), ETableRight.Delete))
            {
                returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "User Does not have permission to Modify the Document", string.Empty);
            }
            else
            {
                CheckoutInfo checkoutInfo = GetCheckoutState(documentInfo);
                if (checkoutInfo.State == CheckoutState.NotCheckedOut || checkoutInfo.State == CheckoutState.LockingNotSupported)
                {
                    isDeleted = _helper.DeleteDocumentData(documentInfo.DocumentId);

                    if (isDeleted)
                    {
                        returnInfo = _helper.CreateReturnInfo(true, string.Empty, string.Empty, ReturnType.Message, string.Format("Data Deleted for document Id : {0}", documentInfo.DocumentId), string.Empty);
                    }
                    else
                    {
                        returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, string.Format("Could not delete data for document Id: {0}, Name:'{1}'", documentInfo.DocumentId, documentInfo.Name), string.Empty);
                    }
                }
                else
                {
                    returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message,
                        string.Format("Could not delete data for document {0} . \n Document is CheckedOut.", documentInfo.DocumentId), string.Empty);
                }
            }

            return returnInfo;
        }


        /// <summary>
        /// Rename a document in the repository
        /// </summary>
        /// <remarks>
        /// The document name should be changed from the existing to the new name. However,
        /// if the new name is not valid (or collides with an existing name of some other
        /// document), then the plugin should amend the name to a valid one and return
        /// it, instead of throwing an exception.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="newFileName">Suggested new document name</param>
        /// <returns>Actual new document name, limited to 254 characters
        /// If renaming was not occured this will return an empty string</returns>
        public string RenameDocument(IDocumentInfo documentInfo, string newFileName)
        {
            //Check whether the document is not being checked out for editing.
            CheckoutInfo checkoutInfo = GetCheckoutState(documentInfo);

            if (checkoutInfo.State == CheckoutState.NotCheckedOut || checkoutInfo.State == CheckoutState.LockingNotSupported)
            {
                bool isLockable = ((this.Locking == Constants.Values.Mandatory) ||
                    ((this.Locking == Constants.Values.Optional) & (documentInfo.LockSemantics != DocumentLockSemantics.None)));

                string fileDirectoryPath = _helper.GetCurrentVersionFolderPath(documentInfo);
				string suggestedFullPath = SoArc2Helper.MakeLegalFileNameAndDirectory(Path.Combine(fileDirectoryPath, newFileName));
				string uniqueName = SoArc2Helper.GetUniqueFilePath(suggestedFullPath);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    //Rename the root file
                    File.Move(Path.Combine(fileDirectoryPath, documentInfo.Name), uniqueName);

                    if (isLockable)
                    {
                        //Rename all versions
                        DirectoryInfo versionDir = new DirectoryInfo(_helper.GetVersionHistoryFolderPath(documentInfo, string.Empty));
                        FileInfo[] fileArr = versionDir.GetFiles();

                        foreach (FileInfo file in fileArr)
                        {
                            string oldFileName = file.Name;
                            string oldFileNameWithoutExt = Path.GetFileNameWithoutExtension(file.Name);

                            string newVersionFileName = uniqueName;

                            //If it's a version file
                            if ((oldFileNameWithoutExt.Length > 4) && oldFileName.Substring(oldFileNameWithoutExt.Length - 4, 1) == "-")
                            {
                                string versionStr = oldFileNameWithoutExt.Substring(oldFileNameWithoutExt.Length - 4);
                                newVersionFileName = Path.GetFileNameWithoutExtension(uniqueName) + versionStr + Path.GetExtension(uniqueName);
                            }
                            file.MoveTo(Path.Combine(versionDir.FullName, newVersionFileName));
                        }

                        //Rename the version history folder
                        Directory.Move(_helper.GetVersionHistoryFolderPath(documentInfo, string.Empty), Path.Combine(fileDirectoryPath, Path.GetFileNameWithoutExtension(uniqueName)));
                    }
                }

                // contract says we should return file-name only.
                string uniqueFileName = Path.GetFileName(uniqueName);
                return uniqueFileName; 
            }
            else
            {
                return string.Empty;
            }
        }


        #endregion


        #region Locking and Versioning


        /// <summary>
        /// Get the checkout state of a document
        /// </summary>
        /// <remarks>
        /// This API is called from inside document archive providers if the plugin has declared that it
        /// supports fast fetching of this attribute. If the document plugin does not support locking or
        /// versioning, then the return value should have state NotCheckedOut, associate id 0 and blank name.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <returns>Object that describes the checkout state of the document</returns>
        public CheckoutInfo GetCheckoutState(IDocumentInfo documentInfo)
        {
            CheckoutInfo checkOutInfo = new CheckoutInfo();
            bool isLockingSupported = _helper.IsLockingSupported(documentInfo.DocumentId,_locking);

            if (!isLockingSupported)//Locking not supported
            {                
                checkOutInfo = _helper.CreateCheckoutInfo(0, string.Empty, CheckoutState.LockingNotSupported);
                return checkOutInfo;
            }

            //Locking is supported. Do the rest
            string checkOutState = _helper.GetDocumentLevelProperty(documentInfo.DocumentId, SoArc2Helper.DocumentInfoKeys.CheckOutState);
            int loggedInUserId = SoContext.CurrentPrincipal.AssociateId;
            int checkedOutUserId = _helper.GetCheckOutAssociateId(documentInfo.DocumentId);

            if (checkOutState == Constants.Values.True)//Document is checked out
            {
                string checkedOutUserName = _helper.GetAssociateName(checkedOutUserId);

                if (loggedInUserId == checkedOutUserId)//Document is checked out by logged in user
                {
                    checkOutInfo = _helper.CreateCheckoutInfo(checkedOutUserId, checkedOutUserName, CheckoutState.CheckedOutOwn);
                }
                else//Document is checked out by other user
                {
                    checkOutInfo = _helper.CreateCheckoutInfo(checkedOutUserId, checkedOutUserName, CheckoutState.CheckedOutOther);
                }
            }
            else//Document is not checked out
            {
                checkOutInfo = _helper.CreateCheckoutInfo(0, string.Empty, CheckoutState.NotCheckedOut);
            }

            return checkOutInfo;
        }


        /// <summary>
        /// Check out the document for editing
        /// </summary>
        /// <remarks>
        /// A document plugin that supports versioning may internally prepare to receive new content and 
        /// prepare a new internal version, but a subsequent GetDocumentVersionList call should <b>not</b> 
        /// show this version � not until CheckInDocument has been called. 
        /// <para/>
        /// After the completion of this call, the document is in checked out state and <see cref="GetCheckoutState"/> 
        /// should return �Own� as the status. <see cref="PutDocumentFromStream"/> calls on behalf of other users should
        /// fail, as should <see cref="CheckoutDocument"/> and <see cref="CheckinDocument"/> calls on behalf of other users.
        /// <para/>
        /// If the document plugin does not support locking or versioning, then this call should perform no action.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo CheckoutDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            ReturnInfo returnInfo = new ReturnInfo();
            
            SuperOffice.CRM.Entities.Document doc = SuperOffice.CRM.Entities.Document.GetFromIdxDocumentId(documentInfo.DocumentId);
            //User cannot check out the document if he does not have permission to update the document.
            if (doc == null)
            {
                returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "User Does not have permission to Modify the Document", string.Empty);
            }
            else if (!doc.Row.Sentries.CanTableDo(TablesInfo.GetDocumentTableInfo(), ETableRight.Update))
            {
                returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "User Does not have permission to Modify the Document", string.Empty);
            }
            else if (_helper.IsLockingSupported(documentInfo.DocumentId, _locking)) //Do the need full if the Plugin & Document supports locking or versioning
            {
                CheckoutInfo checkoutInfo = GetCheckoutState(documentInfo);
                if (checkoutInfo.State == CheckoutState.CheckedOutOwn)
                {
                    returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "Document is already locked by the user", string.Empty);
                }
                else if (checkoutInfo.State == CheckoutState.CheckedOutOther)
                {
                    returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "Document is already locked by another user", string.Empty);
                }
                else if (checkoutInfo.State == CheckoutState.NotCheckedOut)
                {
                    //update database records
                    ArrayList docMetaData = new ArrayList();
                    docMetaData.Add(String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutState, Constants.Values.True));
                    docMetaData.Add(String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutByAssociateId, SoContext.CurrentPrincipal.AssociateId));

                    _helper.SaveDocumentInfo(documentInfo.DocumentId, (string[])docMetaData.ToArray(typeof(string)));

                    if (Exists(documentInfo))
                    {
                        _helper.SetDocumentsOnCheckout(documentInfo.DocumentId);
                        returnInfo = _helper.CreateReturnInfo(true, string.Empty, string.Empty, ReturnType.Message, "Document is CheckedOut for the requested user", string.Empty);
                    }
                    else
                    {
                        DocumentRow docRow = DocumentRow.GetFromIdxDocumentId(documentInfo.DocumentId);
                        returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, String.Format("Could not find file: {0}", _helper.GetFullArchivePath(docRow, string.Empty)), string.Empty);
                    }
                }
            }
            else
            {
                returnInfo = _helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.Message, "Locking Not Supported for this document", string.Empty);
            }

            return returnInfo;
        }


        /// <summary>
        /// Check in a currently checked-out document
        /// </summary>
        /// <remarks>
        /// If the document plugin supports locking and the requesting user is the one who checked out the document, 
        /// then the last-saved content by that user should become the new publicly visible content, and 
        /// the checkout state should be reset. Calls by other users should result in failure and no state change.
        /// <para/>
        /// If the document plugin does not support locking or versioning, then this call should perform no action.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo CheckinDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes, string versionDescription, string[] versionExtraFields)
        {
            ReturnInfo returnInfo = new ReturnInfo();

            bool isLockable = _helper.IsLockingSupported(documentInfo.DocumentId,_locking);
            bool isVersionable = _helper.IsVersioningSupported(documentInfo.DocumentId, _versioning);

            if (isLockable)
            {
                CheckoutInfo checkoutInfo = GetCheckoutState(documentInfo);
                if (checkoutInfo.State == CheckoutState.NotCheckedOut)
                {
                    returnInfo = _helper.CreateReturnInfo(false, documentInfo.ExternalReference, string.Empty, ReturnType.Message, "Document was not checked out for editing", String.Empty);
                }
                else if (checkoutInfo.State == CheckoutState.CheckedOutOther)
                {
                    returnInfo = _helper.CreateReturnInfo(false, documentInfo.ExternalReference, string.Empty, ReturnType.Message, "Document was checked out by another use", String.Empty);
                }
                else if (checkoutInfo.State == CheckoutState.CheckedOutOwn)
                {                    
                    // get the latest (curent) version's information
                    VersionInfo latestVersionInfo = LoadVersionInfo(documentInfo, string.Empty);
                    //check whether this is a new document or a document which has previous versions
                    int numVersions = _helper.GetNumberOfVersions(documentInfo.DocumentId);

                    //Physical document handling for the checkin
                    int nextVersion = _helper.SetDocumentsOnCheckin(documentInfo.DocumentId, isVersionable, numVersions);
            
                    // Update document level information
                    string[] docMetaData = new string[4];
                    docMetaData[0] = (String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutState, Constants.Values.False));
                    docMetaData[1] = (String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutByAssociateId, 0));
                    docMetaData[2] = (String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.CheckOutByAssociateName, string.Empty));
                    docMetaData[3] = (String.Format("{0}={1}", SoArc2Helper.DocumentInfoKeys.NumVersions, nextVersion));

                    _helper.SaveDocumentInfo(documentInfo.DocumentId, docMetaData);

                    VersionInfo verInfo = _helper.CreateVersionInfo(documentInfo.DocumentId, Convert.ToString(0), checkoutInfo.AssociateId, checkoutInfo.Name, 
                                                                 versionDescription, DateTime.Now, string.Empty, string.Empty, new string[0]);//  versionId = 0 :Saving data to document level
                    SaveVersionInfo(documentInfo, verInfo);

                    if (isVersionable && (numVersions != -1))
                    {
                        // Adding the previously existed latest version as the new version into database
                        VersionInfo nextVersionInfo = _helper.CreateVersionInfo(documentInfo.DocumentId, Convert.ToString(nextVersion), latestVersionInfo.CheckedInByAssociateId, 
                                                                            latestVersionInfo.CheckedInByName, latestVersionInfo.Description, latestVersionInfo.CheckedInDate, 
                                                                            latestVersionInfo.DisplayText, latestVersionInfo.ExternalReference, latestVersionInfo.ExtraFields);

                        SaveVersionInfo(documentInfo, nextVersionInfo);
                    }

                    // Success. Create the returnInfo
                    returnInfo = _helper.CreateReturnInfo(true, documentInfo.ExternalReference, string.Empty, ReturnType.Message, "Document was successfully checked in", String.Empty);
                }
            }
            else
            {
                returnInfo = _helper.CreateReturnInfo(false, documentInfo.ExternalReference, string.Empty, ReturnType.Message, "Document or Plugin does not support locking", String.Empty);
            }
            return returnInfo;
        }


        /// <summary>
        /// Undo (abandon) a checkout
        /// </summary>
        /// <remarks>
        /// If the document plugin supports locking and the requesting user is the one who checked out the document, 
        /// then any content saved since the checkout should be discarded and the checkout state reset. 
        /// The content will be as before checkout. 
        /// <para/>
        /// Calls by other users should result in failure and no state change � except if the calling user has the right to force an undo
        /// <para/>
        /// If the document plugin does not support locking or versioning, then this call should perform no action.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo UndoCheckoutDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            if (!_helper.IsLockingSupported(documentInfo.DocumentId,_locking))
            {
                //TODO - Check whether message is really needed and if so add it to resource files.
                return _helper.CreateReturnInfo(false, documentInfo.ExternalReference, string.Empty, ReturnType.None, "Locking is not supported", String.Empty);
            }

            int loggedInUserId = SoContext.CurrentPrincipal.AssociateId;
            int checkedOutUserId = _helper.GetCheckOutAssociateId(documentInfo.DocumentId);
            if (loggedInUserId == checkedOutUserId)
            {
                return _helper.UndoCheckout(documentInfo.DocumentId,documentInfo.ExternalReference);
            }
            else
            {
                //System user can undo any checkout
                //TODO - Check this
                if (SoContext.CurrentPrincipal.RoleType == RoleType.System)
                {
                    return _helper.UndoCheckout(documentInfo.DocumentId, documentInfo.ExternalReference);
                }
                else
                {
                    //TODO - Check whether message is really needed and if so add it to resource files.
                    return _helper.CreateReturnInfo(false, documentInfo.ExternalReference, string.Empty, ReturnType.None, "You are not allowed to Undo", String.Empty);
                }
            }
        }


        /// <summary>
        /// Get the list of current versions for the given document
        /// </summary>
        /// <remarks>
        /// The list should not include an �in-work� version, if the document is currently checked out � only 
        /// versions visible and accessible to any authorized user.
        /// <para/>
        /// If the document plugin does not support versioning, then this call should return an empty array.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Array of objects describing the existing, committed versions for this document</returns>
        public VersionInfo[] GetVersionList(IDocumentInfo documentInfo)
        {
            VersionInfo[] versionInfoArray;
            bool isVersioningSupported = _helper.IsVersioningSupported(documentInfo.DocumentId,_versioning);

            if (!isVersioningSupported)//Versioning is not supported
            {
                return versionInfoArray = new VersionInfo[0];
            }
            else//Versioning is supported
            {               
                return _helper.GetVersions(documentInfo.DocumentId);
            }
        }

        #endregion


        /// <summary>
        /// Create a default document based on the given documentType. Called when creating a new template.
        /// </summary>
        /// <param name="documentTypeKey">Id for a document type. NULL or blank if no types are supported.</param>
        /// <param name="documentTemplateInfo">Document template info</param>
        /// <returns>Extref/Filename for new template. This value is written to the template's Filename property.
        /// Return NULL if no change, or if no document created.</returns>
        public TemplateInfo CreateDefaultDocumentTemplate(int documentTypeKey, IDocumentTemplateInfo documentTemplateInfo)
        {
            // SoArc do not care about this. 
            return null;
        }

        /// <summary>
        /// Get a list of supported document template types. 
        /// </summary>
        /// <returns>An dictionary of key=display-name for supported document types for template. Empty dictionary if no document types supported.</returns>
        public Dictionary<int, string> GetSupportedDocumentTypesForDocumentTemplates()
        {
            // SoArc does not support document types - return empty dictionary
            return new Dictionary<int, string>();            
        }


        /// <summary>
        /// Get the values of certain properties, for a given document template
        /// </summary>
        /// <remarks>
        /// Each document can have a number of properties associated with it. A set of standard properties
        /// is defined in the <see cref="SuperOffice.CRM.Documents.Constants.Properties"/> class. Ideally, retrieving properties should
        /// be a lightweight operation.
        /// <para/>
        /// Note that 'properties' are a one-way mechanism where the document plugin provides information about
        /// the document or certain aspects of it. This is not the same as document-specific
        /// metadata, which is handled by the <see cref="LoadMetaData"/> and <see cref="SaveMetaData"/>
        /// methods.
        /// </remarks>        
        /// <param name="documentTemplateInfo">Document template record from the SuperOffice database</param>
        /// <param name="requestedProperties">Array of property strings, for which values are requested</param>
        /// <returns>Dictionary of name=value pairs, where the name is one of the requested property strings, and the value
        /// is the value of that property for the given document.</returns>
        public Dictionary<string, string> GetDocumentTemplateProperties(IDocumentTemplateInfo templateInfo, string[] requestedProperties)
        {
            var result = new Dictionary<string,string>(requestedProperties.Length);
            foreach( string prop in requestedProperties )
            {
                switch (prop)
                {
                    case Constants.Properties.PreferredOpen:
                        result[prop] = Constants.Values.Stream;
                        break;

                    case Constants.Properties.FileName:
                        result[prop] = templateInfo.ExternalReference;
                        break;

                    default:
                        result[prop] = null;
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// Get a URL referring to the given document template:  "file:////fileserver/soarc/template/file.ext"
        /// </summary>
        /// <remarks>
        /// Document plugins may support document access via URLs. This call is used to retrieve a url that 
        /// will give the specified access to the document. This URL will be passed to the ultimate client 
        /// (most probably a browser, but could be a text editor application), and control will not return to NetServer.
        /// <para/>
        /// The string returned here should be a fully resolved URL that can be given directly to the editor application.
        /// </remarks>
        /// <param name="documentTemplateInfo">The document template info from database</param>        
        /// <param name="writeableUrl">If true, then the request URL should allow the document editor to write content
        /// back to the repository; otherwise, a url that does not support writeback should be supplied
        /// if possible.</param>
        /// <param name="languageCode">Language variation on the template. May be ignored by the plugin, or used to keep language specific versions of the template.</param>
        /// <returns>URL that gives access to the template: "file:////fileserver/soarc/template/file.ext"</returns>
        public string GetDocumentTemplateUrl(IDocumentTemplateInfo documentTemplateInfo, bool writeableUrl, string languageCode)
        {
            string path = _helper.GetDocumentTemplatePath(documentTemplateInfo, languageCode, true);
            Uri uri = new Uri(path);
            return uri.AbsoluteUri; // file:////fileserver/share/dir/file.ext
        }


        /// <summary>
        /// Get the list of languages supported by the given template, not including the default (blank) language.
        /// </summary>
        /// <remarks>Used when populating the dropdown list in the admin client or the document dialog.</remarks>
        /// <param name="documentTemplateInfo">The template we are curious about</param>
        /// <returns>Array of ISO codes: ("en-US", "nb-NO", "fr")</returns>
        public string[] GetDocumentTemplateLanguages(IDocumentTemplateInfo documentTemplateInfo)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {

            var fileName = documentTemplateInfo.ExternalReference;
                string[] files;
                try
                {
                    files = Directory.GetFiles(ConfigFile.Documents.TemplatePath, fileName, SearchOption.AllDirectories);

                }
                catch (Exception ex)
                {
                    SoLogger.LogWarning(ex);

                    files = new string[0];
                }

                var soLangRegex =
                    new Regex(ConfigFile.Documents.TemplatePath.TrimEnd('\\').Replace("\\", "\\\\") + @"\\(\w\w)\\" +
                              fileName);

            var result = from f in files
                         let m = soLangRegex.Match(f)
                         where m.Success
                         select CultureDataFormatter.MapSuperOfficeLanguageToCulture(m.Groups[1].Value);

            return result.ToArray();
        }
        }

        /// <summary>
        /// Delete a document template, all language variations and all metadata from the repository
        /// </summary>
        /// <param name="documentTemplateInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type. ("None", "Message", "SoProtocol", "CustomGUI", "Other")</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo DeleteDocumentTemplate(IDocumentTemplateInfo documentTemplateInfo, string[] allowedReturnTypes)
        {
            string path = _helper.GetDocumentTemplatePath(documentTemplateInfo, "", true);
            if (File.Exists(path))
            {
                var languages = GetDocumentTemplateLanguages(documentTemplateInfo);

                foreach (var lang in languages)
                    DeleteDocumentTemplateLanguage(documentTemplateInfo, lang, new string[0]);
                
                using (new DocumentArchiveFileImpersonationContext())
                {
                    File.Delete(path);                    
                }
            }
            else
                path = "";

            return new ReturnInfo() { Success = true, ExternalReference=path };
        }

        /// <summary>
        /// Delete a specific language variation from the document template
        /// </summary>
        /// <param name="documentTemplateInfo">Fully populated document template metadata used to identity the template.</param>
        /// <param name="languageCode">The language variation to delete</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo DeleteDocumentTemplateLanguage(IDocumentTemplateInfo documentTemplateInfo, string languageCode,
                                                  string[] allowedReturnTypes)

        {
            var invalidFileNameChars = Path.GetInvalidFileNameChars();
            languageCode = invalidFileNameChars.Aggregate(languageCode, (current, ic) => current.Replace(ic, '_'));

            using (new DocumentArchiveFileImpersonationContext())
            {
                string path = _helper.GetDocumentTemplatePath(documentTemplateInfo, languageCode, true);
                bool success = false;

                try
                {
                    File.Delete(path);
                    success = true;
                }
                catch (Exception ex)
                {
                    SoLogger.LogWarning(ex);                    
                }

                return new ReturnInfo
                {
                    Success = success
                };
            }
        }
    }

}
