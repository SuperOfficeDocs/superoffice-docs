' Generated version information
' Machine: DEV-CHRISTIAN8
' Branch:  Feature
' Label:  Christian

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices


<Assembly: AssemblyProduct("SuperOffice 7")> 
<Assembly: AssemblyConfiguration("SuperOffice 7.5")> 
<Assembly: AssemblyCopyright("Copyright © SuperOffice AS 1990 - 2014")> 
<Assembly: AssemblyCompany("SuperOffice AS")> 
<Assembly: AssemblyTrademark("SuperOffice")> 

<Assembly: AssemblyVersion("7.9.5300.2000")> 
<Assembly: AssemblyFileVersion("7.9.5365.1600")> 

