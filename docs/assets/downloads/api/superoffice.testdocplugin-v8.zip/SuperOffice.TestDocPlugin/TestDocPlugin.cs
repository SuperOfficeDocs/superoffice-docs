﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using SuperOffice.CRM.Documents;
using System.IO;

namespace SuperOffice.TestDocPlugin
{
    /// <summary>
    /// This is a test and example of how to implement a document plugin.
    /// Documents are stored in a folder specified in the CONFIG file.
    /// <para/>
    /// This Test Doc Plugin has doc plugin id = 123.
    /// <para/>
    /// The plugin creates files in "C:\TestDoc\Documents" named "glops docid-123.docx".
    /// Templates are stored in "C:\TestDoc\Templates" folder.
    /// <para/>
    /// Checking in and out are handled using a ".lock" file that contains the name of the user who locked the file.
    /// Delete the file to revert the lock.
    /// <para/>
    /// Versions are created when checking in, by making  copies of the file as "glops docid-123 v1.docx" and "glops docid-123 v2.docx" and so on.
    /// </summary>
    /// <example>
    /// <code>
    ///  &lt;SuperOffice&gt;
    ///    &lt;Documents&gt;
    ///     &lt;add key="TestDocPlugin.Path" value="c:\testDoc" /&gt;
    ///     &lt;add key="TestDocPlugin.CanCreateDocumentTemplates" value="true" /&gt;
    ///     &lt;add key="TestDocPlugin.CanLock" value="true" /&gt;
    ///     &lt;add key="TestDocPlugin.CanVersion" value="true" /&gt;
    ///     &lt;add key="TestDocPlugin.CanCommands" value="true" /&gt;
    ///    &lt;/Documents&gt;
    ///  &lt;/SuperOffice&gt;
    /// </code>
    /// </example>
    [DocumentPlugin2("Test Doc Plugin", 123)]
    public class TestDocPlugin : SuperOffice.CRM.Documents.IDocumentPlugin2
    {
        private SuperOffice.CRM.IConfiguration _config;

        public static bool OverrideCanVersion = false;
        public static bool OverrideCanLock = false;
        public static bool OverrideCanCommands = false;

        private void Log(string msg)
        {
#if DEBUG
            msg = msg.Replace("\\", "/");
            System.Diagnostics.Debug.WriteLine(msg);
            SuperOffice.Diagnostics.SoLogger.LogInformation(GetType(), msg, "", true);
#endif
        }
        /// <summary>
        /// Constructor - receives 
        /// </summary>
        public TestDocPlugin(SuperOffice.CRM.IConfiguration config)
        {
            Log("TestDocPlugin ctor");
            _config = config;
            Log("TestDocPlugin rootpath = " + RootPath);
            EnsurePathsExist();
            Log("TestDocPlugin ctor done");
        }

        #region Config Settings

        /// <summary>
        /// Root path for archives and templates
        /// </summary>
        /// <example>
        /// <code>
        ///  &lt;SuperOffice&gt;
        ///    &lt;Documents&gt;
        ///     &lt;add key="TestDocPlugin.Path" value="c:\testDoc" /&gt;
        ///    &lt;/Documents&gt;
        ///  &lt;/SuperOffice&gt;
        /// </code>
        /// </example>
        public string RootPath
        {
            get
            {
                string s = _config.GetConfigString("SuperOffice/Documents/TestDocPlugin.Path") ?? "c:\\testDoc";
                return s;
            }
        }

        /// <summary>
        /// Can this plugin create document templates?
        /// </summary>
        /// <example>
        /// <code>
        ///  &lt;SuperOffice&gt;
        ///    &lt;Documents&gt;
        ///     &lt;add key="TestDocPlugin.CanCreateDocumentTemplates" value="true" /&gt;
        ///    &lt;/Documents&gt;
        ///  &lt;/SuperOffice&gt;
        /// </code>
        /// </example>
        public bool CanCreateDocumentTemplates
        {
            get
            {
                bool res = false;
                res = _config.GetConfigBool("SuperOffice/Documents/TestDocPlugin.CanCreateDocumentTemplates");
                return res;
            }
        }

        /// <summary>
        /// Can this plugin store multiple versions of documents?
        /// </summary>
        /// <example>
        /// <code>
        ///  &lt;SuperOffice&gt;
        ///    &lt;Documents&gt;
        ///     &lt;add key="TestDocPlugin.CanVersion" value="true" /&gt;
        ///    &lt;/Documents&gt;
        ///  &lt;/SuperOffice&gt;
        /// </code>
        /// </example>
        public bool CanVersion
        {
            get
            {
                bool res = false;
                res = _config.GetConfigBool("SuperOffice/Documents/TestDocPlugin.CanVersion");
                return res || OverrideCanVersion;
            }
        }


        /// <summary>
        /// Can this plugin lock documents (check-in and check-out)?
        /// </summary>
        /// <example>
        /// <code>
        ///  &lt;SuperOffice&gt;
        ///    &lt;Documents&gt;
        ///     &lt;add key="TestDocPlugin.CanLock" value="true" /&gt;
        ///    &lt;/Documents&gt;
        ///  &lt;/SuperOffice&gt;
        /// </code>
        /// </example>
        public bool CanLock
        {
            get
            {
                bool res = false;
                res = _config.GetConfigBool("SuperOffice/Documents/TestDocPlugin.CanVersion");
                return res || OverrideCanLock;
            }
        }


        /// <summary>
        /// Can this plugin Add custom commands?
        /// </summary>
        /// <example>
        /// <code>
        ///  &lt;SuperOffice&gt;
        ///    &lt;Documents&gt;
        ///      &lt;add key="TestDocPlugin.CanCommands" value="true" /&gt;
        ///    &lt;/Documents&gt;
        ///  &lt;/SuperOffice&gt;
        /// </code>
        /// </example>
        public bool CanCommands
        {
            get
            {
                bool res = false;
                res = _config.GetConfigBool("SuperOffice/Documents/TestDocPlugin.CanCommands");
                //string s = ConfigurationManager.AppSettings.Get("TestDocPlugin.CanCommands") ?? "";
                //bool.TryParse(s, out res);
                return res || OverrideCanCommands;
            }
        }

#endregion

        private string GetPath(CRM.IDocumentInfo doc )
        {
            string name = doc.ExternalReference;
            if (string.IsNullOrEmpty(name))
                name = "blank";
            string path = Path.Combine(RootPath, "Documents", name);
            return path;
        }

        private string GetPath(CRM.IDocumentInfo doc, string version)
        {
            if (string.IsNullOrEmpty(version))
                return GetPath(doc);

            string name = Path.GetFileNameWithoutExtension(doc.ExternalReference);
            string ext = Path.GetExtension(doc.ExternalReference);
            string path = Path.Combine(RootPath, "Documents", name + " v" + version + ext);
            return path;
        }

        private string GetPath(CRM.IDocumentTemplateInfo doc)
        {
            string path = Path.Combine(RootPath, "Templates", doc.ExternalReference);
            return path;
        }

        private string GetPath(CRM.IDocumentTemplateInfo doc, string langCode)
        {
            string name = Path.GetFileNameWithoutExtension(doc.ExternalReference);
            string ext = Path.GetExtension(doc.ExternalReference);
            string path = Path.Combine(RootPath, "Templates", name + langCode + ext);
            return path;
        }

        private void EnsurePathsExist()
        {
            string path = RootPath;
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            path = Path.Combine(RootPath, "Templates");
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            path = Path.Combine(RootPath, "Documents");
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        }

        public Dictionary<string, string> GetPluginCapabilities()
        {
            Log("TestDocPlugin GetPluginCapabilites");
            EnsurePathsExist();

            var capabilities = new Dictionary<string, string>();
            capabilities[Constants.Capabilities.CanCreateDocumentTemplates] = CanCreateDocumentTemplates.ToString();
            capabilities[Constants.Capabilities.Versioning] = CanVersion.ToString();
            capabilities[Constants.Capabilities.Locking] = CanLock.ToString();
            capabilities[Constants.Capabilities.FastVersionList] = CanVersion.ToString();
            capabilities[Constants.Capabilities.FastLockStatus] = CanLock.ToString();
            capabilities[Constants.Capabilities.FastExists] = true.ToString();
            
            return capabilities;
        }

        public Dictionary<string, string> GetDocumentProperties(CRM.IDocumentInfo documentInfo, string[] requestedProperties)
        {
            Log("TestDocPlugin GetDocumentProperties");
            string path = GetPath(documentInfo);
            var props = new Dictionary<string, string>();
            foreach (string prop in requestedProperties)
                props[prop] = "";
            props[Constants.Properties.HasLocking] = CanLock.ToString();
            props[Constants.Properties.HasVersioning] = CanVersion.ToString();
            if( File.Exists(path) )
                props[Constants.Properties.LastModified] = SuperOffice.CRM.Globalization.CultureDataFormatter.Encode( File.GetLastWriteTime(path) );
            props[Constants.Properties.PreferredOpen] = Constants.Values.Stream;
            return props;
        }

        public CommandInfo[] GetDocumentCommands(CRM.IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            Log("TestDocPlugin GetDocumentCommands");
            CommandInfo[] res = null;
            if( CanCommands )
            {
                res = new CommandInfo[3];
                res[0] = new CommandInfo() { DisplayName = "Picture!", Name = "P", DisplayTooltip = "Convert into picture", IconHint = "hint", ReturnType = CRM.ReturnType.URL };
                res[1] = new CommandInfo() { DisplayName = "Text!", Name = "T", DisplayTooltip = "Convert into text", IconHint = "", ReturnType = CRM.ReturnType.Message };
                res[2] = new CommandInfo() { DisplayName = "Show!", Name = "S", DisplayTooltip = "Show Contact", IconHint = null, ReturnType = CRM.ReturnType.SoProtocol };
            }
            return res;
        }

        public CRM.ReturnInfo ExecuteDocumentCommand(CRM.IDocumentInfo documentInfo, string versionId, string[] allowedReturnTypes, string command, params string[] additionalData)
        {
            EnsurePathsExist();
            CRM.ReturnInfo res = null;
            if( CanCommands )
            {
                switch( command )
                {
                    case "P": 
                        res = new CRM.ReturnInfo() { Success = true, Type = CRM.ReturnType.URL, Value = "https://www.google.com/search?q={0}&source=lnms&tbm=isch&sa=X".FormatWith(documentInfo.Header) };
                        break;
                    case "T":
                        res = new CRM.ReturnInfo() { Success = true, Type = CRM.ReturnType.Message, Value = "You ran Text! command on '{0}'.".FormatWith(documentInfo.Header) };
                        break;
                    case "S":
                        res = new CRM.ReturnInfo() { Success = true, Type = CRM.ReturnType.SoProtocol, Value = "superoffice:contact.main?contact_id={0}".FormatWith(documentInfo.ContactId) };
                        break;
                    default:
                        res = new CRM.ReturnInfo() { Success = false };
                        break;
                }
            }
            return res;
        }

        public Dictionary<string, string> LoadMetaData(CRM.IDocumentInfo documentInfo)
        {
            return null;
        }

        public void SaveMetaData(CRM.IDocumentInfo incomingInfo, Dictionary<string, string> pluginData)
        {
            // yawn
        }

        public CRM.Documents.VersionInfo LoadVersionInfo(CRM.IDocumentInfo documentInfo, string versionId)
        {
            if (!CanVersion)
                return null;
            string path = GetPath( documentInfo, versionId );
            CRM.Documents.VersionInfo res = null;
            if (File.Exists(path))
            {
                var lastMod = File.GetLastWriteTime(path);
                res = new CRM.Documents.VersionInfo() { VersionId = versionId, ExternalReference = path, DocumentId = documentInfo.DocumentId, CheckedInDate = lastMod, DisplayText = "Ver " + versionId + " " + lastMod.ToShortDateString() };
            }
            return res;
        }

        public void SaveVersionInfo(CRM.IDocumentInfo documentInfo, CRM.Documents.VersionInfo versionInfo)
        {
            // not really gonna happen
        }

        public bool Exists(CRM.IDocumentInfo documentInfo)
        {
            Log("TestDocPlugin Exists");
            string path = GetPath(documentInfo);
            bool res = File.Exists(path);
            return res;
        }

        public long GetLength(CRM.IDocumentInfo documentInfo, string versionId)
        {
            string path = GetPath(documentInfo, versionId);
            if (!File.Exists(path))
                return -1;
            var fi = new FileInfo(path);
            long res = fi.Length;
            return res;
        }

        public CRM.Documents.TemplateInfo SaveDocumentTemplateStream(CRM.IDocumentTemplateInfo templateInfo, System.IO.Stream content, string languageCode)
        {
            Log("TestDocPlugin SaveDocumentTemplateStream");
            EnsurePathsExist();
            TemplateInfo res = new TemplateInfo();
            string path = GetPath(templateInfo, languageCode);
            // implicit checkout of file

            var file = File.OpenWrite(path);
            content.CopyTo(file);
            content.Close();
            file.Close();
            
            res.Name = templateInfo.Name;
            res.PluginId = 123;
            res.Description = templateInfo.Tooltip;
            res.ExternalReference = path;

            return res;
        }

        public System.IO.Stream LoadDocumentTemplateStream(CRM.IDocumentTemplateInfo documentTemplateInfo, string languageCode)
        {
            Log("TestDocPlugin LoadDocumentTemplateStream");
            EnsurePathsExist();
            string path = GetPath(documentTemplateInfo, languageCode);
            // fall back to neutral culture if language specific template not found
            if( ! File.Exists(path) )
                path = GetPath(documentTemplateInfo, "");
            return File.OpenRead(path);
        }

        public string GetTemplateExtension(CRM.IDocumentTemplateInfo documentTemplateInfo)
        {
            Log("TestDocPlugin GetTemplateExtension");
            string path = GetPath(documentTemplateInfo);
            string ext = Path.GetExtension(path);
            return ext;
        }

        public CRM.Documents.TemplateInfo CreateDefaultDocumentTemplate(int documentTypeKey, CRM.IDocumentTemplateInfo documentTemplateInfo)
        {
            Log("TestDocPlugin CreateDefaultDocumentTemplate");
            if (CanCreateDocumentTemplates)
            {
                string path = GetPath(documentTemplateInfo);        // arc\Templates
                string name = documentTemplateInfo.Name ?? "name";
                string ext = "";
                string mime = "";
                switch (documentTypeKey)
                {
                    case 1: ext = ".docx"; mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; break;
                    case 2: ext = ".txt"; mime = "text/plain"; break;
                    case 3: ext = ".jpg"; mime = "image/jpeg"; break;
                }

                var res = new TemplateInfo() {
                        MimeType = mime,
                        PluginId = 123,
                        Name = documentTemplateInfo.Name,
                        ExternalReference = Path.Combine(path, name + ext)
                };

                // Create an empty file
                File.Create(res.ExternalReference).Dispose();

                return res;
            }
            else
                return null;
        }

        public Dictionary<int, string> GetSupportedDocumentTypesForDocumentTemplates()
        {
            var res = new Dictionary<int, string>();
            res[1] = "Word Document";
            res[2] = "Text document";
            res[3] = "Picture";
            return res;
        }

        public Dictionary<string, string> GetDocumentTemplateProperties(CRM.IDocumentTemplateInfo documentTemplateInfo, string[] requestedProperties)
        {
            Log("TestDocPlugin GetDocumentTemplateProperties");
            var props = new Dictionary<string, string>();
            foreach (string prop in requestedProperties)
                props[prop] = "";
            return props;
        }

        public string GetDocumentTemplateUrl(CRM.IDocumentTemplateInfo documentTemplateInfo, bool writeableUrl, string languageCode)
        {
            Log("TestDocPlugin GetDocumentTemplateUrl");
            string path = GetPath(documentTemplateInfo, languageCode);
            Uri uri = new Uri(path);
            return uri.AbsoluteUri; // file:////fileserver/share/dir/file.ext

        }

        public string[] GetDocumentTemplateLanguages(CRM.IDocumentTemplateInfo documentTemplateInfo)
        {
            Log("TestDocPlugin GetDocumentTemplateLanguages");
            string path = GetPath(documentTemplateInfo);
            string dir = Path.GetDirectoryName(path);
            string name = Path.GetFileNameWithoutExtension(path);
            var files = Directory.GetFiles(dir, name + " *");
            List<string> langs = new List<string>();
            foreach(var file in files)
            {
                string n = Path.GetFileNameWithoutExtension(file);
                n = n.Replace(name, "");
                n = n.Trim();
                langs.Add(n);
            }

            return langs.ToArray();
        }

        public CRM.ReturnInfo DeleteDocumentTemplate(CRM.IDocumentTemplateInfo documentTemplateInfo, string[] allowedReturnTypes)
        {
            Log("TestDocPlugin DeleteDocumentTemplate");
            CRM.ReturnInfo res = new CRM.ReturnInfo() { Success = false };
            string path = GetPath(documentTemplateInfo);
            if (File.Exists(path))
            {
                File.Delete(path);
                res.Success = true;
            }
            return res;
        }

        public CRM.ReturnInfo DeleteDocumentTemplateLanguage(CRM.IDocumentTemplateInfo documentTemplateInfo, string languageCode, string[] allowedReturnTypes)
        {
            Log("TestDocPlugin DeleteDocumentTemplateLanguage");
            CRM.ReturnInfo res = new CRM.ReturnInfo() { Success = false };
            string path = GetPath(documentTemplateInfo, languageCode);
            if (File.Exists(path))
            {
                File.Delete(path);
                res.Success = true;
            }
            return res;
        }

        public string CreateDocument(CRM.IDocumentInfo incomingInfo, ref string filename, string[] extraFields, string versionDecription, string[] versionExtraFields)
        {
            Log("TestDocPlugin CreateDocument");
            if( ! string.IsNullOrEmpty(incomingInfo.Name) )
                filename = incomingInfo.Name;
            string name = Path.GetFileNameWithoutExtension(filename);
            string ext = Path.GetExtension(filename);
            string path = GetPath(incomingInfo);
            string dir =  Path.GetDirectoryName(path);

            // modify the filename stored on the document to ensure uniqueness
            filename = name + " docid-" + incomingInfo.DocumentId.ToString() + ext;

            // return full path as extref
            string res = Path.Combine( dir, filename );
            return res;
        }

        public CRM.ReturnInfo SaveDocumentFromStream(CRM.IDocumentInfo incomingInfo, string[] allowedReturnTypes, System.IO.Stream content)
        {
            Log("TestDocPlugin SaveDocumentFromStream");
            EnsurePathsExist();
            CRM.ReturnInfo res = new CRM.ReturnInfo() { Success = false };
            string path = GetPath(incomingInfo);
            // implicit checkout of file
            string currentUser = SoContext.CurrentPrincipal.Associate;
            if( CanLock && GetCheckoutInfo(path) == "" )
                SetCheckoutInfo(path, currentUser);
            if( ! CanLock || CanLock && GetCheckoutInfo(path) == currentUser )
            {
                if (File.Exists(path))
                    File.Delete(path);
                var file = File.Create(path); 
                content.CopyTo( file );
                content.Close();
                file.Close();
                res.Success = true;
                res.ExternalReference = incomingInfo.ExternalReference;
            }
            else
            {
                res.Type = CRM.ReturnType.Message;
                res.Value = "Locked by " + GetCheckoutInfo(path);
            }
            return res;
        }

        public System.IO.Stream LoadDocumentStream(CRM.IDocumentInfo incomingInfo, string versionId)
        {
            Log("TestDocPlugin LoadDocumentStream");
            EnsurePathsExist();
            string path = GetPath(incomingInfo, versionId);
            return File.OpenRead(path);
        }

        public string GetDocumentUrl(CRM.IDocumentInfo incomingInfo, string versionId, bool writeableUrl)
        {
            Log("TestDocPlugin GetDocumentUrl");
            EnsurePathsExist();
            string path = GetPath(incomingInfo, versionId);
            Uri uri = new Uri(path);
            return uri.AbsoluteUri; // file:////fileserver/share/dir/file.ext
        }

        public CRM.ReturnInfo DeleteDocument(CRM.IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            Log("TestDocPlugin DeleteDocument");
            EnsurePathsExist();

            CRM.ReturnInfo res = new CRM.ReturnInfo() { Success = false };
            string path = GetPath(documentInfo);
            if (File.Exists(path))
            {
                if( ! CanLock || CanLock && GetCheckoutInfo(path) == "" )
                {
                    File.Delete(path);
                    res.Success = true;
                }
            }
            return res;
        }

        public string RenameDocument(CRM.IDocumentInfo documentInfo, string suggestedNewName)
        {
            Log("TestDocPlugin RenameDocument - not impl");
            throw new NotImplementedException();
        }

        private bool LockedByOtherProcess(string path )
        {
            // check for file locks
            try
            {
                if (File.Exists(path))
                {
                    // See if Word or something is holding the file open
                    using (FileStream fs = File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                    {
                        fs.Close();
                    }
                }
            }
            catch (Exception)
            {
                return true;
            }
            return false;
        }
        private string GetCheckoutInfo(string path)
        {
            string lockPath = path + ".lock";
            if (LockedByOtherProcess(path))
                return "Other process";
            if (!File.Exists(lockPath) )
                return "";
            string locker = File.ReadAllText(lockPath);
            return locker;
        }

        private void SetCheckoutInfo(string path, string locker)
        {
            string lockPath = path + ".lock";
            if (string.IsNullOrEmpty(locker))
                File.Delete(lockPath);
            else
                File.WriteAllText(lockPath, locker);
        }

        public CRM.Documents.CheckoutInfo GetCheckoutState(CRM.IDocumentInfo documentInfo)
        {
            Log("TestDocPlugin GetCheckoutState");
            var res = new CheckoutInfo() { State = CheckoutState.LockingNotSupported };
            string path = GetPath(documentInfo);
            if( CanLock )
            {
                res.State = CheckoutState.NotCheckedOut;
                string currentUser = SoContext.CurrentPrincipal.Associate;
                string locker = GetCheckoutInfo(path);
                res.Name = locker;
                if (locker == "") 
                    res.State = CheckoutState.NotCheckedOut;
                else
                if (locker == currentUser) 
                    res.State = CheckoutState.CheckedOutOwn;
                else
                    res.State = CheckoutState.CheckedOutOther;
            }
            return res;
        }

        public CRM.ReturnInfo CheckoutDocument(CRM.IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            Log("TestDocPlugin CheckoutDocument");
            var res = new CRM.ReturnInfo() { Success = false };
            if (CanLock)
            {
                string currentUser = SoContext.CurrentPrincipal.Associate;
                string path = GetPath(documentInfo);
                string locker = GetCheckoutInfo(path);
                if (locker == "")
                    res.Success = true;
                else
                    if (locker == currentUser)
                        res.Success = true;
                    else
                        res.Success = false;

                if (res.Success)
                    SetCheckoutInfo(path, currentUser);
                else
                {
                    res.Type = CRM.ReturnType.Message;
                    res.Value = "Checked out by " + locker;
                }
            }
            return res;
        }

        public CRM.ReturnInfo CheckinDocument(CRM.IDocumentInfo documentInfo, string[] allowedReturnTypes, string versionDescription, string[] versionExtraFields)
        {
            Log("TestDocPlugin CheckinDocument");
            var res = new CRM.ReturnInfo() { Success = false };
            if (CanLock)
            {
                string currentUser = SoContext.CurrentPrincipal.Associate;
                string path = GetPath(documentInfo);
                string locker = GetCheckoutInfo(path);
                if (locker == "")
                {
                    res.Success = false;
                    res.Type = CRM.ReturnType.Message;
                    res.Value = "Not checked out";
                }
                else
                    if (locker == currentUser)
                        res.Success = true;
                    else
                    {
                        res.Success = false;
                        res.Type = CRM.ReturnType.Message;
                        res.Value = "Checked out to " + locker;
                    }

                if (res.Success)
                {
                    // find next available ver number
                    int verNum = 1;
                    string verPath = GetPath(documentInfo, verNum.ToString());
                    while( File.Exists(verPath) )
                    {
                        verNum++;
                        verPath = GetPath(documentInfo, verNum.ToString());
                    }
                    File.Copy(path, verPath);
                    SetCheckoutInfo(path, "");

                }
            }
            return res;
        }

        public CRM.ReturnInfo UndoCheckoutDocument(CRM.IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            Log("TestDocPlugin UndoCheckoutDocument");
            var res = new CRM.ReturnInfo() { Success = false };
            if (CanLock)
            {
                string currentUser = SoContext.CurrentPrincipal.Associate;
                string path = GetPath(documentInfo);
                string locker = GetCheckoutInfo(path);
                if (locker == "")
                {
                    res.Success = false;
                    res.Type = CRM.ReturnType.Message;
                    res.Value = "Not checked out";
                }
                else
                    if (locker == currentUser)
                        res.Success = true;
                    else
                    {
                        res.Success = false;
                        res.Type = CRM.ReturnType.Message;
                        res.Value = "Checked out to " + locker;
                    }

                if (res.Success)
                {
                    // find last available ver number
                    int verNum = 1;
                    string verPath = GetPath(documentInfo, verNum.ToString());
                    string lastPath = verPath;
                    while (File.Exists(verPath))
                    {
                        lastPath = verPath;
                        verNum++;
                        verPath = GetPath(documentInfo, verNum.ToString());
                    }
                    // Revert the current to the last check-in
                    File.Copy(lastPath, path);

                    SetCheckoutInfo(path, "");
                }
            }
            return res;
        }

        public CRM.Documents.VersionInfo[] GetVersionList(CRM.IDocumentInfo documentInfo)
        {
            Log("TestDocPlugin GetVersionList");
            var res = new List<VersionInfo>();
            if (CanVersion)
            {
                string path = GetPath(documentInfo, "*");
                string dir = Path.GetDirectoryName(path);
                string wild= Path.GetFileName(path);
                string ext = Path.GetExtension(path);
                string prefix = wild.Substring(0, wild.IndexOf("*"));
                var files = Directory.GetFiles(dir, wild);
                foreach( var file in files)
                {
                    string name = file.Replace( dir, "" );
                    string ver = name.Replace(prefix, "");
                    ver = ver.Replace("\\", "");
                    ver = ver.Replace(ext, "");
                    DateTime lastMod = File.GetLastWriteTime(file);
                    var verInfo = new VersionInfo() { DisplayText = "Ver "+ ver +" " + lastMod.ToShortDateString(), DocumentId = documentInfo.DocumentId, ExternalReference = documentInfo.ExternalReference, VersionId = ver, CheckedInDate = lastMod };
                    res.Add(verInfo);
                }
            }
            return res.ToArray();
        }

        public int GetDocumentIdFromPath( string documentPathAndName )
        {
            return 0;
        }
    }
}
