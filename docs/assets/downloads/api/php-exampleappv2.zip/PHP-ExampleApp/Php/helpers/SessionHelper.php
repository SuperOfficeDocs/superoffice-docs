<?php
include_once(dirname(__FILE__).'/../settings.php');
include_once(dirname(__FILE__).'/ClaimHelper.php');

session_save_path("./tmp");
session_start();

/**
 * SessionHelper short summary.
 *
 * SessionHelper description.
 *
 * @version 1.0
 * @author yanjunl
 */
class SessionHelper {
    
    public static function checkSession(){
        $context = self::getSoContext();
        if(empty($context)){            
            $url = AUTH_URL."?app_id=".APPID;
            header("Location: $url");
        }
    }
    
    public static function setSoContext(SoContext $context){
        $_SESSION["SoContext"] = $context;
    }
    
    public static function getSoContext(){
        return $_SESSION["SoContext"];
    }
    
    public static function resetSoContext(){
        $_SESSION["SoContext"] = null;
    }
}