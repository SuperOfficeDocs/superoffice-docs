<?php
include_once(dirname(__FILE__).'/helpers/UrlHelper.php');

?>
<html>
<head>
    <title>SuperId PHP App</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />    <link href="./css/site.css" rel="stylesheet"/>
</head>
<body>
<div align="center" class="div-content">
    <h2>Welcome to SuperId Demo Application</h2>    
</div>
<div align="center">        
    <?php
    echo "<a href='".UrlHelper::getBaseUrl()."index.php'>Home</a>";
    ?>
</div>
</body>

</html>