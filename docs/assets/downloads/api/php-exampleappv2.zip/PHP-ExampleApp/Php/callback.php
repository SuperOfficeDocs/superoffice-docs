<?php

include_once(dirname(__FILE__).'/helpers/SessionHelper.php');
include_once(dirname(__FILE__).'/helpers/UrlHelper.php');

//data from post

$model = new CallbackModel();
$model->Jwt = $_POST["jwt"];
$model->Saml = $_POST["saml"];

/** 
 * if use SMAL for verification, set ENABLE_SAML = true
 * SMAL only works for php version >= 5.4
 */
/* SMAL is not supported in this version */
if(ENABLE_SAML) {
    //require_once('./lib/SoSAML.php');
    //$data = SoSAML::decode($model->Saml, PUBLIC_CERTIFICATE);
} else {
    require_once "./lib/SoJWT.php";
    $data = SoJWT::decode($model->Jwt, PUBLIC_CERTIFICATE);
}

if($data != null){
    $context = ClaimNames::ConvertToSoContext($data);
    //save context info to session
    SessionHelper::setSoContext($context);
    //redirect to index page
    $url = UrlHelper::getBaseUrl().'index.php';
    header("Location: $url");
}
else {
    $url = UrlHelper::getBaseUrl().'welcome.php';
    header("Location: $url");
}

//echo "<pre>";
//print_r($context);
//echo "</pre>";


?>