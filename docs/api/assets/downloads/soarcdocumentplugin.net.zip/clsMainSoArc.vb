Imports System.io
Imports SODocumentPlugin.Interop

'---------------------------------------------------------------------------------------------------------
' GENERAL COMMENTS
' documentId:
'   For SoArc this is the field documentId in document table.
'   For other archives/plugins this can be the value saved in the field extRef
'   If the field extref have any other value than 0, this value will then be passed
'
' If the plugin will be used by CRM5.web, ADO must be used to get data from the database in most cases.
' But the functions Properties, Open, Edit, Print, GoTravel and HomeComing will never be used by CRM5.web
' so in these functions CRM5 SDK can be used
'
' Defined constants for properties, see documentation for details:
'   PluginProperties:
'       "pluginname"        Name of the plugin, fx "SoArcPlugin"
'       "pluginid"          Unique id for the plugin
'       "usesodocdialog"    Should CRM 5 use the documentdialog when creating new documents. Returns "true" or "false".
'       "supportversioning" Does the documentplugin support versioning of documents? Returns "true" or "false".
'       "supporttravel"     Does the documentplugin support replication of documents for travel? Returns "true" or "false".
'
'   DocumentProperties:
'       "versionlist*"      Returns a list with all versions of the document. * is a unique number.
'                           Means the keys will be "versionlist1", "versionlist2" ...
'       "modifieddate"      Last date/time the document was modified
'       "readonly"          Returns "true" or "false"
'       "command1"          Returns string to use in menus for documents if versioning is supported. Fx "New version" or "Check out to folder..."
'       "command2"          Returns string to use in menus for documents if versioning is supported. Fx "New version" or "Check out to folder..."
'
'   NotifySOProperties:
'       The name of the key is the corresponding field-names in document, appointment and text tables
'       for the changed fields in the SOdocumentdialog:
'       "name"              Document
'       "header"            Subject
'       "our_ref"           Our Ref.:
'       "your_ref"          Your Ref.:
'       "archiveprovider"   May change when Type is changed, if the template has another documentplugin
'       "attention"         Contact
'
'       "contact_id"        Company
'       "person_id"         Contact
'       "project_id"        Project
'       "task_idx"          Type
'       "private"           Visible for
'       "type"              Use as mail merge draft
'       "done"              Completed (a date)
'       "status"            Completed
'
'       "text"              Keywords
'---------------------------------------------------------------------------------------------------------
'{} - 31494822-2372-450b-88EE-E106A2FBE93F
' ProgId = Namespace + class name = SoArcPlugin.clsMainSoArc
<Microsoft.VisualBasic.ComClass("5F24CD28-72C2-4417-8DB5-A050620A1DB5")> _
Public Class clsMainSoArc
    Implements IDocumentInterface, IDocumentInterface2



    ' user language code (US, NO, GE, SW etc) 
    Dim m_Language As String
    ' path to the default temporary storage area, set in Initialize
    Dim m_DefaultTempPath As String
    ' where to locate the SUPEROFFICE.INI file, where our system preferences are found
    Dim m_iniPath As String
    ' where to locate the SOUSER.INI file, where our local preferences are found
    Dim m_userIniPath As String
    ' the connection to the database
    Dim m_adoConnection As OleDb.OleDbConnection ' ADODB.Connection

#If USEANSI = 1 Then
    Private Declare Unicode Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteW" (ByVal hwnd As Integer, ByVal lpszOp As String, ByVal lpszFile As String, ByVal lpszParams As String, ByVal LpszDir As String, ByVal FsShowCmd As Integer) As Integer
    Private Declare Unicode Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringW" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer
    Private Declare Auto Function GetShortPathName Lib "kernel32" Alias "GetShortPathNameW" (ByVal lpszLongPath As String, ByVal lpszShortPath As System.Text.StringBuilder, ByVal cchBuffer As Integer) As Integer
#Else
    Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Integer, ByVal lpszOp As String, ByVal lpszFile As String, ByVal lpszParams As String, ByVal LpszDir As String, ByVal FsShowCmd As Integer) As Integer
    Private Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFileName As String) As Integer
    Private Declare Auto Function GetShortPathName Lib "kernel32" Alias "GetShortPathNameA" (ByVal lpszLongPath As String, ByVal lpszShortPath As System.Text.StringBuilder, ByVal cchBuffer As Integer) As Integer
#End If

    Private Declare Function GetDesktopWindow Lib "user32.dll" () As Integer

    Private Const kLogFileName = "c:\SoArcPlugin.log"

    Private Const MAX_PATH = 255
    Private Const kLocalArchivePath = "Local_Archivepath"
    Private Const kCentralArchivePath = "Archivepath"
    Private Const kLocalTemplatePath = "Local_Templatepath"
    Private Const kCentralTemplatePath = "Templatepath"

#Region " *** Helpers *** "
    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String longPath         Path in Long File Name format
    '
    ' Return:
    '   String                  Path in Short File Name format
    '
    ' Purpose:
    '   1. Get the Short File Name (SFN) path to file given in longPath
    '       SFN paths is on the 8.3 format (MS-DOS)
    '       SFN paths can't have spaces and can only have a limited set of ASCII characters.
    '-----------------------------------------------------------------------------------------------------
    Public Function GetShortFileName(ByVal longPath As String) As String
        Dim shortPath As New System.Text.StringBuilder(1)

        Try
            Dim bufferSize As Integer = GetShortPathName(longPath, shortPath, shortPath.Capacity)
            shortPath.Length = bufferSize + 1
            GetShortPathName(longPath, shortPath, shortPath.Capacity)
            Return shortPath.ToString()
        Catch ex As Exception
            OutputDebugString("GetShorFileName", "Error occurred: Long File Name=" & longPath & ", ErrNumber=" & Err.Number & ", Desc=" & Err.Description)
            Return ""
        End Try
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   N/A
    ' Return:
    '   String                  OfficeWord version, "0" on failure
    '
    ' Purpose:
    '   1. Get Get MS Office Word version
    ' Note:
    '   Avoid creating a WORD COM object every time this function is called
    '-----------------------------------------------------------------------------------------------------
    Private Function GetWordVersion() As String
        Dim wordVer As String = ""

        Dim key As Microsoft.Win32.RegistryKey
        key = My.Computer.Registry.ClassesRoot.OpenSubKey("Word.Application\CurVer")
        If key IsNot Nothing Then
            wordVer = key.GetValue("")  ' returns "Word.Application.12" for Office 2007
            key.Close()
        End If

        wordVer = wordVer.Replace("Word.Application.", "")

        Return wordVer
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   N/A
    ' Return:
    '   Boolean                  True: Office Word 2000 is installed, otherwise False
    '
    ' Purpose:
    '   1. Test if MS Office Word 2000 is installed
    '-----------------------------------------------------------------------------------------------------
    Private Function IsWord2000Installed() As Boolean
        Dim nMajorVersion As Double
        nMajorVersion = Val(GetWordVersion())
        If nMajorVersion = 9 Or nMajorVersion = 0 Then
            Return True
        End If
        Return False
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   Path: The path of the file or program to launch
    '   Verb: Verb to send to ShellExecute
    '
    ' Return:
    '   Integer: 0 on failure to launch. Integer.MaxValue when no error is reported.
    '            Basically emulates ShellExecute's response-code.
    '
    ' Purpose:
    '   Non-blocking launch of office documents to avoid COM deadlocks/race-conditions
    '   with Ribbons or other application using SOApplication objects.
    '   
    '   Will check for the existence of the file, and if it exists, assume that
    '   it can be launched.
    '----------------------------------------------------------------------------------------------------
    Private Function ProcessStart(ByVal Path As String, ByVal Verb As String) As Integer
        Dim result As Boolean
        result = System.IO.File.Exists(Path)

        If (result = True) Then
            Try
                Dim thread As System.Threading.Thread
                thread = New System.Threading.Thread(AddressOf ProcessStartHandler)

                Dim params(2) As String
                params(0) = Path
                params(1) = Verb

                thread.Start(params)

                ' lower or equal to 32 = error
                ProcessStart = Integer.MaxValue ' pre-assume success
            Catch ex As Exception
                OutputDebugString("ProcessStart", "Unable to open document " & Path & " using verb " & Verb & ": " & ex.Message)
                ProcessStart = 0 ' failure
            End Try
        Else
            OutputDebugString("ProcessStart", "Unable to open document " & Path & " using verb " & Verb & ": File does not exist")
            ProcessStart = 0 ' failure
        End If
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   oParams: String-array of length 2. First element path, second verb.
    '
    ' Purpose:
    '   Dispatches a non-blocking launch of office documents in a separate thread 
    '   to avoid COM deadlocks/race-conditions. Verb = edit.
    '   with Ribbons or other application using SOApplication objects.
    '   
    '   Very limited error handling is done. Exceptions are ignored.
    '----------------------------------------------------------------------------------------------------
    Private Sub ProcessStartHandler(ByVal oParams As Object)
        Dim params = CType(oParams, String())
        Dim path As String = params(0)
        Dim verb As String = params(1)

        Dim process As System.Diagnostics.Process
        Dim startInfo As System.Diagnostics.ProcessStartInfo

        Try
            process = New System.Diagnostics.Process()
            startInfo = process.StartInfo
            startInfo.FileName = path
            startInfo.Verb = verb

            process.Start()
        Catch ex As System.ComponentModel.Win32Exception
            ' some installations of Office 2007 does not register
            ' "edit"-handles for all its filetypes. Fallback to "open".
            If verb = "edit" Then
                ProcessStart(path, "open")
            Else
                OutputDebugString("ProcessStartHandler", "Unable to open document " & path & " using verb " & verb & ":" & ex.Message)
            End If
        Catch ex As Exception
            OutputDebugString("ProcessStartHandler", "Unable to open document " & path & " using verb " & verb & ":" & ex.Message)
        End Try
    End Sub

#End Region

#Region " *** SODocumentPlugin *** "


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String adoConnectionString      Information needed to set up the ADO connection
    '   String iniPath                  The path to Superof5.ini
    '   String language                 Which language to use (for errormessages)
    '
    ' Purpose:
    '   Initialize the documentplugin with variables that only have to be set once
    '-----------------------------------------------------------------------------------------------------
    Public Sub Initialize(ByVal adoConnectionString As String, ByVal iniPath As String, ByVal language As String) Implements IDocumentInterface.Initialize
        On Error GoTo errorHandler
        Trace("Initialize", "adoCon=" & adoConnectionString & "   iniPath=" & iniPath)

        ' get the window temp path
        m_DefaultTempPath = System.IO.Path.GetTempPath()

        ' set the global superof.ini path variable
        m_iniPath = iniPath

        m_Language = language

        ' initialize the ADO Connection
        m_adoConnection = New OleDb.OleDbConnection(adoConnectionString)
        m_adoConnection.Open()

        m_userIniPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SuperOffice\SOUSER.INI")
        Return

errorHandler:
        Dim e As String
        e = Err.Description
        OutputDebugString("Initialize", "Error occurred when initilizing SoArcPlugin.")
        OutputDebugString("Initialize", "inipath=" & iniPath & ", language=" & language & ", desc=" & e)

        Dim errorString As String
        If m_DefaultTempPath = "" Then
            ' 15021 should return something like "Could not get path to temporary folder. " in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_TEMP_PATH")
            Err.Raise(1001, "Initialize", errorString)
        ElseIf adoConnectionString = "" Then
            ' 15022 should return something like "Ado connection string is missing. " in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_ADO_CONNECTION_STRING_MISSING")
            Err.Raise(1001, "Initialize", errorString + e)
        Else
            Err.Raise(1001, "Initialize", e)
        End If
    End Sub



    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   Long soDocumentId       The documentId from the document-table (field documentId)
    '   String strTemplate      Path to the template (temporary copy) for the document to be created in SoArc, optional
    '   Boolean bIsNewDoc       True if the document is new and should be opened in editor ( fx drag'n'drop should not be opened ), optional
    '   String strExternalApp   Path to application to use to open the document, optional
    '
    ' Return:
    '   String                  The extRef value, if one is generated. SoArc will not use extRef.
    '
    ' Purpose:
    '   1. Find/create the path we want to store the document in
    '   2. Check if a document with the same name already exists
    '       2b. Rename the new document if it already exists
    '   3. Move/create the file
    '   4. Open the document if it is brand new
    '-----------------------------------------------------------------------------------------------------
    Public Function Create(ByVal soDocumentId As Integer, ByVal strTemplate As String, ByVal bIsNewDoc As Boolean, ByVal strExternalApp As String) As String Implements IDocumentInterface.Create
        Dim Ret As String

        On Error GoTo error_handler

        Trace("Create", "docid=" & soDocumentId & "  template=" & strTemplate & "   isNewDoc=" & bIsNewDoc & "    extApp=" & strExternalApp)

        ' Get the path to the directory where the document should be created,
        ' if the path doesn't exists, it will be created
        Dim dirPath As String
        dirPath = GetCreatePath(Trim(Str(soDocumentId)))
        ' So_Arc don't use the extref field, just return the value so the field won't be written over
        Ret = GetExtRef(Trim(Str(soDocumentId)))
        'SODocumentPlugin_Create = GetExtRef(Trim(Str(soDocumentId)))

        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(Trim(Str(soDocumentId)))
        If Len(fileName) = 0 Then
            ' if the documentrecord doesn't provide a filename, use the one from the template
            Dim pos As Integer
            pos = InStrRev(strTemplate, "\", -1, vbTextCompare)
            If pos > 0 Then
                fileName = Right(strTemplate, Len(strTemplate) - pos)
            Else
                fileName = strTemplate
            End If

            If Not FileExists(dirPath + fileName) Then
                SetFileName(Trim(Str(soDocumentId)), fileName, "")
            End If
        End If

        ' If the directory was created correctly proceed, else raise an exception
        If DirectoryExists(dirPath) Then
            ' If the file already exist, make a new filename by adding a counter before the extension ex: "myfile(2).txt"
            If FileExists(dirPath + fileName) Then
                ' find the last dot, if the document has an extension,
                ' it should be whatever comes after this position
                Dim position As Integer
                position = InStrRev(fileName, ".", -1, vbTextCompare)
                ' if no dot is found, set position to the end of the filename
                If position = 0 Then position = Len(fileName)

                Dim newFileName As String
                newFileName = fileName
                Dim origFileName As String
                origFileName = Left(fileName, position - 1)
                Dim counter As Integer
                counter = 2
                ' Loop until an unique filename is found
                Do While FileExists(dirPath + newFileName)
                    newFileName = origFileName + "(" + Trim(Str(counter)) + ")" + Right(fileName, Len(fileName) - position + 1)
                    counter = counter + 1
                Loop

                ' save the new filename to the documentmodel
                ' an exception is raised in SetFileName if the update fails
                SetFileName(Trim(Str(soDocumentId)), newFileName, fileName)
                fileName = newFileName
            End If

            Dim path As String
            path = dirPath + fileName

            ' If the inparameter template is empty, we don't save an empty document, but raise an exception
            If strTemplate <> "" Then
                FileCopy(strTemplate, path)
            Else
                ' 15000 should return something like "Unable to create the file: " in the correct language
                Dim errorString As String = vbNullString
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CREATE_ERROR")
                Err.Raise(1001, "Create", errorString + GetFileHeader(Trim(Str(soDocumentId))))
            End If
        Else
            ' 15018 should return something like "Unable to create the correct path for the file: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_MAKE_TARGET_FOLDER")
            Err.Raise(1001, "Create", errorString + GetFileHeader(Trim(Str(soDocumentId))))
        End If

        ' If sucessfull so far and inparameter bIsNewDoc is true, open the document ( SoArc opens only when it is a new document)
        If bIsNewDoc Then
            Me.Open(Trim(Str(soDocumentId)), strExternalApp, "", "")
        End If

        Return Ret

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("Create", "Error occurred: docid=" & soDocumentId & ", template=" & strTemplate & ", isnew=" & bIsNewDoc & ", extapp=" & strExternalApp & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '
    ' Purpose:
    '   Delete a document if it exists. Remove readOnly property if neccessary
    '   An exception is raised if the document is not found or an error occurs
    '-----------------------------------------------------------------------------------------------------
    Public Sub Delete(ByVal documentId As String) Implements IDocumentInterface.Delete
        On Error GoTo errorHandler
        Trace("Delete", "docid=" & documentId)
        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)

        ' Get the path of the document
        Dim path As String
        path = GetPath(documentId, fileName) + fileName

        ' check that the file really exists in this path
        ' No errormessage is given, if the path is not found, the record in the database will be deleted.
        ' This will cause the nonexisting file to disappear from SuperOffice.
        If FileExists(path) Then
            ' Change the file attribute to normal, to delete the file
            If (Dir(path, vbReadOnly) = "") Then
                System.IO.File.SetAttributes(path, FileAttributes.Normal)
            End If

            ' delete the file
            Kill(path)
        Else
            ' 15028 should return something like "Could not find the file: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_FILE")
            Err.Raise(1001, "Delete", errorString + path)
        End If

        Exit Sub
errorHandler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("Delete", "Error occurred: docid=" & documentId & ", desc=" & Err.Description)
        Err.Raise(number, source, desc) ' pass it on
        ' Example: if filesystem is readonly, this will catch the error when trying to access it
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId           The documentId from the document-table (for SoArc always field documentId)
    '   String strExternalApp       Path to application to use to open the document
    '
    ' Purpose:
    '   Open the document in the appropriate application for editing.
    '   Which application to use is decided by the filenames extension,
    '   or the provided path for external application.
    '
    ' SODocumentPlugin_Edit will never be used from the CRM5.web, so SuperOffice SDK may be used
    '-----------------------------------------------------------------------------------------------------
    Public Sub Edit(ByVal documentId As String, ByVal strExternalApp As String) Implements IDocumentInterface.Edit
        On Error GoTo error_handler
        Trace("Edit", "docid=" & documentId & "   extapp=" & strExternalApp)

        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)

        ' Get the path of the document from the documentrecord
        Dim path As String

        path = GetPath(documentId, fileName) + fileName
        'For Word 2000, documents must be opened using the Short File Name
        If (True = IsWord2000Installed()) Then
            path = GetShortFileName(path)
        End If

        ' The extension is used to determine type of document dispatch
        Dim extension As String = GetExtension(path)

        ' check that the file really exists in this path, set to empty string if not
        Dim wrongPath As String
        wrongPath = path    ' keep this for errormessage
        If Not FileExists(path) Then
            path = ""
        End If

        Dim soApp As SuperOffice.COM.Application.SOApplication
        Dim shellError As Integer
        ' initialize shellerror to 33 to avoid errormessage when document is an url, htm or similar
        shellError = 33
        Dim guiHandle As Integer
        guiHandle = GetDesktopWindow()

        If path <> "" Then
            ' For extension htm, html and mht, the path is opened in the application(browser) decided by preferences in SuperOffice
            If (extension = "htm" Or extension = "html" Or extension = "mht") Then
                soApp = New SuperOffice.COM.Application.SOApplication
                soApp.ShowUrl(path)
                soApp = Nothing
                ' Extension url is opened in application set in profile
            ElseIf extension = "url" Then
                soApp = New SuperOffice.COM.Application.SOApplication
                Dim entry As String
                entry = New String(" ", MAX_PATH) ' max 255 chars in path
                Dim count As Integer
                count = GetPrivateProfileString("InternetShortcut", "URL", "", entry, MAX_PATH, path)
                entry = Left(entry, count)
                soApp.ShowUrl(entry)
                soApp = Nothing
                ' open document with the external application
            ElseIf strExternalApp <> "" Then
                ' try to open with edit
                shellError = ShellExecute(guiHandle, "edit", strExternalApp, path, vbNullString, 1)
                ' then try with open
                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "open", strExternalApp, path, vbNullString, 1)
                End If
                ' try to open with default application if external application couldn't open
                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "edit", path, vbNullString, vbNullString, 1)
                End If

                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "open", path, vbNullString, vbNullString, 1)
                End If

                ' for office documents, we KNOW they should be editable.
            ElseIf extension = "xls" Or extension = "xlsx" _
                Or extension = "doc" Or extension = "docx" _
                Or extension = "ppt" Or extension = "pptx" _
                Or extension = "rtf" Then
                ' use non-blocking launch/fire and forget
                ' avoids COM-blocking/deadlocks when ribbons are installed
                shellError = ProcessStart(path, "edit")
            ElseIf extension = "pdf" Then
                ' using the "open" or "edit" verb fails with Adobe Reader X v10.1.3 because it does not support it.
                ' use vbNullString as the verb and let the OS figure it out works:
                shellError = ShellExecute(guiHandle, vbNullString, path, vbNullString, vbNullString, vbNormalFocus)

                ' if still a problem, use old strategy that did work with earlier versions.
                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "edit", path, vbNullString, vbNullString, 1)
                End If
                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "open", path, vbNullString, vbNullString, 1)
                End If
            Else
                ' just open it with default application if no external application is provided
                shellError = ShellExecute(guiHandle, "edit", path, vbNullString, vbNullString, 1)
                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "open", path, vbNullString, vbNullString, 1)
                End If
            End If
        End If

        If path = "" Or shellError <= 32 Then
            ' 15002 should return something like "Unable to edit the file: " in the correct language
            Dim errorString As String = ""
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_OPEN_FILE_FOR_CHANGE")
            Err.Raise(1001, "Edit", errorString + wrongPath)
        End If
        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("Edit", "Error occurred: docid=" & documentId & ", extapp=" & strExternalApp & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId        the documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   A Dictionary, as an object, containing an identifing key and value for each property for the document.
    '   If the plugin supports versioning, the versions of the document will be identified with key "versionlist*"
    '   where * is substituted with an identifying number in ascending order, starting with the newest document.
    '
    ' Purpose:
    '   Give all properties for the document, such as versions, readonly, modified date.
    '   Each property has a string as identifier which is used as a key in the dictionary.
    '   Properties as versionlist may have one or more values, but Dictionary craves unique keys
    '----------------------------------------------------------------------------------------------------
    Public Function GetDocumentProperty(ByVal documentId As String) As Object Implements IDocumentInterface.GetDocumentProperty
        On Error GoTo error_handler
        Trace("GetDocumentProperty", "docid=" & documentId)
        Dim dictDocProperty As Scripting.Interop.Dictionary
        dictDocProperty = New Scripting.Interop.Dictionary

        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)
        ' Get the path of the document from the documentrecord
        Dim path As String
        path = GetPath(documentId, fileName) + fileName

        If (Dir(path, vbReadOnly) = "") Then
            dictDocProperty.Add("readonly", "true")
        Else
            dictDocProperty.Add("readonly", "false")
        End If

        Dim modified As String
        modified = GetDateTime(path)
        If modified <> "" Then
            dictDocProperty.Add("modifieddate", modified)
        End If

        ' NB "docexist" is just for the time being. Don't assume other plugins even know about this key.
        If (FileExists(path)) Then
            dictDocProperty.Add("docexist", "true")
        Else
            dictDocProperty.Add("docexist", "false")
        End If

        Return dictDocProperty

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetDocumentProperty", "Error occurred: docid=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId   The documentId from the document-table (for SoArc always field documentId)
    '   String strFilepath  The path to store the filecopy in, if another directory than windowstemp is needed
    '
    ' Return:
    '   String              The path to the copy of the file (default templatepath + filename))
    '
    ' Purpose:
    '   Make a copy of the file pointed to by documentId to the default temp dir
    '-----------------------------------------------------------------------------------------------------
    Public Function GetFileCopy(ByVal documentId As String, ByVal strFilepath As String) As String Implements IDocumentInterface.GetFileCopy
        On Error GoTo error_handler
        Trace("GetFileCopy", "docid=" & documentId & "   filepath=" & strFilepath)
        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)

        ' Get the path of the document from the documentrecord
        Dim path As String
        path = GetPath(documentId, fileName) + fileName

        ' if the file really exists in this path, make a copy to the default temporary path (set in Initialize)
        ' or to the path provided. Create the directory in the provided path, if necessary.
        If FileExists(path) Then
            If Len(strFilepath) = 0 Then
                strFilepath = m_DefaultTempPath
            ElseIf (Dir(strFilepath, vbDirectory) = "") Then
                CreatePath(strFilepath)
            End If

            ' make sure the file does't already exists
            ' if it does, rename our file
            If FileExists(strFilepath + fileName) Then
                Dim ext As String = vbNullString ' file extension
                Dim file As String = vbNullString ' filename
                Dim pos As Integer ' position of the last '.' char
                pos = InStrRev(fileName, ".", , vbTextCompare)
                If pos > 0 Then
                    ext = Right(fileName, Len(fileName) - pos)
                    file = Left(fileName, pos - 1)
                End If

                Dim idx As Integer : idx = 1
                ' Loop until an unique filename is found
                Do While FileExists(strFilepath + fileName)
                    fileName = file & "(" & Trim(Str(idx)) & ")" & "." & ext
                    idx = idx + 1
                Loop
            End If

            FileCopy(path, strFilepath + fileName)
            Return strFilepath + fileName
        Else
            ' 15003 should return something like "Unable to get a copy of the file: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_GET_COPY")
            Err.Raise(1001, "GetFileCopy", errorString + path)

            Return ""
        End If
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetFileCopy", "Error occurred: docid=" & documentId & ", filepath=" & strFilepath & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId   The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   String              The path to the document
    '
    ' Purpose:
    '   Get the path to a document, given its documentId
    '-----------------------------------------------------------------------------------------------------
    Public Function GetPath(ByVal documentId As String) As String Implements IDocumentInterface.GetPath
        On Error GoTo error_handler
        Trace("GetPath", "docId=" & documentId)
        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)

        Dim result As String = GetPath(documentId, fileName) + fileName
        Trace("GetPath", "   path=" & result)

        Return result

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetPath", "Error occurred: docid=" & documentId)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String path   The document path, which should be a valid Windows/UNC-path.
    '
    ' Return:
    '   String        The extension of the file, without a dot. (ie html, not .html)
    '
    ' Purpose:
    '   Get the extension of a document to determine dispatch-type.
    '-----------------------------------------------------------------------------------------------------
    Public Function GetExtension(ByVal path As String) As String
        Dim extension As String
        extension = System.IO.Path.GetExtension(path).ToLower()
        If (extension.Length > 1) Then
            extension = extension.Substring(1)
        End If

        GetExtension = extension
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId           The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   String                      The requested property for the plugin
    '
    ' Purpose:
    '   Give all properties for the plugin, such as pluginid, pluginname, whether versioning and travel is supported...
    '   Each property has a string as identifier which is used as a key in the dictionary.
    '   Properties as version may have one or more values.
    '----------------------------------------------------------------------------------------------------
    Public Function GetPluginProperty(ByVal propertyName As String) As String Implements IDocumentInterface.GetPluginProperty
        On Error GoTo error_handler
        propertyName = LCase(propertyName)
        Trace("GetPluginProperty", "propName=" & propertyName)
        Dim Ret As String = vbNullString

        If propertyName = "pluginid" Then
            Ret = "0"
        ElseIf propertyName = "pluginname" Then
            Ret = "SoArc"
        ElseIf propertyName = "usesodocdialog" Then
            Ret = "true"
        ElseIf propertyName = "supportversion" Then
            Ret = "false"
        ElseIf propertyName = "supporttravel" Then
            Ret = "true"
        End If
        Trace("GetPluginProperty", "    return=" & Ret)
        Return Ret
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetPluginProperty", "Error occurred: propertyname=" & propertyName & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String associateName                        UserId for the user to go on travel
    '   SODocumentPluginLib.IStatus progressStatus  Interface for updating the progressbar for document replication
    '
    ' Purpose:
    '   Called when user goes on travel to copy new and modified files from central to local archive.
    '   Copies the files in directories for current and previous period, with sub-directories,
    '   and files saved directly in the associates directory.
    '   The files must be an exact copy regarding filename, and modified date
    '-----------------------------------------------------------------------------------------------------
    Public Sub GoTravel(ByVal associateName As String, ByVal progressStatus As IStatus) Implements IDocumentInterface.GoTravel
        On Error GoTo error_handler
        Dim sourceDir As String
        Dim targetDir As String
        Dim copyOk As Boolean
        copyOk = True
        Trace("GoTravel", "assoc=" & associateName)

        ' get the archivepaths from superof.ini, and add the "associate dir"
        sourceDir = GetArchivePath(kCentralArchivePath) + associateName + "\"
        targetDir = GetArchivePath(kLocalArchivePath, True) + associateName + "\"

        ' The associates directory is made before the plugin is called.
        ' Make sure the associates directory exists and is made in so_local
        ' this directory contains only subfolders, so it's not counted for the progresstotal
        If VerifyTravelDirectories(sourceDir, targetDir) Then
            ' count files saved directly in the associates directory (C:\55nytravel\So_Local\HH\DivNotater.DOC)
            Dim numFiles As Integer
            numFiles = numFiles + NumberOfFiles(sourceDir, False)

            ' get the period before this
            Dim startDate As Date
            startDate = Now
            ' go back one period
            If Month(startDate) < 8 Then
                startDate = DateAdd("m", -Month(startDate), startDate)
            Else
                startDate = DateAdd("m", -Month(startDate) + 7, startDate)
            End If

            Dim periodDate As Date
            periodDate = startDate

            ' GetPeriod( periodDate ) not only returns fx "2002.2", but also change periodDate to a date in the period nearer todays date
            Dim period As String
            period = GetPeriod(periodDate)
            Do While period <> ""
                numFiles = numFiles + NumberOfFiles(sourceDir + period, True)
                period = GetPeriod(periodDate)
            Loop

            progressStatus.SetTotal(numFiles) ' set total number of steps to iterate through

            ' copy files saved directly in the associates directory
            If Not CopyTravelFiles(sourceDir, targetDir, False, progressStatus) Then
                copyOk = False
            End If

            ' go back to startdate again
            periodDate = startDate
            period = GetPeriod(periodDate)
            Do While period <> ""
                If Not CopyTravelFiles(sourceDir + period, targetDir + period, True, progressStatus) Then
                    copyOk = False
                End If
                period = GetPeriod(periodDate)
            Loop
        Else
            ' If directory don't exist this is no crisis here
        End If

        If Not copyOk Then
            ' 15010 should return something like "Could not copy one or more of the files." in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_COPY_FILES")
            Err.Raise(1001, "Travel", errorString)
        End If
        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GoTravel", "Error occurred: assoc=" & associateName & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String associateName                        UserId for the user to go on travel
    '   SODocumentPluginLib.IStatus progressStatus  Interface for updating the progressbar for document replication
    '
    ' Purpose:
    '   Called when user comes home from travel to copy new and modified files from central to local archive.
    '   Copies the files in directories and subdirectories for current and previous period, or all periods since user left for travel,
    '   and files saved directly in the associates directory.
    '   The files must be an exact copy regarding filename and modified date
    '   first period is from january to july, second from august to december...
    '-----------------------------------------------------------------------------------------------------
    Public Sub HomeComing(ByVal associateName As String, ByVal progressStatus As IStatus) Implements IDocumentInterface.HomeComing
        On Error GoTo error_handler
        Dim sourceDir As String
        Dim targetDir As String
        Dim copyOk As Boolean
        copyOk = True
        Trace("HomeComing", "assoc=" & associateName)

        ' get the archivepaths from superof.ini file, and add the "associate dir"
        sourceDir = GetArchivePath(kLocalArchivePath) + associateName + "\"
        targetDir = GetArchivePath(kCentralArchivePath) + associateName + "\"

        ' no need to do anything if these are the same
        If sourceDir = targetDir Then Exit Sub

        ' Make sure the associates directory exists and is made in so_arc
        ' this directory containes only subfolders, so it's not counted for the progresstotal
        If VerifyTravelDirectories(sourceDir, targetDir) Then
            ' count files saved directly in the associates directory (C:\55nytravel\So_Local\HH\DivNotater.DOC)
            Dim numFiles As Integer
            numFiles = numFiles + NumberOfFiles(sourceDir, False)

            ' Get the date the user left for travel
            Dim periodDate As Date
            Dim orgDate As Date
            orgDate = GetTravelGeneratedTime(associateName)
            periodDate = orgDate
            ' go back one period
            If Month(periodDate) < 8 Then
                periodDate = DateAdd("m", -7, periodDate)
            Else
                periodDate = DateAdd("m", -5, periodDate)
            End If

            ' get the period for the date the user went on travel(performed local update)
            Dim period As String
            period = GetPeriod(periodDate)
            ' count the files to be copied for all periods since user went on travel(minimum this and last period)
            Do While period <> ""
                numFiles = numFiles + NumberOfFiles(sourceDir + period, True)
                period = GetPeriod(periodDate)
            Loop
            ' set the status for the progressbar
            progressStatus.SetTotal(numFiles)

            ' copy files saved directly in the associates directory
            If Not CopyTravelFiles(sourceDir, targetDir, False, progressStatus) Then
                copyOk = False
            End If

            ' get the start date and period again to copy the documents
            periodDate = orgDate
            ' go back one period
            If Month(periodDate) < 8 Then
                periodDate = DateAdd("m", -7, periodDate)
            Else
                periodDate = DateAdd("m", -5, periodDate)
            End If
            period = GetPeriod(periodDate)
            Do While period <> ""
                If Not CopyTravelFiles(sourceDir + period, targetDir + period, True, progressStatus) Then
                    copyOk = False
                End If
                period = GetPeriod(periodDate)
            Loop
        Else
            ' If directory don't exist this is no crisis here
        End If

        If Not copyOk Then
            ' 15010 should return something like "Could not copy one or more of the files." in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_COPY_FILES")
            Err.Raise(1001, "Travel", errorString)
        End If
        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("HomeComing", "Error occurred: assoc=" & associateName & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId           The documentId from the document-table (for SoArc always field documentId)
    '   Object dictFieldValueNew    Dictionary with fieldname and new value for all fields that has been changed
    '                               in the document dialog or otherwise in CRM5
    '   Object dictFieldValueOld    Dictionary with fieldname and old value for all fields that has been changed
    '                               in the document dialog or otherwise in CRM5
    '
    ' Purpose:
    '   Rearchive a document according to changes in the documents properties.
    '   The documentrecord is updated from CRM5.
    '----------------------------------------------------------------------------------------------------
    Public Sub NotifySOProperties(ByVal documentId As String, ByVal dictFieldValueNew As Object, ByVal dictFieldValueOld As Object) Implements IDocumentInterface.NotifySOProperties
        On Error GoTo error_handler
        Err.Clear()
        Trace("NotifySOProperties", "docid=" & documentId)

        Dim dictionaryNew As Scripting.Interop.Dictionary
        dictionaryNew = CType(dictFieldValueNew, Scripting.Interop.Dictionary)

        Dim dictionaryOld As Scripting.Interop.Dictionary
        dictionaryOld = CType(dictFieldValueOld, Scripting.Interop.Dictionary)

        Dim fileName As String
        If dictionaryOld.Exists("name") Then
            fileName = dictionaryOld.Item("name")
        Else
            fileName = GetFileName(documentId)
        End If

        Dim path As String
        path = GetPath(documentId, fileName)

        ' make sure the file exists in the found path and with the old filename
        If FileExists(path + fileName) Then
            ' For So_Arc the filename is the only property that has to be handled by the plugin if the property is changed.
            ' Even though the filename is based on the documents header among other things, filename is not altered if header is.
            If dictionaryNew.Exists("name") Then
                Dim oldpath, newpath As String
                ' rename the document in so_Arc
                oldpath = path + dictionaryOld.Item("name")
                newpath = path + dictionaryNew.Item("name")
                Microsoft.VisualBasic.Rename(oldpath, newpath)
            End If
        Else
            ' 15028 should return something like "Could not find the file: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_FILE")
            Err.Raise(1001, "NotifySOProperties", errorString + path + fileName)
        End If

        ' catch other errors
        If StrComp(Err.Description, "") <> 0 Then
            Err.Raise(1001, "NotifySOProperties", Err.Description)
        End If

        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("NotifySOProperties", "Error occoured: docid=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '   String strExternalApp   Path to application to use to open the document, optional.
    '   String strFilePath      Path/name to file to be opened, optional
    '   String strVersionCommand    The selected command for version handling on this document, optional
    '
    ' Purpose:
    '   Open the document in the appropriate application.
    '   Which application to use is decided by the filenames extension,
    '   or the provided path for external application.
    '   If the plugin supports versioning:
    '   a.  When a document in a versionlist is selected, Open(...) will be called with the documentId
    '       of the main document and selected document-versions path/name as third parameter.
    '   b.  If command to handle/create versions is selected, Open(...) will be called with documentId
    '       of the main document and third parameter empty. strVersionCommand tells which command the user has selected.
    '   c.  When a document is doubleclicked or open is selected, Open(...) will be called with the
    '       documentId of the document and third and fourth parameter empty.
    '
    ' Comment:
    '   SODocumentPlugin_Open will never be used from the CRM5.web,
    '   so SuperOffice SDK is used here to access ShowUrl(...) in the CRM5 windows client
    '   else ADO is used where possible in this function also
    '-----------------------------------------------------------------------------------------------------
    Public Sub Open(ByVal documentId As String, ByVal strExternalApp As String, ByVal strFilepath As String, ByVal strVersionCommand As String) Implements IDocumentInterface.Open
        On Error GoTo error_handler
        Trace("Open", "docid=" & documentId & "  extApp=" & strExternalApp & "  file=" & strFilepath & "   verCommand=" & strVersionCommand)

        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)

        ' Get the path of the document from the documentrecord
        Dim path As String

        path = GetPath(documentId, fileName) + fileName

        'For Office 2000, documents must be opened using the Short File Name
        If (True = IsWord2000Installed()) Then
            path = GetShortFileName(path)
        End If

        ' The extension is used to determine type of document dispatch
        Dim extension As String
        extension = GetExtension(path)

        ' check that the file really exists in this path, set to empty string if not
        Dim wrongPath As String
        wrongPath = path    ' keep this for errormessage
        If Not FileExists(path) Then
            path = ""
        End If

        Dim soApp As SuperOffice.COM.Application.SOApplication
        Dim shellError As Integer
        ' initialize shellerror to 33 to avoid errormessage when document is an url, htm or similar
        shellError = 33
        Dim guiHandle As Integer
        guiHandle = GetDesktopWindow()

        If path <> "" Then
            ' For extension htm, html and mht, the path is opened in the application(browser) decided by preferences in SuperOffice
            If (extension = "htm" Or extension = "html" Or extension = "mht") Then
                soApp = New SuperOffice.COM.Application.SOApplication
                soApp.ShowUrl(path)
                soApp = Nothing
                ' Extension url is opened in application set in profile
            ElseIf extension = "url" Then
                soApp = New SuperOffice.COM.Application.SOApplication
                Dim entry As String
                entry = New String(" ", MAX_PATH) ' max 255 chars in path
                Dim count As Integer
                count = GetPrivateProfileString("InternetShortcut", "URL", "", entry, MAX_PATH, path)
                entry = Left(entry, count)
                soApp.ShowUrl(entry)
                soApp = Nothing
                ' open document with the external application
            ElseIf strExternalApp <> "" Then
                shellError = ShellExecute(guiHandle, "open", strExternalApp, path, vbNullString, 1)
                ' try to open with default application if external application couldn't open
                If shellError <= 32 Then
                    shellError = ShellExecute(guiHandle, "open", path, vbNullString, vbNullString, 1)
                End If
                ' just open it with default application if no external application is provided
            ElseIf extension = "xls" Or extension = "xlsx" _
                Or extension = "doc" Or extension = "docx" _
                Or extension = "ppt" Or extension = "pptx" _
                Or extension = "rtf" Then
                ' use non-blocking launch/fire and forget
                ' avoids COM-blocking/deadlocks when ribbons are installed
                shellError = ProcessStart(path, "open")
            Else
                shellError = ShellExecute(guiHandle, "open", path, vbNullString, vbNullString, 1)
            End If
        End If

        If path = "" Or shellError <= 32 Then
            ' 15006 should return something like "Unable to open the file: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_OPEN_FILE")
            Err.Raise(1001, "Open", errorString & wrongPath)
        End If
        Exit Sub

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("Open", "Error occurred: docid=" & documentId & ", extapp=" & strExternalApp)
        OutputDebugString("Open", "filepath=" & strFilepath & ", versioncmd=" & strVersionCommand & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '   String strExternalApp   Path to application to use to open the document
    '
    ' Purpose:
    '   Print the document with the appropriate application.
    '
    ' SODocumentPlugin_Print will never be used from the CRM5.web, so SuperOffice SDK can be used
    '-----------------------------------------------------------------------------------------------------
    Public Sub Print(ByVal documentId As String, ByVal strExternalApp As String) Implements IDocumentInterface.Print
        On Error GoTo error_handler
        Trace("Print", "docid=" & documentId & "  extApp=" & strExternalApp)

        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)

        ' Get the path of the document from the documentrecord
        Dim path As String
        path = GetPath(documentId, fileName) + fileName

        'For Office 2000, documents must be opened using the Short File Name
        If (True = IsWord2000Installed()) Then
            path = GetShortFileName(path)
        End If

        Dim shellError As Long
        shellError = 0
        Dim guiHandle As Long
        guiHandle = GetDesktopWindow()

        If FileExists(path) Then
            ' if path for external application is provided, try to print with that
            If strExternalApp <> "" Then
                shellError = ShellExecute(guiHandle, "print", strExternalApp, path, vbNullString, 1)
            End If

            ' try with just "open" if external application could not deliver or no such is provided
            If strExternalApp = "" Or shellError <= 32 Then
                shellError = ShellExecute(guiHandle, "print", path, vbNullString, vbNullString, 1)
            End If
        End If

        If shellError <= 32 Then
            ' 15007 should return something like "Unable to print the file: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_PRINT_FILE")
            ' 15023 should return something like "There is no application associated with the given file name extension.\n" in the correct language
            Dim errorString2 As String = vbNullString
            errorString2 = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_NO_APPLICATION_FOR_EXTENSION")

            ' This is especially the case regarding SoMail.exe, extension '.som'
            If shellError = 31 Then
                Err.Raise(1001, "Print", errorString2 + errorString + path)
            Else
                Err.Raise(1001, "Print", errorString + path)
            End If
        End If

        Return

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("Print", "Error occurred: docid=" & documentId & ", extapp=" & strExternalApp & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId    The documentId from the document table (for SoArc always field documentId)
    '
    ' Purpose:
    '   Execute the SODocumentdialog with data for the documentId provided
    '   If another documentdialog is needed, this is the place to initialize and execute it
    '-----------------------------------------------------------------------------------------------------
    Public Sub Properties(ByVal documentId As String) Implements IDocumentInterface.Properties
        On Error GoTo error_handler
        ' SODocumentPlugin_Properties will never be used from the CRM5.web, so SuperOffice SDK can be used
        Dim soApp As SuperOffice.COM.Application.SOApplication
        soApp = New SuperOffice.COM.Application.SOApplication
        ' Display the SODocumentDialog for the document with right documentId
        soApp.SetContext(CLng(documentId), SuperOffice.COM.Application.SOContexts.enCtxDocument)
        soApp = Nothing
        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("Properties", "Error occurred: docid=" & documentId)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId   The documentId from the document-table (for SoArc always field documentId)
    '   String filePath     The path to the document that must be saved
    '
    ' Return:
    '   String              The documentId (value from the extRef-field in documentrecord.
    '
    ' Purpose:
    '   Archive the file from the filepath provided. The documentId provided may be for the main document,
    '   while the document in the filePath is a version.
    '   If so, the createdDate and filename found in the document record is for main document.
    '-----------------------------------------------------------------------------------------------------
    Public Function PutFile(ByVal documentId As String, ByVal filePath As String) As String Implements IDocumentInterface.PutFile
        On Error GoTo error_handler
        Trace("PutFile", "docid=" & documentId & "   filepath=" & filePath)

        ' SoArc don't support versioning, and all files must have a record in document-table
        ' So_Arc don't use the extref field, just return the value so the field won't be written over
        Dim Ret As String = GetExtRef(documentId)

        ' Get the path to the directory where the document should be created,
        ' if the path doesn't exists, it will be created
        Dim dirPath As String
        dirPath = GetCreatePath(documentId)

        ' Get the filename of the document from the documentrecord
        Dim fileName As String
        fileName = GetFileName(documentId)
        If Len(fileName) = 0 Then
            ' if the documentrecord doesn't provide a filename, make one from the files path
            Dim pos As Long
            pos = InStrRev(filePath, "\", -1, vbTextCompare)
            If pos > 0 Then
                fileName = Right(filePath, Len(filePath) - pos)
            Else
                fileName = filePath
            End If

            If Not FileExists(dirPath + fileName) Then
                SetFileName(documentId, fileName, "")
            End If
        End If

        ' If the directory was created correctly proceed, else raise an exception
        If DirectoryExists(dirPath) Then
            Dim path As String
            path = dirPath + fileName

            ' If the inparameter template is empty, we don't save an empty document, but raise an exception
            ' Only copy the document if the "new" is newer
            If filePath <> "" Then
                FileCopy(filePath, path)
            Else
                ' 15000 should return something like "Unable to create the file: " in the correct language
                Dim errorString As String = vbNullString
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CREATE_ERROR")
                Err.Raise(1001, "PutFile", errorString + GetFileHeader(documentId))
            End If
        Else
            Dim errorString As String = vbNullString
            ' 15018 should return something like "Unable to create the correct path for the file: " in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_CREATE_PATH")
            Err.Raise(1001, "PutFile", errorString + GetFileHeader(documentId))
        End If

        Return Ret
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("PutFile", "Error occurred: docid=" & documentId & ", filepath=" & filePath & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on

    End Function


    '----------------------------------------------------------------------------------------------------
    ' Purpose:
    '   Ensure that the documentplugin is properly shut down, and no loose ends is open
    '-----------------------------------------------------------------------------------------------------
    Public Sub ShutDown() Implements IDocumentInterface.ShutDown
        On Error GoTo error_handler
        Trace("Shutdown", "Closing so_arc plugin")

        m_adoConnection.Close()
        m_adoConnection = Nothing
        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("ShutDown", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub
#End Region

#Region "*** IDocumentInterface2 ***"

    ' 
    '----------------------------------------------------------------------------------------------------
    ' Parameters:   
    '   String              A path to a document somewhere on a disk somewhere.
    '           
    ' Return:
    '   Integer             Return the document id that matches the path, if we recognize the path.
    '
    ' Purpose:
    '   Used when the Office Ribbon is trying to figure out if the document is already archived or not.
    '-----------------------------------------------------------------------------------------------------
    Public Function GetDocumentIdFromPath(ByVal filePath As String) As Integer _
        Implements IDocumentInterface2.GetDocumentIdFromPath

        If String.IsNullOrEmpty(filePath) Then Return 0

        On Error GoTo error_handler

        ' filepath = \\server\path\so_arc\user\year.x\foobar.doc
        '          = x:\path\so_arc\user\year.x\foobar.doc

        Dim counter As Int32 = 2
        Dim soarc As String
        soarc = GetArchivePath()  ' = \\server\path\so_arc\
        ' first check the default archive, then try all the archive paths 2, 3, 4...9 in order
        While Not String.IsNullOrEmpty(soarc) And Not filePath.StartsWith(soarc, StringComparison.InvariantCultureIgnoreCase) And counter < 10
            soarc = GetArchivePath(kCentralArchivePath + Trim(Str(counter)))
            counter = counter + 1
        End While

        ' Hopefully one of the archive paths matched the starting portion of the file path
        If Not String.IsNullOrEmpty(soarc) And filePath.StartsWith(soarc, StringComparison.InvariantCultureIgnoreCase) Then
            Dim partPath As String
            partPath = filePath.Substring(soarc.Length)     ' = user\year.x\foobar.doc
            Dim parts() As String = partPath.Split("\\")
            Dim assocId As Integer
            assocId = GetAssociateIdFromName(parts(0))
            If (assocId > 0) Then
                Dim yearParts() As String
                yearParts = parts(1).Split(".")
                Dim year, period As Integer
                Integer.TryParse(yearParts(0), year)
                Integer.TryParse(yearParts(1), period)

                Dim fromDate, toDate As Date
                If period = 1 Then
                    fromDate = New Date(year, 1, 1)
                    toDate = New Date(year, 8, 1)
                Else
                    fromDate = New Date(year, 8, 1)
                    toDate = New Date(year + 1, 1, 1)
                End If

                Dim docId As Integer
                docId = GetDocumentIdFromFileName(assocId, fromDate, toDate, parts(2))
                Return docId
            End If
        End If

        Return 0
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetDocumentIdFromPath", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '
    ' Return:
    '   String()            List of templates in the archive\TEMPLATE dir.
    '                       e.g. { "letter.doc", "fax.doc", "budget.xls" }
    ' Purpose:
    '   Return a list of template that the admin client can use to populate the template dropdown list.
    '   Note that the name should be recognizable by the GetTemplateFilePath function.
    '-----------------------------------------------------------------------------------------------------
    Public Function GetTemplateNames() As String() _
        Implements IDocumentInterface2.GetTemplateNames
        On Error GoTo error_handler

        Dim soTemplatesDir As String
        soTemplatesDir = GetArchiveTemplatePath()

        If Not DirectoryExists(soTemplatesDir) Then
            Dim empty(0) As String
            Return empty
        End If

        Dim files As String() = Directory.GetFiles(soTemplatesDir, "*")
        ' files(0) = c:\so_arc\template\letter.docx
        ' files(1) = c:\so_arc\template\etc etc.etc

        ' strip off the leading path, leaving only the file names
        Dim i As Integer
        For i = 0 To files.Length - 1
            files(i) = Path.GetFileName(files(i))
        Next

        ' files(0) = letter.docx, etc
        ' files(1) = etc etc.etc

        Return files

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("ShutDown", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String templateName   The name of the template as seen from GetTemplates()
    '                         e.g.  "letter.doc"
    ' Return:
    '   String                The path to the template to use, or NULL if the template name is not recognized
    '                         e.g. "\\server\so_arc\template\US\letter.doc"
    ' Purpose:
    '   Return a path to a template that SOCRM can make a copy of and use to do template-var substitution.
    '-----------------------------------------------------------------------------------------------------
    Function GetTemplateFilePath(ByVal templateName As String) As String _
        Implements IDocumentInterface2.GetTemplateFilePath
        On Error GoTo error_handler

        Dim soTemplatesDir, templatePath As String
        soTemplatesDir = GetArchiveTemplatePath()
        templatePath = Path.Combine(soTemplatesDir, templateName)

        ' first see if the template exists in TEMPLATE folder
        If Not File.Exists(templatePath) Then
            Return ""
        End If

        ' ok - now let's see if we have a template in the preferred language
        Dim lang As String
        lang = GetUserPref("System", "PreferDocLanguage")
        If Not String.IsNullOrEmpty(lang) Then
            templatePath = Path.Combine(Path.Combine(soTemplatesDir, lang), templateName)
            If File.Exists(templatePath) Then
                Return templatePath
            End If
        End If

        ' let's see if we have a template in the current UI language
        templatePath = Path.Combine(Path.Combine(soTemplatesDir, m_Language), templateName)
        If File.Exists(templatePath) Then
            Return templatePath
        End If

        ' ok - default to standard template - we know it exists, because we checked earlier...
        templatePath = Path.Combine(soTemplatesDir, templateName)
        Return templatePath

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("ShutDown", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function
#End Region

#Region " *** Support methods *** "
    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String source           Path to source directory
    '   String target           Path to target directory
    '
    ' Return:
    '   Boolean                 true = the file was copied successfully
    '
    ' Purpose:
    '   Copy a file and handle any errors by returning false
    '-----------------------------------------------------------------------------------------------------
    Private Function CopyTheFile(ByRef source As String, ByRef target As String) As Boolean
        On Error GoTo errorHandler
        FileCopy(source, target)
        Return True
errorHandler:
        OutputDebugString("CopyTheFile", "Error occurred: src=" & source & ", target=" & target & ", desc=" & Err.Description)
        CopyTheFile = False
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String source                               Path to sourcedirectory
    '   String target                               Path to targetdirectory
    '   Boolean copySubDir                          Tells if subdirectories in sourcedirectory should be copied
    '   SODocumentPluginLib.IStatus progressStatus  Interface for updating the progressbar for document replication
    '
    ' Return:
    '   Boolean                                     Was the copying a success?
    '
    ' Purpose:
    '   Copy all files from source to target that is new or modified relative to files already in targetdirectory.
    '   Raise an exception if source don't exist or if target can't be created
    '   Return false if one or more files can't be copied,
    '   even if most files both before and after was copied successfully
    '-----------------------------------------------------------------------------------------------------
    Private Function CopyTravelFiles(ByVal source As String, ByVal target As String, ByVal copySubDir As Boolean, ByVal progressStatus As IStatus) As Boolean
        On Error GoTo error_handler
        ' Initialize the return variable
        Dim bRetVal As Boolean
        bRetVal = True

        ' If sourcetarget exists and targetdirectory is sucessfully created, true is returned, no sourcedirectory gives false
        If VerifyTravelDirectories(source, target) Then
            Dim dirCount As Integer
            dirCount = 0

            ' String array to hold the paths of source directories (the sourcedirectory and subdirectories)
            Dim sourceDirArray() As String
            ReDim Preserve sourceDirArray(1)
            sourceDirArray(dirCount) = source

            ' String array to hold the paths of target directories (the targetdirectory and subdirectories)
            Dim targetDirArray() As String
            ReDim Preserve targetDirArray(1)
            targetDirArray(dirCount) = target
            dirCount = dirCount + 1

            Dim loopCounter As Integer
            loopCounter = 0
            ' UBound returns the number of elements in an array
            Do While sourceDirArray(loopCounter) <> "" And loopCounter < UBound(sourceDirArray)
                ' returns the name of the first file or subdirectory in the directory
                Dim fileName As String
                fileName = Dir(sourceDirArray(loopCounter), vbDirectory)
                ' keeps track of wether the current file should be copied or not
                Dim copyFile As Boolean
                ' Loop through all the files in the directory
                Do Until Len(fileName) = 0
                    copyFile = True

                    ' we don't want to copy files that start with a "~" ( temp files )
                    ' also exclude . and .. ( current and parent dir )
                    If Left(fileName, 1) = "~" Or fileName = "." Or fileName = ".." Then
                        copyFile = False
                    End If

                    ' if subdirectories is to be copied And this filename is to be copied And the filename is an existing directory
                    If copySubDir And copyFile And DirectoryExists(sourceDirArray(loopCounter) + fileName) Then
                        ' keep track of subdirectories in the arrays of paths to directories
                        ReDim Preserve sourceDirArray(UBound(sourceDirArray) + 1)
                        sourceDirArray(dirCount) = sourceDirArray(loopCounter) + fileName + "\"
                        ReDim Preserve targetDirArray(UBound(targetDirArray) + 1)
                        targetDirArray(dirCount) = targetDirArray(loopCounter) + fileName + "\"
                        dirCount = dirCount + 1

                        ' If the targetdirectory don't exist, make it
                        If Not DirectoryExists(targetDirArray(loopCounter) + fileName) Then
                            CreatePath(targetDirArray(loopCounter) + fileName + "\")
                        End If

                        copyFile = False
                        ' if subdirectories is not to be copied And this is an existing directory
                    ElseIf Not copySubDir And DirectoryExists(sourceDirArray(loopCounter) + fileName) Then
                        copyFile = False
                    End If

                    ' check if a file with same name exists in target directory
                    If copyFile And FileExists(targetDirArray(loopCounter) + fileName) Then
                        ' check if the modified date is identical, if not so the file will be copied
                        If (GetDateTime(sourceDirArray(loopCounter) + fileName) <= GetDateTime(targetDirArray(loopCounter) + fileName)) Then
                            copyFile = False
                        End If
                    End If

                    ' If no tests have said otherwise, copy the file
                    If copyFile Then
                        progressStatus.UpdateStatus(1, fileName) ' send status back to CRM 5
                        ' do not update the return value if we already have a failed copy
                        IIf(bRetVal, bRetVal = CopyTheFile(sourceDirArray(loopCounter) + fileName, targetDirArray(loopCounter) + fileName), CopyTheFile(sourceDirArray(loopCounter) + fileName, targetDirArray(loopCounter) + fileName))
                    End If

                    ' use Dir() to get the next file in the directory,
                    ' Dir(...) can not be used for other purposes in the loop (Dir looses track of which file to get next)
                    fileName = Dir()
                Loop
                loopCounter = loopCounter + 1
            Loop
        Else
            ' Do nothing, sourcedirectory we supposed were there didn't exist
        End If  'VerifyTravelDirectories

        CopyTravelFiles = bRetVal ' will be false if an error occures during processing
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim src : src = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("CopyTravelFiles", "Error occurred: src=" & source & ", target=" & target & ", copysub=" & copySubDir & ", desc=" & desc)
        Err.Raise(number, src, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String path  path to be created
    '
    ' Purpose:
    '   Create the path provided if it doesn't exist
    '-----------------------------------------------------------------------------------------------------
    Private Sub CreatePath(ByVal path As String)
        On Error GoTo error_handler
        If Not Right(path, 1) = "\" Then path = path + "\"

        ' check if the directory already exist
        ' get the name of the first directory by searching for the trailing "\"
        If Not DirectoryExists(path) Then
            Dim pos As Integer
            pos = InStr(1, path, "\", vbTextCompare)
            pos = InStr(pos + 1, path, "\", vbTextCompare)

            Dim subDir As String
            subDir = Left(path, pos)

            ' if the directory is on another machine,
            ' get the path to the first directory that can be created from the client
            ' for example: \\domino\lotus\so_arc\
            If subDir = "\\" Then
                Dim counter As Integer
                For counter = 1 To 3 Step 1
                    pos = InStr(pos + 1, path, "\", vbTextCompare)
                Next counter
            End If

            ' make one missing directory at a time
            While pos > 0
                subDir = Left(path, pos)
                If Not DirectoryExists(subDir) Then
                    MkDir(subDir)
                End If

                pos = InStr(pos + 1, path, "\", vbTextCompare)
            End While

        Else
            ' the dir already exists, do nothing
        End If
        Exit Sub
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("CreatePath", "Error occurred: path=" & path & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String path     Path to a directory
    '
    ' Return:
    '   Boolean         true = yes the directory exists
    '
    ' Purpose:
    '   Check if a directory exists
    '-----------------------------------------------------------------------------------------------------
    Private Function DirectoryExists(ByVal path As String, Optional ByVal supressError As Boolean = False) As Boolean
        On Error GoTo errorHandler
        If Len(path) > 0 Then
            ' get the attributes and check if it is a diectory or not
            ' GetAttr will fail if the path is invalid
            Return ((GetAttr(path) And vbDirectory) = vbDirectory)
        End If

        Return False
errorHandler:
        If Not supressError Then
            OutputDebugString("DirectoryExists", "Error occurred: path=" & path & ", desc=" & Err.Description)
        End If
        DirectoryExists = False
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String path     Path to a file
    '
    ' Return:
    '   Boolean         true = yes the file exists
    '
    ' Purpose:
    '   Check if a file exists
    '-----------------------------------------------------------------------------------------------------
    Private Function FileExists(ByVal path As String) As Boolean
        On Error GoTo errorHandler
        If Len(path) > 0 Then
            ' get the attributes and ensure that it isn't a directory
            FileExists = (GetAttr(path) And vbDirectory) = 0
        End If
        Exit Function
errorHandler:
        ' this method is supposed to fail if the file doesn't exist, no need to write to the log file
        ' if an error occurs, this function returns False
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   String                  The associates login name
    '
    ' Purpose:
    '   Get the login name for the associate (central or travel) by using ADO
    '-----------------------------------------------------------------------------------------------------
    Private Function GetAssocLoginName(ByVal documentId As String) As String
        On Error GoTo error_handler

        Dim assocName As String = vbNullString

        Dim sqlStr, sqlStrApp, sqlStrAppAssoc As String
        sqlStr = "SELECT registered_associate_id, appointment_id FROM document WHERE document_id =" + documentId

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr

        Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

        Dim assocId, appointmentId, appAssocId As Integer
        If recordSet.Read Then
            assocId = recordSet.GetInt32(0)
            appointmentId = recordSet.GetInt32(1)
        End If

        recordSet.Close()


        Dim errorString As String = vbNullString
        If assocId <> 0 Then
            ' get the associate_id from the appointment-record
            ' use it if it is different from registered_associate_id in document-record
            sqlStr = "SELECT associate_id FROM appointment WHERE appointment_id =" & appointmentId

            DBCommand.CommandText = sqlStr
            recordSet = DBCommand.ExecuteReader()
            If recordSet.Read Then
                appAssocId = recordSet.GetInt32(0)
            End If

            recordSet.Close()

            If appAssocId <> assocId Then
                assocId = appAssocId
            End If

            sqlStr = "SELECT name FROM associate WHERE associate_id =" & assocId
            DBCommand.CommandText = sqlStr
            recordSet = DBCommand.ExecuteReader()

            If recordSet.Read Then
                assocName = recordSet.GetString(0)
            Else
                ' 15015 should return something like "Could not get associatename for associate with id: " in the correct language
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_USERNAME")
                Err.Raise(1001, "Get associate loginname", errorString + assocId)
            End If

            recordSet.Close()
        Else
            ' 15016 should return something like "Could not get associateid for associate that created document with id: " in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_USERID")
            Err.Raise(1001, "Get associate loginname", errorString + assocId)
        End If

        Return assocName

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetAssocLoginName", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String archive              Name on key used in SuperOf5.ini to sort the settings. Fx. "Archivepath"
    '   Boolean createifnotfound    Default false, that means don't create an archivepath if it is missing
    '
    ' Return:
    '  String                       The archive path, empty if not found, a slash is added at the end, if the string is ot a drive
    '
    ' Purpose:
    '   Get the archivepath. In SoArc it is different on central and travel
    '-----------------------------------------------------------------------------------------------------
    Private Function GetArchivePath(Optional ByVal archive As String = "", Optional ByVal createifnotfound As Boolean = False) As String
        On Error GoTo error_handler
        ' return the Archivepath from superof5.ini, or empty string if not found
        ' if we are on travel, we want to use the local archivepaths
        Dim iniKey As String = ""
        Dim iniPath As String = ""
        If GetDbVariant() > 0 And archive = "" Then
            iniKey = kLocalArchivePath
        ElseIf GetDbVariant() = 0 And archive = "" Then
            iniKey = kCentralArchivePath
        ElseIf archive <> "" Then
            iniKey = archive
        End If

        Dim entry As String
        entry = New String(" ", MAX_PATH) 'String(MAX_PATH, " ") ' max 255 chars in path
        Dim count As Integer

        count = GetPrivateProfileString("DocPlugin_SoArc", iniKey, "", entry, MAX_PATH, m_iniPath)      ' superoffice.ini first
        If count = 0 Then
            entry = New String(" ", MAX_PATH)
            count = GetPrivateProfileString("DocPlugin_SoArc", iniKey, "", entry, MAX_PATH, m_userIniPath)  ' override with souser.ini
        End If

        entry = Left(entry, count)

        If Not DirectoryExists(entry) Then
            If Len(entry) > 0 And createifnotfound Then
                CreatePath(entry)
                ' check in section "SuperOffice" if the archivepath was not found
            Else
                entry = New String(" ", MAX_PATH) ' String(MAX_PATH, " ") ' max 255 chars in path
                count = GetPrivateProfileString("SuperOffice", iniKey, "", entry, MAX_PATH, m_iniPath)            ' original file, can be superoffice.ini or souser.ini
                If count = 0 Then
                    entry = New String(" ", MAX_PATH) ' reset allocated string so there is room for a new one
                    count = GetPrivateProfileString("SuperOffice", iniKey, "", entry, MAX_PATH, m_userIniPath)   ' override with souser.ini in any case, if there's nothing in superoffice.ini
                End If
                entry = Left(entry, count)

                ' do the same here, if the dir doesn't exists, try to create it
                If Len(entry) > 0 And createifnotfound Then
                    CreatePath(entry)
                End If
            End If
        End If

        If Not DirectoryExists(entry) And String.IsNullOrEmpty(archive) Then
            ' 15008 should return something like "Unable to find archivepath" in the correct language
            Dim errorString As String = ""
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_ARCHIVEPATH")
            Err.Raise(1001, "Create", errorString & vbCr & entry)
        End If

        ' if entry is a drive it will always come with an ending slash, fx. m:\, don't add another one!
        If Not Right(entry, 1) = "\" Then
            GetArchivePath = entry + "\"
        Else
            GetArchivePath = entry
        End If
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetArchivePath", "Error occurred: archive=" & archive & ", create=" & createifnotfound & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '
    ' Return:
    '  String                       The template folder path, empty if not found, a slash is added at the end, if the string nis ot a drive
    '
    ' Purpose:
    '   Get the archive template path. In SoArc it is different on central and travel
    '   Superoffice.ini: 
    '     [SuperOffice] TemplatePath=
    '     [SuperOffice] Local_TemplatePath=
    '   Default:   [SuperOffice] ArchivePath or Local_Archivepath + "\TEMPLATE"
    '-----------------------------------------------------------------------------------------------------
    Private Function GetArchiveTemplatePath() As String
        On Error GoTo error_handler
        ' return the Archivepath from superof5.ini, or empty string if not found
        ' if we are on travel, we want to use the local archivepaths
        Dim iniKey As String = ""
        Dim iniPath As String = ""
        If GetDbVariant() > 0 Then
            iniKey = kLocalTemplatePath
        Else
            iniKey = kCentralTemplatePath
        End If

        Dim entry As String
        entry = New String(" ", MAX_PATH) ' max 255 chars in path
        Dim count As Integer

        count = GetPrivateProfileString("SuperOffice", iniKey, "", entry, MAX_PATH, m_iniPath)      ' superoffice.ini first
        If count = 0 Then
            entry = New String(" ", MAX_PATH) ' reset allocated string so there is room for a new one
            count = GetPrivateProfileString("SuperOffice", iniKey, "", entry, MAX_PATH, m_userIniPath)   ' override with souser.ini in any case, if there's nothing in superoffice.ini 
        End If
        entry = Left(entry, count)
        If Not DirectoryExists(entry) Then
            ' infer Template from Archive dir
            entry = Path.Combine(GetArchivePath(), "TEMPLATE")
        End If

        Return entry
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetArchiveTemplatePath", "Error occurred: desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table
    '
    ' Return:
    '   String                  The path where this document will be created
    '
    ' Purpose:
    '   Return the correct path for this document to be created in
    '   example path: \\server\so_arc\ola\2002.1\, c:\SuperOffice\So_Arc\
    '   if the path does not exists, create it
    '-----------------------------------------------------------------------------------------------------
    Private Function GetCreatePath(ByVal documentId As String) As String
        On Error GoTo error_handler
        ' get the base path
        Dim archivePath As String
        archivePath = GetArchivePath("", True)

        ' get the login name for the associate who created the document
        Dim assocName As String
        assocName = GetAssocLoginName(documentId) + "\"

        Dim createdDate As Date
        createdDate = GetFileCreatedDate(documentId)
        ' if for some reason the createddate is not yet set, it will default
        ' to 1970, treat those as new documents with creationdate today
        If Year(createdDate) = 1970 Then
            createdDate = Now
        End If

        Dim createdYear As String
        createdYear = Year(createdDate)
        If Month(createdDate) < 8 Then
            GetCreatePath = archivePath + assocName + createdYear + "." + "1" + "\"
        Else
            GetCreatePath = archivePath + assocName + createdYear + "." + "2" + "\"
        End If

        ' if the path does not exist, create it
        If (Dir(GetCreatePath, vbDirectory) = "") Then
            CreatePath(GetCreatePath)
        End If
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetCreatePath", "Error occurred: desc=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Purpose:
    '   Get the "Date modified" for a file.
    '   If the "Date Modified" is corrupted, error number 5 "Invalid procedure call or argument" is raised
    '   We don't want this to stop the copying of files, if the file have been modified the "Date modified" will be corrected
    '-----------------------------------------------------------------------------------------------------
    Private Function GetDateTime(ByVal fileName As String) As String
        On Error Resume Next
        ' Original code: Format(FileDateTime(fileName), "yyyymmdd hh:mm:ss")
        ' Changed the yyyymmdd => yyyyMMdd (mm => minutes and MM => month
        ' 06.02.2008 Arild Eik 
        GetDateTime = Format(FileDateTime(fileName), "yyyyMMdd hh:mm:ss")
        If Err.Number <> 5 AndAlso Err.Number <> 0 Then
            Err.Raise(Err.Number, Err.Source, Err.Description, Err.HelpFile, Err.HelpContext)
        End If
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String assocLoginName   Login name for the associate on Travel
    '
    ' Return:
    '   assocId                 id for the associate name, or 0 if not found
    '
    ' Purpose:
    '   Get the id of the associate based on the login name
    '-----------------------------------------------------------------------------------------------------
    Private Function GetUserPref(ByVal sectionName As String, ByVal keyName As String) As String
        On Error GoTo error_handler

        Dim v As String = vbNullString
        ' the call to call to SoDatabase.dll fails when we surprisingly get an new instance  instead of the existing
        'v = "US"
        v = SuperOffice.Data.SoPreference.GetString(sectionName, keyName, "")
        Return v

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetAssociateIdFromName", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Return:
    '   String      0 = Central
    '               1 = Travel
    '
    ' Purpose:
    '   Get the database variant (central or travel) by using ADO
    '-----------------------------------------------------------------------------------------------------
    Private Function GetDbVariant() As Integer
        On Error GoTo error_handler
        ' never more than one record in travelcurrent
        Dim sqlStr As String
        sqlStr = "SELECT current_id FROM travelcurrent"

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr

        Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

        Dim currId As String = vbNullString
        If recordSet.Read Then
            currId = recordSet.GetInt32(0).ToString
        Else
            ' 15014 should return something like "Could not get database variant." in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_DATABASE_VARIANT")
            Err.Raise(1001, "Get database variant", errorString)
        End If

        recordSet.Close()

        ' Extract the database variant
        Dim dbVariant As Integer
        dbVariant = 0
        If (currId > 0 And currId < &HFFFFFF And ((currId & &HFFFFFF) <> 0)) Then
            dbVariant = 1
        End If

        GetDbVariant = dbVariant
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetDbVariant", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   String                  Value from the extref field in the document table
    '
    ' Purpose:
    '   Get the reference (extref) of the file with the provided documentId by using ADO
    '-----------------------------------------------------------------------------------------------------
    Private Function GetExtRef(ByVal documentId As String) As String
        On Error GoTo error_handler

        Dim extRef As String = vbNullString
        Dim errorString As String = vbNullString

        ' documentId says "Not Available" if a document linked to an appointment or similar is deleted
        If (IsNumeric(documentId)) Then
            Dim sqlStr As String
            sqlStr = "SELECT extref FROM document WHERE document_id =" + documentId

            Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
            DBCommand.CommandText = sqlStr

            Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

            If recordSet.Read Then
                extRef = recordSet.GetString(0)
            Else
                ' 15027 should return something like "Could not get reference for document with documentid: " in the correct language
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_REFERENCE_FOR_ID")
                Err.Raise(1001, "Get reference", errorString + Trim(documentId))
            End If
            recordSet.Close()
        Else
            ' 15020 should return something like "Could not find a record for the document in the database." in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_DOC_IN_DATABASE")
            Err.Raise(1001, "Get reference", errorString)
        End If

        Return extRef

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetExtRef", "Error occurred: docid=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   Date                    The files created date
    '
    ' Purpose:
    '   Get the created/modified date of the file with the provided documentId by using ADO
    ' ------------------------------------------------------------------------
    Private Function GetFileCreatedDate(ByVal documentId As String) As Date
        On Error GoTo error_handler
        Dim sqlStr As String
        sqlStr = "SELECT registered FROM document WHERE document.document_id =" + documentId

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr

        Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

        Dim regDate As Date
        If recordSet.Read Then
            regDate = recordSet.GetDateTime(0)
        Else
            ' 15013 should return something like "Could not get created date for document with documentid: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_CREATED_DATE_FOR_ID")
            Err.Raise(1001, "Get created date", errorString + Trim(documentId))
        End If

        recordSet.Close()
        Return regDate

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetFileCreatedDate", "Error occurred: docid=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   String                  The files header, if it is empty returns filename
    '
    ' Purpose:
    '   Get the header of the file with the provided documentId by using ADO
    ' ------------------------------------------------------------------------
    Private Function GetFileHeader(ByVal documentId As String) As String
        On Error GoTo error_handler
        Dim sqlStr As String
        sqlStr = "SELECT header, name FROM document WHERE document.document_id =" + documentId

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr

        Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader

        Dim fileHeader As String = vbNullString
        Dim fileName As String = vbNullString
        If recordSet.Read Then
            fileHeader = recordSet.GetString(0)
            fileName = recordSet.GetString(1)
        Else
            ' 15012 should return something like "Could not get the header for document with documentid: " in the correct language
            Dim errorString As String = vbNullString
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_SUBJECT_FOR_ID")
            Err.Raise(1001, "Get header", errorString + Trim(documentId))
        End If

        recordSet.Close()

        If Len(fileHeader) > 0 Then
            Return fileHeader
        Else
            Return fileName
        End If

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetFileHeader", "Error occurred: docid=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '
    ' Return:
    '   String                  Name of the file
    '
    ' Purpose:
    '   Get the name of the file with the provided documentId by using ADO
    '-----------------------------------------------------------------------------------------------------
    Private Function GetFileName(ByVal documentId As String) As String
        On Error GoTo error_handler
        Dim filePath As String = vbNullString
        Dim errorString As String = vbNullString

        ' documentId says "Not Available" if a document linked to an appointment or similar is deleted
        If (IsNumeric(documentId)) Then
            Dim sqlStr As String
            sqlStr = "SELECT name FROM document WHERE document_id =" + documentId

            Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
            DBCommand.CommandText = sqlStr

            Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

            If recordSet.Read Then
                filePath = recordSet.GetString(0)
            Else
                ' 15011 should return something like "Could not get the filename for document with documentid: " in the correct language
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_FILENAME_FOR_ID")
                Err.Raise(1001, "Get filename", errorString + Trim(documentId))
            End If
            recordSet.Close()
        Else
            ' 15020 should return something like "Could not find a record for the document in the database." in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_DOC_IN_DATABASE")
            Err.Raise(1001, "Get filename", errorString)
        End If
        ' if no rows were found, or the name-field returns "" there is something fishy and "" is returned
        Return filePath
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetFileName", "Error occurred: docid=" & documentId & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Purpose:
    '   Return the full path to a CRM 5 log file
    '-----------------------------------------------------------------------------------------------------
    Private Function GetLogFileName() As String
        On Error GoTo error_handler

        Dim soLogFileName As String = ""

        ' Find the SuperOffice program folder by getting info from Registry
        Dim soProgDir As String = Microsoft.Win32.Registry.GetValue(Microsoft.Win32.Registry.CurrentUser.Name & "\Software\SuperOffice\", "ProgDir", "")
        Dim soIniDir As String = Microsoft.Win32.Registry.GetValue(Microsoft.Win32.Registry.CurrentUser.Name & "\Software\SuperOffice\", "IniDir", "")

        ' If SuperOffice program directory is found we can start to read the superof5.ini
        If (Len(soIniDir) > 0) Then
            If (Right(soIniDir, 1) <> "\") Then
                soIniDir = soIniDir & "\"
            End If

            ' Then check if there is an [Error] section in the local SuperOffice.ini file
            Dim sBuffer As String ' buffer containing value read from ini file
            sBuffer = New String(" ", MAX_PATH) ' String(MAX_PATH, " ")
            Dim soIniFileName As String
            soIniFileName = soIniDir & "superoffice.ini"
            Dim bytes As Integer
            bytes = GetPrivateProfileString("Error", "LogPath", "", sBuffer, Len(sBuffer), soIniFileName)
            If bytes = 0 Then
                ' No [Error] section found, get the archivepath and use the default SO log file
                bytes = GetPrivateProfileString("SuperOffice", "ArchivePath", "", sBuffer, Len(sBuffer), soIniFileName)
                If bytes > 0 Then
                    soLogFileName = Left(sBuffer, bytes)
                    If Right(soLogFileName, 1) <> "\" Then
                        soLogFileName = soLogFileName & "\"
                    End If

                    soLogFileName = soLogFileName & "Data\so_log.txt"
                End If
            Else
                soLogFileName = Left(sBuffer, bytes)
            End If
        End If

        ' Finally if no log file name found use the one defined in the constand LogFileName
        If Len(soLogFileName) = 0 Then
            soLogFileName = kLogFileName
        End If

        Return soLogFileName

        Exit Function
error_handler:
        Return kLogFileName
    End Function


    Private Function isTraceEnabled() As Boolean
        Dim soIniDir As String = Microsoft.Win32.Registry.GetValue(Microsoft.Win32.Registry.CurrentUser.Name & "\Software\SuperOffice\", "IniDir", "")

        isTraceEnabled = False
        If (Len(soIniDir) > 0) Then
            If (Right(soIniDir, 1) <> "\") Then
                soIniDir = soIniDir & "\"
            End If

            ' Then check if there is an [Error] section in the local SuperOffice.ini file
            Dim sBuffer As String ' buffer containing value read from ini file
            sBuffer = New String(" ", MAX_PATH) ' String(MAX_PATH, " ")
            Dim soIniFileName As String
            soIniFileName = soIniDir & "superoffice.ini"
            Dim bytes As Integer
            bytes = GetPrivateProfileString("Error", "EnableSoArcLog", "", sBuffer, Len(sBuffer), soIniFileName)
            If bytes > 0 Then
                Dim result As String = Left(sBuffer, bytes)
                result = result.ToLowerInvariant()
                isTraceEnabled = result = "1" Or result = "true" Or result = "yes"
            End If
        End If
    End Function
    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String soDocumentId     The documentId from the document-table (for SoArc always field documentId)
    '   String fileName         Name of the document
    '
    ' Return:
    '   String                  The path to the document (excluding the document filename).
    '                           May be located in SO_ARC2 or SO_ARC3 - not just in main archive.
    '
    ' Purpose:
    '   GetPath returns the path to the directory where the document is/should be stored,
    '   or an empty string if the document was not found
    '   Alternative archivepaths is also tried,
    '   this means the resulting directorypath can not be used for creating new files.
    '   Checks [DocPlugin_SoArc] section for "Archivepath" and "Archivepath2"
    '   Check in section [SuperOffice] in SuperOffice.ini if ArchivePath is not found in [DocPlugin_SoArc]
    '-----------------------------------------------------------------------------------------------------
    Private Function GetPath(ByVal documentId As String, ByVal fileName As String) As String
        On Error GoTo error_handler
        ' if we are on travel, we want to look at the local archivepaths
        Dim iniKey As String
        Dim iniFile As String
        If GetDbVariant() > 0 Then
            iniKey = kLocalArchivePath
        Else
            iniKey = kCentralArchivePath
        End If

        ' build up the correct path for the document
        ' example path: \\server\so_arc\ola\2002.1\
        Dim assocName As String
        assocName = GetAssocLoginName(documentId)

        Dim created As Date
        created = GetFileCreatedDate(documentId)
        If Year(created) = 1970 Then
            created = Now
        End If

        Dim path As String
        Dim createdYear As String
        createdYear = Year(created)
        ' CRM 5 treats the first 7 months as the first period
        ' the next 5 are the second
        If Month(created) < 8 Then
            path = assocName + "\" + createdYear + "." + "1"
        Else
            path = assocName + "\" + createdYear + "." + "2"
        End If

        ' first look in section for SoArc to find the ArchivePath
        ' the string entry is used to hold the path found in superof5.ini, fx. c:\55Ny\so_arc\
        Dim entry As String
        entry = New String(" ", MAX_PATH) ' max 255 chars in path
        Dim count As Integer
        count = GetPrivateProfileString("DocPlugin_SoArc", iniKey, "", entry, MAX_PATH, m_iniPath)      ' superoffice.ini first
        If count = 0 Then
            entry = New String(" ", MAX_PATH)
            count = GetPrivateProfileString("DocPlugin_SoArc", iniKey, "", entry, MAX_PATH, m_userIniPath)  ' override with souser.ini
        End If
        entry = Left(entry, count)

        'the full path to SO_ARC without the filename
        Dim fullPath As String
        fullPath = System.IO.Path.Combine(entry, path) + "\"

        Dim strCounter As String
        Dim counter As Integer
        counter = 1
        ' if Dir(...) returns blank, the file does not exist, look in alternative directories
        Do While Not FileExists(System.IO.Path.Combine(fullPath, fileName))
            counter = counter + 1
            strCounter = Trim(Str(counter))
            entry = New String(" ", MAX_PATH) ' max 255 chars in path
            count = GetPrivateProfileString("DocPlugin_SoArc", iniKey + strCounter, "", entry, MAX_PATH, m_iniPath)
            If count = 0 Then
                entry = New String(" ", MAX_PATH)
                count = GetPrivateProfileString("DocPlugin_SoArc", iniKey + strCounter, "", entry, MAX_PATH, m_userIniPath)  ' check in souser.ini if superoffice.ini is blank
            End If
            ' if count is zero, we most likely didn't find a value for this entry
            If count = 0 Then Exit Do

            entry = Left(entry, count)
            fullPath = System.IO.Path.Combine(entry, path) + "\"
        Loop

        ' Check in section [SuperOffice] in SuperOffice.ini if ArchivePath is not found in [DocPlugin_SoArc]
        counter = 1
        Do While Not FileExists(System.IO.Path.Combine(fullPath, fileName))
            Dim iniKeyName As String = iniKey
            entry = New String(" ", MAX_PATH) ' max 255 chars in path
            If counter = 1 Then
                iniKeyName = iniKey
            ElseIf counter > 1 Then
                strCounter = Trim(Str(counter))
                iniKeyName = iniKey + strCounter
            End If
            count = GetPrivateProfileString("SuperOffice", iniKeyName, "", entry, MAX_PATH, m_iniPath)
            If count = 0 Then
                entry = New String(" ", MAX_PATH)
                count = GetPrivateProfileString("SuperOffice", iniKeyName, "", entry, MAX_PATH, m_userIniPath)  ' check in souser.ini if superoffice.ini is blank
            End If
            counter = counter + 1

            ' if count is zero, we most likely didn't find a value for this entry
            ' make sure an empty string is returned
            If count = 0 Then
                fullPath = ""
                Exit Do
            End If

            entry = Left(entry, count)
            fullPath = System.IO.Path.Combine(entry, path)
        Loop

        ' if entry is a drive it will always come with an ending slash, fx. m:\, don't add another one!
        If fullPath <> "" AndAlso Not Right(fullPath, 1) = "\" Then
            fullPath = fullPath + "\"
        Else
            fullPath = fullPath
        End If

        Trace("getpath", "    docid=" & documentId & " --> path=" & fullPath)
        GetPath = fullPath
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetPath", "Error occurred: docid=" & documentId & ", filename=" & fileName & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   ByRef Date periodFrom       Date for a period to be copied
    '                               The date is updated to the next period
    '                               until it reaches the period for todays date
    ' Purpose:
    '   Convert the date supplied to a string,
    '   formatted to be the name of the directory (30.09.2002 gives "2002.2\") for the dates period
    '-----------------------------------------------------------------------------------------------------
    Private Function GetPeriod(ByRef periodDate As Date) As String
        On Error GoTo error_handler
        Dim Ret As String
        Ret = Trim(Str(Year(periodDate))) & IIf(Month(periodDate) < 8, ".1\", ".2\")

        ' only increase until todays period
        If periodDate > Now Then
            If GetPeriod(Now) <> Ret Then
                Return ""
            End If
        End If

        ' go to next period
        If Month(periodDate) < 8 Then
            periodDate = DateAdd("m", 8 - Month(periodDate), periodDate)
        Else
            periodDate = DateAdd("m", 5, periodDate)
        End If

        Return Ret

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetPeriod", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String assocLoginName   Login name for the associate on Travel
    '
    ' Return:
    '   assocId                 id for the associate name, or 0 if not found
    '
    ' Purpose:
    '   Get the id of the associate based on the login name
    '-----------------------------------------------------------------------------------------------------
    Private Function GetAssociateIdFromName(ByVal assocLoginName As String) As Integer
        On Error GoTo error_handler
        Dim sqlStr As String
        sqlStr = "SELECT associate_id FROM associate WHERE name LIKE '" + assocLoginName + "'"

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr
        Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

        Dim assocId As Integer
        If recordSet.Read Then
            assocId = recordSet.GetInt32(0)
        End If

        recordSet.Close()
        Return assocId

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetAssociateIdFromName", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   int  assocId            Owner of the document
    '   String documentName     Filename for the document
    '
    ' Return:
    '   docId                 id for the document, or 0 if not found
    '
    ' Purpose:
    '   Get the id of the document based on the file name
    '-----------------------------------------------------------------------------------------------------
    Private Function GetDocumentIdFromFileName(ByVal assocId As Integer, ByVal fromDate As Date, ByVal toDate As Date, ByVal filename As String) As Integer
        On Error GoTo error_handler

        Dim sqlStr As String
        sqlStr = String.Format("SELECT document_id FROM document WHERE registered_associate_id  = {0} AND registered >= '{1}' AND registered <= '{2}' AND name LIKE '{3}'", _
                        assocId, fromDate.ToString("yyyy.MM.dd"), toDate.ToString("yyyy.MM.dd"), filename)

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr
        Dim recordSet As OleDb.OleDbDataReader = DBCommand.ExecuteReader()

        Dim docId As Integer
        If recordSet.Read Then
            docId = recordSet.GetInt32(0)
        End If

        recordSet.Close()
        Return docId

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetDocumentIdFromFileName", "Error occurred: " & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String assocLoginName   Login name for the associate on Travel
    '
    ' Return:
    '   Date                    Date the traveldatabase was created (local update) (Generatedtime in table traveller)
    '
    ' Purpose:
    '   Get the date the associate went on travel by using ADO
    '-----------------------------------------------------------------------------------------------------
    Private Function GetTravelGeneratedTime(ByVal assocLoginName As String) As Date
        On Error GoTo error_handler
        Dim sqlStr As String
        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        Dim recordSet As OleDb.OleDbDataReader

        Dim assocId As Integer
        assocId = GetAssociateIdFromName(assocLoginName)

        Dim errorString As String = vbNullString
        Dim generatedTime As Date
        If assocId <> 0 Then
            sqlStr = "SELECT generatedtime FROM traveller WHERE travel_id =" & assocId
            DBCommand.CommandText = sqlStr
            recordSet = DBCommand.ExecuteReader()

            If recordSet.Read And assocId <> 0 Then
                generatedTime = recordSet.GetDateTime(0)
            Else
                ' 15019 should return something like "Could not get date for when associate left for travel." in the correct language
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_FIND_TRAVEL_START_DATE")
                Err.Raise(1001, "Travel", errorString)
            End If
            recordSet.Close()
        End If

        Return generatedTime

error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("GetTravelGeneratedTime", "Error occurred: loginname=" & assocLoginName & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function



    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String sourceDir        Path to the source directory
    '   Boolean copySubDir      If true, files in subDir will be counted
    '
    ' Return:
    '   Long                    Number of files in the directory
    '
    ' Purpose:
    '   Count the number of files in sourceDir and subdirectories
    '-----------------------------------------------------------------------------------------------------
    Private Function NumberOfFiles(ByVal sourceDir As String, ByVal copySubDir As Boolean) As Integer
        On Error GoTo error_handler
        Dim num As Integer
        num = 0

        ' check if source directory exists, exit if not
        If DirectoryExists(sourceDir, True) Then
            ' counter for number of directories
            Dim dirCount As Integer
            dirCount = 0

            ' String array to hold the paths of directories (the sourcedirectory and subdirectories)
            Dim dirArray() As String
            ReDim Preserve dirArray(1)
            dirArray(dirCount) = sourceDir
            dirCount = dirCount + 1

            ' Keep track if this is a file that should be copied or not
            Dim isFile As Boolean

            ' Counter for which directory we are looping through now
            Dim loopCount As Integer
            loopCount = 0
            Dim fileName As String
            ' Loop as long as there are more paths to directories in the array
            Do While dirArray(loopCount) <> "" And loopCount < UBound(dirArray)
                ' returns the name of the first file or subdirectory in the directory
                fileName = Dir(dirArray(loopCount), vbDirectory)
                ' Loop as long as there are more files or directories in the current directory
                Do Until Len(fileName) = 0
                    isFile = True

                    ' we don't want to copy files that start with a "~" ( temp files )
                    ' also exclude . and .. ( current and parent dir )
                    If Left(fileName, 1) = "~" Or (fileName = ".") Or (fileName = "..") Then
                        isFile = False
                    End If

                    ' count subdirectories, actually put name of directory in the end of an array
                    ' so the files and subdirectories can be counted in due order
                    ' but only if the parameter copySubDir says to do so
                    If isFile And copySubDir And DirectoryExists(dirArray(loopCount) + fileName) Then
                        ReDim Preserve dirArray(UBound(dirArray) + 1)
                        dirArray(dirCount) = dirArray(loopCount) + fileName + "\"
                        dirCount = dirCount + 1
                        isFile = False
                    End If

                    ' If no tests have said otherwise, count the file
                    If isFile Then
                        num = num + 1
                    End If

                    ' use Dir() to get the next file in the directory,
                    ' Dir(...) can not be used for other purposes in the loop (Dir looses track of which file to get next)
                    fileName = Dir()
                Loop
                loopCount = loopCount + 1
            Loop

        End If

        NumberOfFiles = num
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("NumberOfFiles", "Error occurred: src=" & sourceDir & ", copysub=" & copySubDir & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Function


    '----------------------------------------------------------------------------------------------------
    ' Purpose:
    '   Write text to the logfile
    '   Logs Date, current prinicipal identity, component, description
    '-----------------------------------------------------------------------------------------------------
    Private Sub OutputDebugString(ByVal iStrSource As String, ByVal iStrDesc As String)
        On Error GoTo error_handler

        Dim logFile As String
        logFile = GetLogFileName()

        Dim name As String
        name = My.User.Name
        If My.User.CurrentPrincipal IsNot Nothing Then
            If My.User.CurrentPrincipal.Identity IsNot Nothing Then
                name = My.User.CurrentPrincipal.Identity.Name
            End If
        End If
        name = String.Format("  {0:-10} ", name)    ' left align and pad out name

        ' note encoding, to be compatible with C++ code writing UTF16 to the same file (SEV-3789)
        Using tw As TextWriter = My.Computer.FileSystem.OpenTextFileWriter(logFile, True, Text.Encoding.Unicode)
            Dim today As String
            ' Original code: today = Format(Now, "yymmdd hh:mm:ss")
            ' 06.02.2008 Arild Eik: Changed the yyyymmdd => yyyyMMdd (mm => minutes and MM => month
            ' 06.02.2008 CM: hh (12 hr clock) --> HH (24 hr clock) 
            today = Format(Now, "yyMMdd HH:mm:ss")
            Dim header As String
            header = "SoArcDocPlugin[" & iStrSource & "]"
            header = String.Format("{0:-36} ", header)
            tw.WriteLine(today & name & header & iStrDesc)
            Debug.Print(header & iStrDesc)
        End Using


error_handler:
        ' oops, something went wrong trying to write to the log file, no need to alert the user about it
        ' MsgBox "An error occurred while writing to the log file: " & Err.Description, vbOKOnly + vbInformation, kDialogTitle
        Err.Clear()
    End Sub

    Private Sub Trace(ByVal source As String, ByVal descr As String)
        On Error GoTo error_handler

        If isTraceEnabled() Then
            OutputDebugString(source, descr)
        End If

error_handler:
        ' oops, something went wrong trying to write to the log file, no need to alert the user about it
        Err.Clear()
    End Sub

    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String documentId       The documentId from the document-table (for SoArc always field documentId)
    '   String newFileName      New filename to be set
    '
    ' Purpose:
    '   Update the documentrecord with the new unique filename
    '   Cast an exception if update fails
    '   Returns nothing
    '-----------------------------------------------------------------------------------------------------
    Private Sub SetFileName(ByVal documentId As String, ByVal newFileName As String, ByVal fileName As String)
        On Error GoTo error_handler

        'Character ' needs to be escaped with \ for ExecuteScalar to handle it
        newFileName = Replace(newFileName, "'", "\'", 1, -1, vbTextCompare)

        Dim sqlStr As String
        sqlStr = "UPDATE document SET name ='" & newFileName & "' WHERE document_id=" + documentId

        Dim DBCommand As OleDb.OleDbCommand = m_adoConnection.CreateCommand
        DBCommand.CommandText = sqlStr

        Dim recordSet As Integer = DBCommand.ExecuteScalar

        Dim errorString As String = vbNullString
        'If recordSet.ActiveConnection.Errors.count > 0 Then
        If recordSet = 0 Then
            ' 15017 should return something like "Could not save an unique filename: " in the correct language
            errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_SAVE_UNIQUE_FILENAME")
            Err.Raise(1001, "Create", errorString + newFileName)
        End If

        'recordSet.Close()

        Return
error_handler:
        Dim number : number = Err.Number
        Dim source : source = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("SetFileName", "Error occurred: docid=" & documentId & ", newfile=" & newFileName & ", file=" & fileName & ", desc=" & desc)
        Err.Raise(number, source, desc) ' pass it on
    End Sub


    '----------------------------------------------------------------------------------------------------
    ' Parameters:
    '   String source    Path to sourcedirectory
    '   String target    Path to targetdirectory
    '
    ' Return:
    '   Boolean          True if sourcedirectory exists and targetdirectory existed or was made successfully
    '
    ' Purpose:
    '   Check the source and target directories before copying documents
    '   Raise an exception if source don't exist or if target can't be created
    '-----------------------------------------------------------------------------------------------------
    Private Function VerifyTravelDirectories(ByVal source As String, ByVal target As String) As Boolean
        On Error GoTo error_handler
        ' used to get the correct error message from the resource manager
        Dim errorString As String = vbNullString

        ' check if source directory exists, return false if not
        If DirectoryExists(source, True) Then
            ' If the targetdirectory don't exist, make it
            If Not DirectoryExists(target, True) Then
                CreatePath(target)
            End If

            ' check if the target directory was created, throw an exception and exit if not
            If Not DirectoryExists(target) Then
                ' 15005 should return something like "Could not locate or create target directory: " in the correct language
                errorString = SuperOffice.Globalization.ResourceManager.GetString("SR_DOCPLUGIN_CANNOT_MAKE_TARGET_FOLDER")
                Err.Raise(1001, "Travel", errorString + target)
            End If

            ' If no exception is raised, return true
            Return True
        Else
            Return False
        End If
        Exit Function
error_handler:
        Dim number : number = Err.Number
        Dim src : src = Err.Source
        Dim desc : desc = Err.Description
        OutputDebugString("VerifyTravelDirectories", "Error occurred: src=" & source & ", target=" & target & ", desc=" & desc)
        Err.Raise(number, src, desc) ' pass it on
    End Function
#End Region
End Class
