﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SuperOffice SoArcDocumentPlugin")> 
<Assembly: AssemblyDescription("SuperOffice Document Archive access")> 



<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("3535bc2b-eaa5-47e1-b8df-49ef1763d5df")> 



