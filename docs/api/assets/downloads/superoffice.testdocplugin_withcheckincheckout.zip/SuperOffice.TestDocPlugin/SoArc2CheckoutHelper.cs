﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SuperOffice.CRM.Rows;
using SuperOffice.Diagnostics;
using SuperOffice.Exceptions;
using SuperOffice.Security.Util;

namespace SuperOffice.CRM.Documents
{
    /// <summary>
    /// Class for helping with locking/checkout functionality
    /// </summary>
    public class SoArc2CheckoutHelper
    {
        public const string LockedFolderName = "locked";
        private readonly ICheckinFileOperations _fileOps;
        public SoArc2CheckoutHelper(ICheckinFileOperations fileOps)
        {
            _fileOps = fileOps;
        }

        /// <summary>
        /// Check-out the document. This will copy the current document to the locked folder. 
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <param name="associateId"></param>
        /// <returns>The path to the locked document.</returns>
        public string CheckoutDocument(IDocumentInfo documentInfo, int associateId)
        {
            var checkoutData = new CheckoutData
            {
                AssociateId = associateId,
                CheckedOutAt = DateTime.UtcNow,
                DocumentId = documentInfo.DocumentId,
            };

            var lockFile = GetLockFileName(documentInfo);

            using (new DocumentArchiveFileImpersonationContext())
            {
                // use the transaction object to prevent us from entering a stale state.
                var transaction = new SoArc2SimpleTransactions();
                                    
                var documentOriginalPathAndFileName = SoArc2Helper.GetFullArchivePath(documentInfo);
                var documentLockedPathAndFileName = GetCheckedOutDocumentPath(documentInfo);

                var jsonData = JsonConvert.SerializeObject(checkoutData);

                // Acquire the lock to prevent TOCTOU (Time-Of-Check to Time-To-Use) issues. WriteAllText is assumed to be an atomic operation. However, systems such as DFS and file-synchronization may
                // render this assumption incorrect.
                transaction.Add(
                    () => _fileOps.WriteAllText(lockFile, jsonData),
                    () => _fileOps.Delete(lockFile)); 

                transaction.Add(
                    () => _fileOps.Copy(documentOriginalPathAndFileName, documentLockedPathAndFileName, true),
                    () => _fileOps.Delete(documentLockedPathAndFileName));

                transaction.Add(
                    () => _fileOps.RemoveReadOnly(documentLockedPathAndFileName),
                    () => { });

                transaction.Add(() => _fileOps.SetReadOnly(documentOriginalPathAndFileName),
                    () => _fileOps.RemoveReadOnly(documentOriginalPathAndFileName));

                // Perform the actions added to the transaction.
                transaction.Commit();
            }

            return GetCheckedOutDocumentPath(documentInfo);
        }

        /// <summary>
        /// Check-in the document. This will copy the locked\document to the original folder and remove the checkoutdata.
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <returns></returns>
        public void CheckinDocument(IDocumentInfo documentInfo)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                var documentOriginalPathAndFileName = SoArc2Helper.GetFullArchivePath(documentInfo);
                var documentLockedPathAndFileName = GetCheckedOutDocumentPath(documentInfo);
                
                _fileOps.RemoveReadOnly(documentOriginalPathAndFileName);
                _fileOps.Copy(documentLockedPathAndFileName, documentOriginalPathAndFileName, true);
                _fileOps.Delete(documentLockedPathAndFileName);

                // Just make sure that we don't have the readonly attribute set. 
                _fileOps.RemoveReadOnly(documentOriginalPathAndFileName);

                SaveCheckoutData(documentInfo, null);
            }
        }



        /// <summary>
        /// Get the internal representation of the checkout meta-data. 
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <returns></returns>
        public CheckoutData GetCheckoutData(IDocumentInfo documentInfo)
        {
            // Get the directory of the document 
            var lockFile = GetLockFileName(documentInfo);
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (_fileOps.Exists(lockFile))
                {
                    var jsonData = _fileOps.ReadAllText(lockFile);
                    return JsonConvert.DeserializeObject<CheckoutData>(jsonData);
                }

                string msName;
                if (IsDocumentLockedByOffice(documentInfo, out msName))
                {
                    return new CheckoutData
                    {
                        AssociateId = -1,
                        CheckedOutAt = DateTime.UtcNow,
                        CheckedOutBy = msName,
                    };
                }
            }



            return null;
        }


        public void UndoCheckout(IDocumentInfo documentInfo)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                string displayName;
                if (IsDocumentLockedByOffice(documentInfo, out displayName))
                    throw new SoException(string.Format("Document is locked by another system. (Locked by: {0}). SuperOffice is unable to revert this.", displayName));

                SaveCheckoutData(documentInfo, null);
                DeleteLockedFile(documentInfo);

                // Make sure that we don't have the readonly attribute set. 
                var originalDocumentFile = SoArc2Helper.GetFullArchivePath(documentInfo);
                _fileOps.RemoveReadOnly(originalDocumentFile);
            }
        }


        private void DeleteLockedFile(IDocumentInfo documentInfo)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                var checkedOutFileName = GetCheckedOutDocumentPath(documentInfo);
                if (_fileOps.Exists(checkedOutFileName))
                {
                    try
                    {
                        _fileOps.Delete(checkedOutFileName);
                    }
                    catch (Exception ex)
                    {
                        SoLogger.LogError(ex);
                    }
                }
            }
        }

        /// <summary>
        /// Save the checkout data as JSON in the archivepath. The checkoutdata is removed if the checkoutData is null. 
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <param name="checkoutData"></param>
        public void SaveCheckoutData(IDocumentInfo documentInfo, CheckoutData checkoutData)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                var lockFile = GetLockFileName(documentInfo);

                if (checkoutData == null)
                {

                    if (_fileOps.Exists(lockFile))
                    {
                        try
                        {
                            _fileOps.Delete(lockFile);
                        }
                        catch (Exception ex)
                        {
                            SoLogger.LogError(ex);
                        }
                    }

                    return;
                }

                var json = JsonConvert.SerializeObject(checkoutData);
                _fileOps.WriteAllText(lockFile, json);
            }
        }

        private string GetLockFileName(IDocumentInfo documentInfo)
        {
            var lockFileName = SoArc2Helper.GetFullArchivePath(documentInfo) + ".lock";
            return lockFileName;
        }

        private string GetLockFileName(IDocumentInfo documentInfo, string newDocumentName)
        {
            var lockFileName = Path.Combine(SoArc2Helper.GetCurrentVersionFolderPath(documentInfo), newDocumentName + ".lock");
            return lockFileName;
        }


        /// <summary>
        /// Get the path to the checked-out document. 
        /// 
        /// Assumes that the document is checked-out. 
        /// </summary>
        /// <param name="incomingInfo"></param>
        /// <returns></returns>
        public string GetCheckedOutDocumentPath(IDocumentInfo incomingInfo)
        {
            var documentLockedPath = GetDocumentLockedPath(incomingInfo, true);
            var documentLockedPathAndFileName = Path.Combine(documentLockedPath,
                SoArc2Helper.MakeLegalFileName(incomingInfo.Name));

            return documentLockedPathAndFileName;
        }

        /// <summary>
        /// Get the path to the document which this associate has access to. If the document is checked-out to the user, he will receive the path to the document in the locked
        /// folder. If the document is not checked out, or the current associate is not the checked-out-associate, he will receive the path to the original document.
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <param name="associateId"></param>
        /// <returns></returns>
        public string GetDocumentPath(IDocumentInfo documentInfo, int associateId)
        {
            var checkoutData = GetCheckoutData(documentInfo);
            return GetDocumentPath(documentInfo, checkoutData, associateId);
        }

        /// <summary>
        /// Get the path to the document which this associate has access to. If the document is checked-out to the user, he will receive the path to the document in the locked
        /// folder. If the document is not checked out, or the current associate is not the checked-out-associate, he will receive the path to the original document.
        /// </summary>
        public string GetDocumentPath(IDocumentInfo documentInfo, CheckoutData checkoutData, int associateId)
        {
            if (checkoutData != null && checkoutData.AssociateId == associateId)
                return GetCheckedOutDocumentPath(documentInfo);

            return SoArc2Helper.GetFullArchivePath(documentInfo);
        }

        /// <summary>
        /// Get the path to the locked folder for the supplied document. 
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <param name="createIfNeccessary"></param>
        /// <returns>The path to the locked folder for the document - excluding the document name</returns>
        protected string GetDocumentLockedPath(IDocumentInfo documentInfo, bool createIfNeccessary = false)
        {
            var archivePath = Path.Combine(SoArc2Helper.GetCurrentVersionFolderPath(documentInfo), LockedFolderName);
            if (createIfNeccessary)
            {
                using (new DocumentArchiveFileImpersonationContext())
                {
                    if (!Directory.Exists(archivePath))
                        Directory.CreateDirectory(archivePath);
                }
            }

            return archivePath;
        }

        public bool IsWriteableForAssociate(IDocumentInfo documentInfo, int associateId)
        {
            var checkoutData = GetCheckoutData(documentInfo);
            return IsWriteableForAssociate(documentInfo, checkoutData, associateId);
        }

        public bool IsWriteableForAssociate(IDocumentInfo documentInfo, CheckoutData checkoutData, int associateId)
        {
            if (checkoutData == null)
                return false;

            return (checkoutData.AssociateId == associateId);
        }

        /// <summary>
        /// Rename the checkout data when the document is renamed. 
        /// Should only be called when the document has actually changed file name. 
        /// </summary>
        /// <param name="documentInfo"></param>
        /// <param name="newFileName"></param>
        public void RenameDocument(IDocumentInfo documentInfo, string newFileName)
        {
            var oldLockPathAndFileName = GetLockFileName(documentInfo);
            var newLockPathAndFileName = GetLockFileName(documentInfo, newFileName);

            // We should already be in an impersonated context... 
            _fileOps.Move(oldLockPathAndFileName, newLockPathAndFileName);

            // Rename the locked file. 
            var documentLockedPath = GetDocumentLockedPath(documentInfo, true);
            var oldDocumentLockedPathAndFileName = Path.Combine(documentLockedPath,
                SoArc2Helper.MakeLegalFileName(documentInfo.Name));
            var newDocumentLockedPathAndFileName = Path.Combine(documentLockedPath, newFileName);

            _fileOps.Move(oldDocumentLockedPathAndFileName, newDocumentLockedPathAndFileName);
        }

        /// <summary>
        /// Check if the document is locked by Office. If the file is locked, displayName will be populated with the name of the editor.
        /// 
        /// </summary>
        /// <remarks>
        /// The displayName will be the name supplied by the user in Microsoft Office. Note that the name *MAY* in some scenarios be wrong.
        /// </remarks>
        /// 
        /// <param name="documentInfo"></param>
        /// <param name="displayName"></param>
        /// <returns></returns>
        public bool IsDocumentLockedByOffice(IDocumentInfo documentInfo, out string displayName)
        {
            displayName = string.Empty;

            // Check if the feature is disabled. 

            // Check if there is a lock file
            var documentPath = SoArc2Helper.GetFullArchivePath(documentInfo);
            var documentName = Path.GetFileName(documentPath);
            var documentDirectory = Path.GetDirectoryName(documentPath);

            var candidates = new List<string>();
            candidates.Add(Path.Combine(documentDirectory, "~$" + documentName));
            if (documentName.Length > 7)
            {
                var alternative = "~$" + documentName.Substring(2);
                candidates.Add(Path.Combine(documentDirectory, alternative));
            }

            var matchingLockFiles = candidates.Where(_fileOps.Exists).ToArray();
            if (!matchingLockFiles.Any())
                return false;


            // Read in the name 
            displayName = ReadNameFromLockFile(matchingLockFiles.First());


            try
            {
                // Just test if we can open the file in read mode. This will fail if Office has openend the file.
                using (_fileOps.Open(documentPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    // No issues opening the file. There is no lock.

                    return false;
                }
            }
            catch (IOException ex)
            {
                if (ex.HResult == -2147024864) // The HResult used when access was denied. 
                    return true;
            }


            return false;
        }

        private string ReadNameFromLockFile(string lockFile)
        {
            try
            {
                using (var fs = _fileOps.Open(lockFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (var br = new BinaryReader(fs))
                    {
                        var nameLength = br.ReadByte();
                        var name = br.ReadBytes(nameLength);
                        return System.Text.Encoding.UTF8.GetString(name);
                    }
                }
            }
            catch
            {
                // Intentionally empty
            }

            return string.Empty;
        }

    }

    /// <summary>
    /// Only public so we can access this during tests. 
    /// </summary>
    public interface ICheckinFileOperations
    {
        /// <summary>
        /// Move the file from sourceFileName to destinationFileName
        /// </summary>
        /// <param name="sourceFileName"></param>
        /// <param name="destinationFileName"></param>
        void Move(string sourceFileName, string destinationFileName);

        /// <summary>
        /// Copy the contents of the sourceFilename to the destinationFilename.
        /// </summary>
        /// <param name="sourceFileName"></param>
        /// <param name="destinationFileName"></param>
        /// <param name="overwrite"></param>
        void Copy(string sourceFileName, string destinationFileName, bool overwrite);

        /// <summary>
        /// Write all text to the fileName (overwrites the existing content).
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="text"></param>
        void WriteAllText(string fileName, string text);

        /// <summary>
        /// Delete the file.
        /// </summary>
        /// <param name="fileName"></param>
        void Delete(string fileName);

        /// <summary>
        /// Check if the file exists. 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns>True if the file exists.</returns>
        bool Exists(string fileName);

        /// <summary>
        /// Read all text from the given fileName. 
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        string ReadAllText(string fileName);

        /// <summary>
        /// Set the read-only attribute on the given file.
        /// </summary>
        /// <param name="fileName"></param>
        void SetReadOnly(string fileName);

        /// <summary>
        /// Remove the read-only attribute on the given file.
        /// </summary>
        /// <param name="fileName"></param>
        void RemoveReadOnly(string fileName);

        /// <summary>
        /// Open the file in read-only.
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="fileMode"></param>
        /// <param name="fileAccess"></param>
        /// <param name="fileShare"></param>
        /// <returns></returns>
        FileStream Open(string fileName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare);
    }

    /// <summary>
    /// Default implementation using the File API. This abstraction level is only required due to the testing framework.     
    /// </summary>
    internal class DefaultCheckinFileOperations : ICheckinFileOperations
    {
        public void Move(string sourceFileName, string destinationFileName)
        {
            File.Move(sourceFileName, destinationFileName);
        }

        public void Copy(string sourceFileName, string destinationFileName, bool overwrite)
        {
            File.Copy(sourceFileName, destinationFileName, overwrite);
        }

        public void WriteAllText(string fileName, string contents)
        {
            using (var fs = File.Open(fileName, FileMode.CreateNew, FileAccess.Write, FileShare.Read))
            {
                var buffer = Encoding.UTF8.GetBytes(contents);
                fs.Write(buffer, 0, buffer.Length);
            }
        }

        public void Delete(string fileName)
        {
            File.Delete(fileName);
        }

        public bool Exists(string fileName)
        {
            return File.Exists(fileName);
        }

        public string ReadAllText(string fileName)
        {
            return File.ReadAllText(fileName);
        }

        public void SetReadOnly(string fileName)
        {
            File.SetAttributes(fileName, File.GetAttributes(fileName) | FileAttributes.ReadOnly);
        }

        /// <summary>
        /// Remove the read-only attribute on the specified file.
        /// </summary>
        /// <param name="fileName"></param>
        public void RemoveReadOnly(string fileName)
        {
            File.SetAttributes(fileName, File.GetAttributes(fileName) & ~FileAttributes.ReadOnly);
        }


        public FileStream Open(string fileName, FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
        {
            return File.Open(fileName, fileMode, fileAccess, fileShare);
        }

    }

    /// <summary>
    /// The data container for serializing the checkout meta-data. 
    /// </summary>
    [DataContract(Namespace = "http://www.superoffice.com/netserver/internal/8.0")]
    public class CheckoutData
    {
        [DataMember]
        public int DocumentId { get; set; }

        [DataMember]
        public int AssociateId { get; set; }

        [DataMember]
        public DateTime CheckedOutAt { get; set; }

        [DataMember]
        public string CheckedOutBy { get; set; }
    }


    /// <summary>
    /// Utility class that will run the actions pseudo-atomically. If one of the actions fails, by throwing an exception, the previous revert actions will be executed sequentially.
    /// </summary>
    internal class SoArc2SimpleTransactions
    {
        private List<Action> _actions = new List<Action>();
        private List<Action> _reverts = new List<Action>();
        private int _currentAction = 0;

        public void Add(Action action, Action revert)
        {
            _actions.Add(action);
            _reverts.Add(revert);            
        }

        /// <summary>
        /// Commit the actions. If one of the actions fails by throwing an exception, it will run the revert action on all previously executed actions.
        /// After all reverts have been executed, the failing exception is rethrown.
        /// </summary>
        /// <returns>Throws an exception on error.</returns>
        public void Commit()
        {
            try
            {
                for (_currentAction = 0; _currentAction < _actions.Count; _currentAction++)
                {
                    _actions[_currentAction]();
                }
            }
            catch (Exception)
            {
                Revert();

                throw;
            }            
        }

        private void Revert()
        {
            try
            {
                for (var i = _currentAction - 1; i >= 0; i--)
                {
                    _reverts[i]();
                }
            }
            catch (Exception ex)
            {
                SoLogger.LogWarning(ex);
            }
        }
    }
}
