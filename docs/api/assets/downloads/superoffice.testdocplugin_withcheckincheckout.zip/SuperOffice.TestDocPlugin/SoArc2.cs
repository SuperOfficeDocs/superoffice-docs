using SuperOffice.CRM.Globalization;
using SuperOffice.Configuration;
using SuperOffice.CRM.Rows;
using SuperOffice.Data;
using SuperOffice.Diagnostics;
using SuperOffice.Exceptions;
using SuperOffice.Plugins.CRM.Documents;
using SuperOffice.Security.Util;
using System;
using System.Collections;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using SuperOffice.CRM.Cache;


namespace SuperOffice.CRM.Documents
{
    /// <summary>
	/// Document plugin for SuperOffice standard document archive (i.e SO_ARC) with Check-in/Check-out &amp; versioning features.
	/// </summary>
	[DocumentPlugin2("SO Archive", 0)]
    public class SoArc2 : IDocumentPlugin2, IAssociateRename, IDocumentPluginTravel
    {
        /// <summary>
        /// Renames the path associated with the associate.
        /// </summary>
        /// <param name="oldName"></param>
        /// <param name="newName"></param>
        public void AssociateRename(string oldName, string newName)
        {
            try
            {
                using (new DocumentArchiveFileImpersonationContext())
                {
                    string oldPath = Path.Combine(SoArc2Helper.GetArchivePath(), oldName);
                    string newPath = Path.Combine(SoArc2Helper.GetArchivePath(), newName);
                    if (Directory.Exists(oldPath))
                    {
                        Directory.Move(oldPath, newPath);
                    }
                }
            }
            catch (Exception ex)
            {
                SoLogger.LogError(ex);
                throw new SoException("Error occurred at changing the associate so_arc path", ex, "Unable to move so_arc location for user.");
            }

        }
        #region plugin level data, keys etc

        // this name must be kept in sync between:
        //  - Server\Source\SoDataBase\CRM\Documents\SoArc2.cs (declaration at top of class)
        //  - Clients\SM.win\Source\DbSetup\DbToSevenFiveUpgrader.cpp SDbToSevenFiveUpgrader::FixDocPluginForeignKeys
        private const string SOARC2_APP_NAME = "SOARC2";

        // Jens & Jostein: Only used for buffer when accessing file on file storage - change to default size
        //private const int PREFERRED_BUFFER_SIZE = 2;

        //SoArc2Checkout Helper class providing the checkout methods        
        protected SoArc2CheckoutHelper _checkoutHelper;

        //variables to hold plugin level capabilities
        private string _locking;
        private string _fastLockStatus;
        private string _versioning;
        private string _fastVersionList;
        private string _fastExists;
        private int _maxDocumentSize;
        private int _timeout;
        private bool _canCreateDocumentTemplates;
        private bool _customCommand;

        public string Locking
        {
            get { return _locking; }
        }

        public string FastLockStatus
        {
            get { return _fastLockStatus; }
        }

        public string Versioning
        {
            get { return _versioning; }
        }

        public string FastVersionList
        {
            get { return _fastVersionList; }
        }

        public string FastExists
        {
            get { return _fastExists; }
        }

        public int MaxDocumentSize
        {
            get { return _maxDocumentSize; }
        }

        public int Timeout
        {
            get { return _timeout; }
        }

        #endregion



        #region Plugin initialization & lifetime management etc.

        /// <summary>
        /// Create the document plugin. Check configuration to see if the TestCommand should be enabled?
        /// </summary>
        /// <remarks>
        /// Reads Config properties:<para/>
        ///  &lt;SuperOffice&gt;&lt;Documents&gt;&lt;add key="TestCommand" value="true" /&gt;
        ///  <para/>
        ///  &lt;SuperOffice&gt;&lt;Documents&gt;&lt;add key="CanCreateDocumentTemplates" value="false" /&gt;
        /// </remarks>
        /// <param name="config">configuration settings</param>
        public SoArc2(IConfiguration config)
        {
            this.Initialize(config);
            _customCommand = config.GetConfigBool("SuperOffice/Documents/TestCommand");
        }

        private void Initialize(IConfiguration config)
        {
            //Initialize the helper          
            _checkoutHelper = new SoArc2CheckoutHelper(new DefaultCheckinFileOperations());

            //Populate plugin level properties
            PopulatePluginProperties(config);
        }

        private void PopulatePluginProperties(IConfiguration config)
        {
            _locking = Constants.Values.Mandatory;
            _fastLockStatus = string.Empty;
            _versioning = string.Empty;
            _fastVersionList = string.Empty;
            _fastExists = string.Empty;

            // should be done like this - but we have a TRUE default, so we can't:
            // _canCreateDocumentTemplates = config.GetConfigBool("SuperOffice/Documents/CanCreateDocumentTemplates");
            _canCreateDocumentTemplates = ConfigFile.Documents.CanCreateDocumentTemplates;
        }


        #endregion


        #region Capabilities, properties, metadata and custom commands


        /// <summary>
        /// Get a list of capabilities (functionality) supported by this document plugin
        /// </summary>
        /// <remarks>
        /// The purpose of this call is to enable NetServer and clients to determine what functionality this plugin can offer. 
        /// Plugins should populate the return array with all capabilities they know about. NetServer will call this API only once.
        /// <para/>
        /// As an example of use, the Document archive provider inside NetServer will look at plugin capabilities, 
        /// and read document properties as appropriate. i.e. if �fast-lock-status=false�, then the archive provider 
        /// will not call the IsCheckedOut(externalReference) function. Otherwise it will make the call (if the client has requested
        /// the appropriate column in the GUI), so that the user can see which documents are checked out.
        /// <para/>
        /// String constants for capabilities are available in the <see cref="SuperOffice.CRM.Documents.Constants.Capabilities"/> static class.
        /// </remarks>
        /// <returns>Array of name=value strings listing all known capabilities and their values</returns>
        public Dictionary<string, string> GetPluginCapabilities()
        {
            var result = new Dictionary<string, string>(7);

            //locking
            result[Constants.Capabilities.Locking] = _locking;
            //fast-lock-status
            result[Constants.Capabilities.FastLockStatus] = _fastLockStatus;
            //versioning
            result[Constants.Capabilities.Versioning] = _versioning;
            //fast-version-list
            result[Constants.Capabilities.FastVersionList] = _fastVersionList;
            //fast-exists
            result[Constants.Capabilities.FastExists] = _fastExists;
            //max-document-size
            result[Constants.Capabilities.MaxDocumentSize] = _maxDocumentSize.ToString();
            //timeout
            result[Constants.Capabilities.Timeout] = _timeout.ToString();

            result[Constants.Capabilities.CanCreateDocumentTemplates] = _canCreateDocumentTemplates.ToString();

            return result;
        }

        /// <summary>
        /// Get the values of certain properties, for a given document
        /// </summary>
        /// <remarks>
        /// Each document can have a number of properties associated with it. A set of standard properties
        /// is defined in the <see cref="SuperOffice.CRM.Documents.Constants.Properties"/> class. Ideally, retrieving properties should
        /// be a lightweight operation.
        /// <para/>
        /// Note that 'properties' are a one-way mechanism where the document plugin provides information about
        /// the document or certain aspects of it. This is not the same as document-specific
        /// metadata, which is handled by the <see cref="LoadMetaData"/> and <see cref="SaveMetaData"/>
        /// methods.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="requestedProperties">Array of property strings, for which values are requested</param>
        /// <returns>Array of name=value pairs, where the name is one of the requested property strings, and the value
        /// is the value of that property for the given document.</returns>
        public Dictionary<string, string> GetDocumentProperties(IDocumentInfo documentInfo, string[] requestedProperties)
        {
            var result = new Dictionary<string, string>(requestedProperties.Length);
            int documentId = documentInfo.DocumentId;

            foreach (string documentProperty in requestedProperties)
            {
                string value = string.Empty;
                switch (documentProperty)
                {
                    case Constants.Properties.HasLocking:
                        value = _locking;
                        break;
                    case Constants.Properties.HasVersioning:
                        value = _versioning;
                        break;
                    case Constants.Properties.FileType:
                        DocumentRow document = new DocumentRow.IdxDocumentId(documentId);
                        value = document.Name.Substring(document.Name.LastIndexOf('.') + 1);
                        break;
                    case Constants.Properties.FileName:
                        if (! string.IsNullOrWhiteSpace(documentInfo.Header))
                        {
                            var extension = Path.GetExtension(documentInfo.Name);
                            var suggestedName = documentInfo.Header + extension;
                            value = SoArc2Helper.MakeLegalFileName(suggestedName);                            
                        }
                        else
                        {
                            value = documentInfo.Name;
                        }

                        break;
                    case Constants.Properties.PreferredOpen:
                        value = Constants.Values.Stream;
                        break;
                    case Constants.Properties.LastModified:
                        DocumentRow documentRow = new DocumentRow.IdxDocumentId(documentId);
                        string archivePath = SoArc2Helper.GetFullArchivePath(documentRow);
                        using (new DocumentArchiveFileImpersonationContext())
                        {
                            if (File.Exists(archivePath))
                            {
                                DateTime lastModified = File.GetLastWriteTimeUtc(archivePath);
                                value = SuperOffice.CRM.Globalization.CultureDataFormatter.EncodeDateTime(lastModified);
                            }
                        }
                        break;
                    default:
                        break;
                }
                result[documentProperty] = value;
            }

            return result;
        }


        /// <summary>
        /// Get a list of custom commands, applicable to a specific document. Note that commands related to
        /// standard locking and versioning operations have their own API calls and are not 'custom commands' in this sense.
        /// </summary>
        /// <remarks>
        /// This API is called before a menu, task button or other GUI item that gives access to document-specific commands is shown.
        /// It is used to populate the GUI with available commands for a particular document, the results are not cached by the GUI.
        /// <para/>
        /// Depending on the return type indicated in the command, the command might be filtered by GUI. More information can
        /// be found in the <see cref="CommandInfo"/> topic.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Array of command descriptions. If there are no custom commands available, an empty array should be returned.</returns>
        public CommandInfo[] GetDocumentCommands(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            if (_customCommand)
            {
                CommandInfo cmd1 = new CommandInfo() { DisplayName = "Test URL", DisplayTooltip = "This is the tooltip", Name = "TEST-URL", ReturnType = ReturnType.URL };
                CommandInfo cmd2 = new CommandInfo() { DisplayName = "Test SO Protocol", DisplayTooltip = "[SR_QUOTE_SETTINGS_TOOLTIPRES_TOOLTIP]", Name = "TEST-SO", ReturnType = ReturnType.SoProtocol };
                CommandInfo cmd3 = new CommandInfo() { DisplayName = "Test Message", DisplayTooltip = "This is the message", Name = "TEST-MSG", ReturnType = ReturnType.Message };
                return new CommandInfo[3] { cmd1, cmd2, cmd3 };
            }

            return new CommandInfo[] {};
        }


        /// <summary>
        /// Execute a custom command on a specified document and version
        /// </summary>
        /// <remarks>
        /// This command is called when the user chooses an action item from a dropdown/context menu. 
        /// It is also reflected in the DocumentAgent service interface, so that custom GUI�s and external 
        /// code can directly execute document plugin commands; this is useful if a plugin also has some 
        /// corresponding custom GUI that needs to execute commands depending on user interaction.
        /// <para/>
        /// The parameter <see cref="allowedReturnTypes"/> can be used by clients to hint to the plugin
        /// what kind of return value processing is available. For instance, a mobile client might
        /// only offer None and Message, and this information can be used by the document plugin to adapt
        /// the processing of a command, if it wants to (for instance, use default values instead of
        /// triggering some more advanced workflow).
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="versionId">Version identifier, blank implies 'latest' version</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <param name="command">Command name, taken from an earlier call to <see cref="GetDocumentCommands"/>
        /// - or any other command name that is understood by the provider. 'Private' commands that
        /// are not declared in GetDocumentCommands but are known to the authors of custom GUI code
        /// or OK.</param>
        /// <param name="additionalData">Array of strings containing whatever additional data the command
        /// may need. This parameter is intended for authors of more complex custom GUI's and works as
        /// a tunnel between the ultimate client and the document plugin. Standard GUI made by SuperOffice,
        /// such as a context menu connected to a document item in an archive, will not populate this
        /// member.<br/>It is strongly suggested that the convention of using name=value for each string
        /// array element be followed here.</param>
        /// <returns>Return value object, specifying failure or success plus any optional, additional processing to be triggered</returns>
        public ReturnInfo ExecuteDocumentCommand(IDocumentInfo documentInfo, string versionId, string[] allowedReturnTypes, string command, params string[] additionalData)
        {
            ReturnInfo ret = new ReturnInfo();
            if (_customCommand)
            {
                if (command == "TEST-URL")
                {
                    ret.Success = true;
                    ret.Type = ReturnType.URL;
                    ret.Value = "http://www.google.com/search?q=" + Uri.EscapeDataString(documentInfo.Header);
                }
                else if (command == "TEST-SO")
                {
                    ret.Success = true;
                    ret.Type = ReturnType.SoProtocol;
                    ret.Value = "contact.main?contact_id=" + documentInfo.ContactId.ToString();
                }
                else if (command == "TEST-MSG")
                {
                    ret.Success = true;
                    ret.Type = ReturnType.Message;
                    ret.Value = "[SR_LOGIN_UPGRADE_VERSION_8]";
                }
            }

            return ret;
        }


        /// <summary>
        /// Retrieve metadata owned by the plugin/repository, related to one document (excluding version-dependent metadata)
        /// </summary>
        /// <remarks>
        /// A document plugin may consume and provide an arbitrary number of metadata fields. These are placed
        /// in a string, string dictionary, representing name/value pairs. This call should <b>not</b>
        /// retrieve metadata related to any particular version, only data related to the document as a whole.
        /// <para/>
        /// The NetServer service call DocumentAgent.GetDocumentEntity will (among other things) result in a call 
        /// to this API to populate the ExtraFields property of the document entity carrier. Note, however, 
        /// that the carrier handed over to the client may contain other fields in addition to those 
        /// supplied by the document plugin, since the extrafields mechanism is generic and 
        /// there may be other metadata providers along the line.
        /// <para/>
        /// Attribute names should be prefixed with the name of the document plugin, to maintain global uniqueness.
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// </remarks>
        /// <param name="documentInfo">Document info used by the document plugin</param>
        /// <returns>Dictionary of name=value strings, each representing one key and one value.
        /// Always throws InvalidOperationException.
        /// </returns>
        public Dictionary<string, string> LoadMetaData(IDocumentInfo documentInfo)
        {
            throw new InvalidOperationException();
        }


        /// <summary>
        /// Retrieve metadata owned by the plugin/repository, related to one particular
        /// version of one document
        /// </summary>
        /// <remarks>
        /// A document plugin may consume and provide an arbitrary number of metadata fields. These are placed
        /// in a string, string dictionary, representing name/value pairs. This call should only retrieve
        /// metadata related to a version.
        /// <para/>
        /// The NetServer service call DocumentAgent.GetDocumentEntity will (among other things) result in a call 
        /// to this API to populate the VersionInfo property of the document entity carrier. 
        /// <para/>
        /// Attribute names should be prefixed with the name of the document plugin, to maintain global uniqueness.
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// <para/>
        /// To efficiently retrieve information about <b>all</b> versions, use the 
        /// <see cref="SuperOffice.CRM.Documents.IDocumentPlugin2.GetVersionList"/> method, instead of iterating
        /// over this method.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="versionId">Version identifier, blank implies 'latest' version</param>
        /// <returns>Fully populated version info structure.
        /// Always throws InvalidOperationException.
        /// </returns>
        public VersionInfo LoadVersionInfo(IDocumentInfo documentInfo, string versionId)
        {
            throw new InvalidOperationException();
        }

        /// <summary>
        /// Store/update plugin-dependent document metadata in the repository
        /// </summary>
        /// <remarks>
        /// This call is made when the document metadata should be stored, and is the complement of the
        /// <see cref="SuperOffice.CRM.Documents.IDocumentPlugin2.LoadMetaData"/> method.
        /// The document plugin should extract whatever elements it 
        /// recognizes from the pluginData name/value dictionary. Failure to recognize an element should not cause an exception, 
        /// as there may be other plugins along the line (not document plugins, but service-level field providers) that own the data. 
        /// Likewise, absence of a value should be taken to imply �no change� to that value - not "delete".
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// 
        /// SoArc plugin does not use metadata.
        /// </remarks>
        /// <param name="incomingInfo">SuperOffice document information. Note that the plugin is <b>not</b> responsible
        /// for storing this data; however, it is allowed to look at it, in case it influences how the document
        /// is stored. However, it should always be possible to retrieve a document using the ExternalReference
        /// or DocumentId keys alone.</param>
        /// <param name="pluginData">Name/value dictionary containing metadata</param>
        public void SaveMetaData(IDocumentInfo incomingInfo, Dictionary<string, string> pluginData)
        {
            // Don't do anything...
        }


        /// <summary>
        /// Store/update plugin-dependent document version metadata in the repository
        /// </summary>
        /// <remarks>
        /// This call is made when the document <b>version</b> metadata should be stored, and is the complement of the
        /// <see cref="SuperOffice.CRM.Documents.IDocumentPlugin2.LoadVersionInfo"/> method.
        /// The document plugin should extract whatever elements it 
        /// recognizes from the pluginData name/value dictionary. Failure to recognize an element should not cause an exception, 
        /// as there may be other plugins along the line (not document plugins, but service-level field providers) that own the data. 
        /// Likewise, absence of a value should be taken to imply �no change� to that value - not "delete".
        /// <para/>
        /// It is <b>strongly suggested</b> that non-string data be formatted according to the rules followed by the 
        /// <see cref="SuperOffice.CRM.Globalization.CultureDataFormatter"/> class, to avoid problems
        /// when parsing dates and floating-point types between different cultures and platforms.
        /// Always throws InvalidOperationException.
        /// </remarks>
        /// <param name="versionInfo">Version information to be saved</param>
        public void SaveVersionInfo(IDocumentInfo docInfo, VersionInfo versionInfo)
        {
            throw new InvalidOperationException();
        }


        /// <summary>
        /// Determine if the document exists in the repository
        /// </summary>
        /// <remarks>
        /// The plugin should declare, through the <see cref="SuperOffice.CRM.Documents.Constants.Capabilities.FastExists"/> property,
        /// whether this call is highly efficient or not. If it is efficient, then document archive providers and similar code
        /// will call it when populating an archive, otherwise not.
        /// </remarks>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <returns>true if the document exists in the repository, otherwise false</returns>
        public bool Exists(IDocumentInfo documentInfo)
        {
            string path = SoArc2Helper.GetFullArchivePath(documentInfo);
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (File.Exists(path))
                    return true;
                else
                    return false;
            }
        }


        /// <summary>
        /// Return the length of the physical document. This should be an efficient method
        /// </summary>
        /// <param name="externalReference">Document key used by the document plugin, unique per plugin</param>
        /// <param name="documentId">Document key used inside the SuperOffice database</param>
        /// <param name="versionId">Version identifier, blank implies 'latest' version</param>
        /// <returns>Physical document length in bytes - this should be the same as the length of the stream
        /// returned by the LoadDocumentStream method.</returns>
        public long GetLength(IDocumentInfo documentInfo, string versionId)
        {
            if (Exists(documentInfo))
            {
                string docFullPath = SoArc2Helper.GetFullArchivePath(documentInfo);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    return new FileInfo(docFullPath).Length;
                }
            }

            return -1;
        }


        #endregion


        #region Document Templates




        /// <summary>
        /// Get the "extension" for the template, i.e., what the file extension would have been - to 
        /// help identify the stream content format
        /// </summary>
        /// <remarks>
        /// Template documents are generally created in text editors and stored as files of some kind. The
        /// file extension indicates the kind of document - doc, docx, xls, txt, and so on. While the template
        /// may be stored inside the document repository as any kind of data byte collection, a concept
        /// akin to the file extension is still needed to help identify the document format, ahead of actually
        /// reading the template content.
        /// </remarks>
        /// <param name="templateInfo">Document template info: contains the extref/filename, template id, mime type.</param>    
        /// <returns>String equivalent to a file extension, for instance ".docx"</returns>
        public string GetTemplateExtension(IDocumentTemplateInfo templateInfo)
        {
            string fileName = templateInfo.ExternalReference;
            return Path.GetExtension(fileName);
        }


        /// <summary>
        /// Get the document template content as a stream. NetServer will read-to-end and close this stream
        /// </summary>
        /// <remarks>
        /// Document templates may be stored in a repository, with or without special content tags.
        /// Because a document template does not have a corresponding document record within
        /// SuperOffice, there is no documentId to identify it.
        /// <para/>
        /// This call is used by NetServer to retrieve a document template based on either
        /// an externalreference value stored in the corresponding DocTmpl.Filename field,
        /// or the Id of the doctmpl record itself. The document plugin is free
        /// to use either method of identification.
        /// <para/>
        /// Mail templates are passed in using extref = "filename=xyz&amp;allowPersonal=1" and docTemplateId = 0
        /// </remarks>
        /// <param name="templateInfo">Document template info: contains the extref/filename, template id, mime type.
        /// TemplateInfo.Id = 0 when archiving mail messages. 
        /// </param>
        /// <param name="languageCode">Language (en-US, nb-NO, etc) that the user is using in the user interface. Can be used to select language-specific templates.</param>
        /// <returns>Stream containing the template content. Null if no suitable template found.</returns>
        public System.IO.Stream LoadDocumentTemplateStream(IDocumentTemplateInfo templateInfo, string languageCode)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                System.IO.Stream retval = null;
                if (templateInfo.Id != 0)    // normal templates
                {
                    string filePath = SoArc2Helper.GetDocumentTemplatePath(templateInfo, languageCode);

                    retval = GetStream(filePath);
                }
                else // Mail templates and other things not stored in DocTmpl table
                {
                    string templateName = GetExternalReferenceValue("filename", templateInfo.ExternalReference);
                    bool allowPersonal = GetExternalReferenceValue("allowPersonal", templateInfo.ExternalReference) == "1";
                    string filePath = string.Empty;
                    if (allowPersonal)
                    {
                        filePath = Path.Combine(ConfigFile.Documents.ArchivePath, Path.Combine(SoContext.CurrentPrincipal.Associate, templateName));
                        retval = GetStream(filePath);
                    }

                    if (retval == null)
                    {
                        filePath = Path.Combine(ConfigFile.Documents.TemplatePath, templateName);
                        retval = GetStream(filePath);
                    }
                }

                return retval;
            }
        }

        /// <summary>
        /// Get the value of a property from a custom crafted externalReference string.
        /// Separator = � or &
        /// </summary>
        /// <param name="property">Name of property to retrieve value for</param>
        /// <param name="externalReference">The externalReference string.
        /// Ex: "soarc�filename=myfile.txt�allowPersonal=1"</param>
        /// <returns>Value of the requested property</returns>
        private string GetExternalReferenceValue(string property, string externalReference)
        {
            string retval = string.Empty;
            if (!string.IsNullOrEmpty(externalReference))
            {
                Regex pattern = new Regex(property + "=" + "([^�&]+)", RegexOptions.IgnoreCase);
                Match value = pattern.Match(externalReference);
                if (value != null && value.Success && value.Groups.Count > 1)
                    retval = value.Groups[1].Value;
            }
            return retval;
        }

        /// <summary>
        /// Retrieve the content of a physical file
        /// </summary>
        /// <param name="filePath">Full path and filename of a file to retrieve</param>
        /// <returns>Content of file</returns>
        private System.IO.Stream GetStream(string filePath)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (!string.IsNullOrEmpty(filePath) && (File.Exists(filePath)))
                {
                    for (int retry = 1; retry <= 3; retry++)
                    {
                        try
                        {
                            return File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                        }
                        catch (Exception ex)
                        {
                            if (retry < 3)
                                SoLogger.LogWarning(typeof(SoArc2), "File.Open '{1}' create failure. Retrying {0}".FormatWith(retry, filePath), ex.SimpleMessageStack());
                            else
                            {
                                SoLogger.LogError(ex);
                                throw;
                            }
                        }
                    }
                }
                else
                    return null;
            }
            return null;
        }

        /// <summary>
        /// Create or update the document template contents. Usually used when uploading a file to a new document template.
        /// </summary>
        /// <param name="templateInfo">Name and tooltip from the document template record in the database. The ExtRef/Filename may be set if this is an edit rather than an add.</param>
        /// <param name="content">Stream containing file content</param>
        /// <param name="languageCode">Language variation on the template. May be ignored by the plugin, or used to keep language specific versions of the template.</param>
        /// <returns>Template information with ExtRef/Filename and MimeType filled in. These values are saved in the DocTmpl record.</returns>
        public TemplateInfo SaveDocumentTemplateStream(IDocumentTemplateInfo templateInfo, System.IO.Stream content, string languageCode)
        {
            return SaveDocumentTemplateStream(templateInfo, content, languageCode, runDuplicateCheck: false);
        }

        private TemplateInfo SaveDocumentTemplateStream(IDocumentTemplateInfo templateInfo, System.IO.Stream content, string languageCode, bool runDuplicateCheck)
        {
            DocTmplRow docTmplRow = DocTmplRow.GetFromIdxDocTmplId(templateInfo.Id);
            string filePath = null;

            // what should we do if there is no doc template with the given id?
            if (docTmplRow.DocTmplId > 0)
            {
                Stream archive = null;
                filePath = SoArc2Helper.GetDocumentTemplatePath(templateInfo, languageCode, checkIfFileExists: false, runDuplicateCheck: runDuplicateCheck);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    try
                    {
                        // We write to a temp .NEW file in SO_ARC, then rename the old file, rename the NEW file, then delete the old file.
                        string newFilePath = filePath + ".new";
                        string oldFilePath = filePath + ".old";

                        FileInfo newFi = new FileInfo(newFilePath);
                        FileInfo fi = new FileInfo(filePath);

                        if (!fi.Directory.Exists)
                        {
                            fi.Directory.Create();
                        }
                        for (int retry = 1; archive == null && retry <= 3; retry++)
                        {
                            try
                            {
                                archive = newFi.Open(FileMode.Create);
                            }
                            catch (Exception ex)
                            {
                                if (retry < 3)
                                {
                                    SoLogger.LogWarning(typeof(SoArc2), "File.Open create '{1}' failure. Retrying {0}".FormatWith(retry, filePath), ex.SimpleMessageStack());
                                    System.Threading.Thread.Sleep(200 * retry);
                                }
                                else
                                {
                                    SoLogger.LogError(ex);
                                    throw;
                                }
                            }
                        }

                        content.WriteInChunksTo(archive);

                        content.Close();
                        archive.Flush();
                        archive.Close();

                        // files are now written and flushed to disk.
                        // time to rename and delete the old file
                        if (File.Exists(oldFilePath))
                            File.Delete(oldFilePath);
                        if (fi.Exists)
                            fi.MoveTo(oldFilePath);
                        newFi.MoveTo(filePath);
                        if (File.Exists(oldFilePath))
                            File.Delete(oldFilePath);
                    }
                    catch (Exception ex)
                    {
                        SoLogger.LogError(ex);
                        throw new Exception("Error occurred at saving the physical document", ex);
                    }
                    finally
                    {
                        content.Dispose();
                        if (archive != null)
                        {
                            archive.Dispose();
                        }
                    }
                }
            }

            TemplateInfo template = new TemplateInfo();
            template.Name = docTmplRow.Name;
            template.Description = docTmplRow.Filename;
            template.PluginId = 0;  // SoArc is id = 0
            template.MimeType = templateInfo.MimeType;


            // Don't overwrite the external reference if this is the main template.
            if (string.IsNullOrEmpty(languageCode))
            {
                template.ExternalReference = Path.GetFileName(filePath);
            }
            else
            {
                template.ExternalReference = docTmplRow.Filename;
            }

            return template;
        }

        #endregion


        #region Document Content and Lifetime


        /// <summary>
        /// Create a document in the repository, intially without content
        /// </summary>
        /// <remarks>
        /// Execution of this method should result in the creation of a document instance in the
        /// underlying repository, with empty content. If locking is supported, the status should
        /// be 'Checked-out'; the document should not be visible to other users. If locking is not 
        /// supported, a zero-length content sh.ould be the result.
        /// <para/>
        /// All metadata should be saved, an externalReference key should be assigned, and
        /// the file name/document name validated and reserved.
        /// <para/><b>Notes on semantics</b><br/>
        /// The IDocumentInfo.<see cref="SuperOffice.CRM.IDocumentInfo.Semantics"/> property is used to specify the
        /// locking/versioning semantics requested and implemented for a document. Semantics actually implemtned
        /// will be the lowest of what is requested and what is supported. Thus, a document may request 
        /// <see cref="SuperOffice.Data.DocumentSemantics.None"/> semantics even if versioning is optionally supported
        /// by the document plugin, and in that case no versioning or locking should be performed.
        /// <para/>
        /// On creation, if locking and/or versioning is supported and requested, then the document stream should
        /// be saved to a temporary area. Calls to GetDocumentStream should return an empty stream until the first
        /// call to CheckinDocument has succeeded. The result of that Checkin call will be the base version 
        /// (version 1).
        /// <para/>
        /// Locking semantics are set on creation and cannot be changed later.
        /// </remarks>
        /// <param name="incomingInfo">SuperOffice metadata for the document, including the document Id
        /// and locking/versioning sematics requested for this document.</param>
        /// <param name="fileName">Suggested file name/document name. The document plugin must validate this
        /// name and amend it if needed (this is a ref parameter). If the name needs to be changed
        /// for any reason, a new and valid name must be generated by the plugin, and returned
        /// to the caller.</param>
        /// <param name="extraFields">Plugin-dependent metadata for the document as a whole. The
        /// usual caveats apply, i.e., there may be name/value pairs in the parameter that
        /// belong to other parts of the system. Failure to recognize a name is not an error.</param>
        /// <param name="versionDecription">Description of the initial version, if versioning is supported
        /// and enabled for the document.</param>
        /// <param name="versionExtraFields">Plugin-dependent metadata for the initial version</param>
        /// <returns></returns>
        public string CreateDocument(SuperOffice.CRM.IDocumentInfo incomingInfo, ref string fileName, string[] extraFields, string versionDecription, string[] versionExtraFields)
        {
            //Document properties                   
            try
            {
                // Create the file with a unique file name.(in Document's root folder)
                //set this file name to the ref parameter so that the caller knows the new name
                string suggestedFullPath = SoArc2Helper.GetFullArchivePath(incomingInfo);
                string createdFilePath = SoArc2Helper.MakeLegalFileNameAndDirectory(suggestedFullPath);
                string uniqueFilePath = SoArc2Helper.GetUniqueFilePath(createdFilePath);    // resolve any duplicates

                // filename gets persisted to the DB, and should NOT have an absolute path ever.
                fileName = Path.GetFileName(uniqueFilePath);

                using (new DocumentArchiveFileImpersonationContext())
                {

                    FileStream fsCreatedFile = File.Create(uniqueFilePath);
                    fsCreatedFile.Close();
                }
            }
            catch (Exception ex)
            {
                SoLogger.LogError(ex);
                throw new Exception("Error occurred at creating the physical document", ex);
            }

            return string.Empty;
        }


        /// <summary>
        /// Save the stream as the document content in the repository; depending on the state, this
        /// may imply creating a temporary save pending a final checkin, or an immediately visible result.
        /// </summary>
        /// <remarks>
        /// If the document is currently checked out to the current user, then the stream should be saved, 
        /// but this call does not imply the automatic creation of a new version (visible to other users) 
        /// or automatic checkin. However, it is an advantage if subsequent GetDocument calls made by 
        /// the same user using the same key return the latest known content � while other users see 
        /// the latest checked-in version.
        /// <para/>
        /// If the plugin does not support locking agnd versioning (or such semantics are not requested, see below), 
        /// then each call to this API overwrites 
        /// any prior content completely and becomes the new, official content immediately. The Save operation 
        /// should be atomic, and should not destroy earlier content if it fails.
        /// <para/>
        /// If locking is supported and requested, the document is checked out and some other associate than the one 
        /// that has checked it out calls this API, a failure message should be returned.
        /// </remarks>
        /// <param name="incomingInfo">Incoming document metadata, used to identify the document. Metadata
        /// changes are <b>not</b> to be checked or saved by this operation - only the document stream is saved.</param>
        /// <param name="content">Document content, a binary stream about which nothing is assumed. The
        /// document plugin should read-to-end and close this stream.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo SaveDocumentFromStream(SuperOffice.CRM.IDocumentInfo incomingInfo, string[] allowedReturnTypes, System.IO.Stream content)
        {
            Stream archive = null;
            string filePath = _checkoutHelper.GetDocumentPath(incomingInfo, SoContext.CurrentIdentity.AssociateId);

            using (new DocumentArchiveFileImpersonationContext())
            {
                // We write to a temp .NEW file in SO_ARC, then rename the old file, rename the NEW file, then delete the old file.
                string newFilePath = filePath + ".new";
                string oldFilePath = filePath + ".old";

                FileInfo newFi = new FileInfo(newFilePath);
                FileInfo fi = new FileInfo(filePath);
                try
                {
                    if (!fi.Directory.Exists)
                    {
                        fi.Directory.Create();
                    }

                    for (int retry = 1; archive == null && retry <= 3; retry++)
                    {
                        try
                        {
                            archive = newFi.Open(FileMode.Create);
                        }
                        catch (Exception ex)
                        {
                            if (retry < 3)
                            {
                                SoLogger.LogWarning(typeof(SoArc2), "File.Open '{1}' create failure. Retrying {0}".FormatWith(retry, filePath), ex.SimpleMessageStack());
                                System.Threading.Thread.Sleep(200 * retry);
                            }
                            else
                            {
                                SoLogger.LogError(ex);
                                throw;
                            }
                        }
                    }

                    content.WriteInChunksTo(archive);

                    content.Close();
                    archive.Flush();
                    archive.Close();

                    // files are now written and flushed to disk.
                    // time to rename and delete the old file
                    if (File.Exists(oldFilePath))
                        File.Delete(oldFilePath);
                    if (fi.Exists)
                        fi.MoveTo(oldFilePath);
                    newFi.MoveTo(filePath);
                    if (File.Exists(oldFilePath))
                        File.Delete(oldFilePath);

                    return SoArc2Helper.CreateReturnInfo(true, string.Empty, string.Empty, ReturnType.None, string.Empty, string.Empty);
                }
                catch (Exception e)
                {
                    SoLogger.LogError(e);
                    return SoArc2Helper.CreateReturnInfo(false, string.Empty, string.Empty, ReturnType.None, "Failed to save file '" + filePath + "' " + e.Message, string.Empty);
                }
                finally
                {
                    content.Dispose();
                    if (archive != null)
                    {
                        archive.Dispose();
                    }
                }

            } // using DocumentArchiveFileImpersonationContext
        }

        /// <summary>
        /// Get document content as a stream. NetServer will read-to-end and close this stream.
        /// </summary>
        /// <remarks>
        /// It is up to the document plugin whether it can open a stream directly into the underlying repository, 
        /// or whether it has to extract the document to some temporary area and then stream that � 
        /// however, the fewer buffers the better.
        /// </remarks>
        /// <param name="incomingInfo">Fully populated document metadata, used to identify the document.</param>
        /// <param name="versionId">Optional version identifier, blank implies 'latest' version</param>
        /// <returns>Document content stream</returns>
        public System.IO.Stream LoadDocumentStream(SuperOffice.CRM.IDocumentInfo incomingInfo, string versionId)
        {
            // We dont care about the versionId.             
            var checkoutData = _checkoutHelper.GetCheckoutData(incomingInfo);
            string docPath = _checkoutHelper.GetDocumentPath(incomingInfo, checkoutData, SoContext.CurrentPrincipal.AssociateId);
            bool writable = _checkoutHelper.IsWriteableForAssociate(incomingInfo, checkoutData, SoContext.CurrentPrincipal.AssociateId);

            FileStream docFileStream = null;
            using (new DocumentArchiveFileImpersonationContext())
            {
                if (!string.IsNullOrEmpty(docPath))
                {
                    try
                    {
                        docFileStream = new FileStream(docPath,
                            FileMode.Open,
                            writable ? FileAccess.ReadWrite : FileAccess.Read,
                            FileShare.ReadWrite);
                    }
                    catch (FileNotFoundException fileEx)
                    {
                        SuperOffice.Diagnostics.SoLogger.LogError(fileEx);
                        throw new SoException(string.Format("The document named '{0}', was not found in the document archive. " +
                            "Please contact your administrator to rectify the problem.", incomingInfo.Name));
                    }
                    catch (Exception e)
                    {
                        SuperOffice.Diagnostics.SoLogger.LogError(e);
                        //Do nothing. null will be returned;
                    }
                }
            }

            return (Stream)docFileStream;
        }

        /// <summary>
        /// Get a WebDAV-compliant URL referring to the given document
        /// </summary>
        /// <remarks>
        /// Document plugins may support document access via WebDAV. This call is used to retrieve a WebDAV url that 
        /// will give the specified access to the document. This URL will be passed to the ultimate client 
        /// (most probably a text editor application), and control will not return to NetServer.
        /// <para/>
        /// The string returned here should be a fully resolved URL that can be given directly to the editor application.
        /// </remarks>
        /// <param name="incomingInfo">Fully populated document metadata, used to identify the document.</param>
        /// <param name="versionId">Optional version identifier, blank implies 'latest' version</param>
        /// <param name="writeableUrl">If true, then the request URL should allow the document editor to write content
        /// back to the repository; otherwise, a url that does not support writeback should be supplied
        /// if possible.</param>
        /// <returns>"file:////fileserver/soarc/user/2013.2/file.ext"</returns>
        public string GetDocumentUrl(IDocumentInfo incomingInfo, string versionId, bool writeableUrl)
        {
            string path = _checkoutHelper.GetDocumentPath(incomingInfo, SoContext.CurrentPrincipal.AssociateId);
            Uri uri = new Uri(path);
            return uri.AbsoluteUri; // file:////fileserver/share/dir/file.ext
        }

        /// <summary>
        /// Delete a document, all versions and all metadata from the repository
        /// </summary>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo DeleteDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                _checkoutHelper.UndoCheckout(documentInfo);
                var fileName = SoArc2Helper.GetFullArchivePath(documentInfo);

                if (File.Exists(fileName))
                {
                    File.SetAttributes(fileName, File.GetAttributes(fileName) & ~FileAttributes.ReadOnly);
                    File.Delete(fileName);
                }
            }

            var returnInfo = new ReturnInfo
            {
                Success = true
            };

            return returnInfo;
        }


        /// <summary>
        /// Rename a document in the repository
        /// </summary>
        /// <remarks>
        /// The document name should be changed from the existing to the new name. However,
        /// if the new name is not valid (or collides with an existing name of some other
        /// document), then the plugin should amend the name to a valid one and return
        /// it, instead of throwing an exception.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="newFileName">Suggested new document name</param>
        /// <returns>Actual new document name, limited to 254 characters
        /// If renaming was not occured this will return an empty string</returns>
        public string RenameDocument(IDocumentInfo documentInfo, string newFileName)
        {
            // Check whether the document is not being checked out for editing.
            CheckoutInfo checkoutInfo = GetCheckoutState(documentInfo);

            var orgFileExtension = Path.GetExtension(documentInfo.Name) ?? "";
            var newFileExtension = Path.GetExtension(newFileName) ?? "";

            // We only support renaming when the extension has changed. 
            if (string.Equals(orgFileExtension, newFileExtension, StringComparison.InvariantCultureIgnoreCase))
                return documentInfo.Name;

            if (checkoutInfo.State != CheckoutState.CheckedOutOther)
            {
                // Do not require explicit lock when renaming documents in order to be nice to Mail Link and partner applications.

                var sanitizedFileName = SoArc2Helper.MakeLegalFileName(newFileName);
                string fileDirectoryPath = SoArc2Helper.GetCurrentVersionFolderPath(documentInfo);
                string suggestedFullPath = SoArc2Helper.MakeLegalFileNameAndDirectory(Path.Combine(fileDirectoryPath, sanitizedFileName));
                string uniqueName = SoArc2Helper.GetUniqueFilePath(suggestedFullPath);
                string uniqueFileName = Path.GetFileName(uniqueName);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    //Rename the root file
                    File.Move(Path.Combine(fileDirectoryPath, documentInfo.Name), uniqueName);

                    if (checkoutInfo.State == CheckoutState.CheckedOutOwn)
                    {
                        _checkoutHelper.RenameDocument(documentInfo, uniqueFileName);
                    }
                }

                // contract says we should return file-name only.                
                return uniqueFileName;
            }
            else
            {
                return string.Empty;
            }
        }


        #endregion


        #region Locking and Versioning


        /// <summary>
        /// Get the checkout state of a document
        /// </summary>
        /// <remarks>
        /// This API is called from inside document archive providers if the plugin has declared that it
        /// supports fast fetching of this attribute. If the document plugin does not support locking or
        /// versioning, then the return value should have state NotCheckedOut, associate id 0 and blank name.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <returns>Object that describes the checkout state of the document</returns>
        public CheckoutInfo GetCheckoutState(IDocumentInfo documentInfo)
        {
            var checkoutData = _checkoutHelper.GetCheckoutData(documentInfo);
            if (checkoutData == null)
                return new CheckoutInfo
                {
                    State = CheckoutState.NotCheckedOut
                };

            return new CheckoutInfo
            {
                AssociateId = checkoutData.AssociateId,
                State = checkoutData.AssociateId == SoContext.CurrentPrincipal.AssociateId
                               ? CheckoutState.CheckedOutOwn
                               : CheckoutState.CheckedOutOther,
                Name = string.IsNullOrWhiteSpace(checkoutData.CheckedOutBy) ? SoArc2Helper.GetAssociateName(checkoutData.AssociateId) : checkoutData.CheckedOutBy
            };
        }


        /// <summary>
        /// Check out the document for editing
        /// </summary>
        /// <remarks>
        /// A document plugin that supports versioning may internally prepare to receive new content and 
        /// prepare a new internal version, but a subsequent GetDocumentVersionList call should <b>not</b> 
        /// show this version � not until CheckInDocument has been called. 
        /// <para/>
        /// After the completion of this call, the document is in checked out state and <see cref="GetCheckoutState"/> 
        /// should return �Own� as the status. <see cref="PutDocumentFromStream"/> calls on behalf of other users should
        /// fail, as should <see cref="CheckoutDocument"/> and <see cref="CheckinDocument"/> calls on behalf of other users.
        /// <para/>
        /// If the document plugin does not support locking or versioning, then this call should perform no action.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo CheckoutDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {            
            _checkoutHelper.CheckoutDocument(documentInfo, SoContext.CurrentPrincipal.AssociateId);

            return new ReturnInfo
                    {
                        Success = true,
                        Type = ReturnType.None
                    };            
        }


        /// <summary>
        /// Check in a currently checked-out document
        /// </summary>
        /// <remarks>
        /// If the document plugin supports locking and the requesting user is the one who checked out the document, 
        /// then the last-saved content by that user should become the new publicly visible content, and 
        /// the checkout state should be reset. Calls by other users should result in failure and no state change.
        /// <para/>
        /// If the document plugin does not support locking or versioning, then this call should perform no action.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo CheckinDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes, string versionDescription, string[] versionExtraFields)
        {            
            _checkoutHelper.CheckinDocument(documentInfo);

            return SoArc2Helper.CreateReturnInfo(true, string.Empty, string.Empty, ReturnType.None, null,
                string.Empty);            
        }


        /// <summary>
        /// Undo (abandon) a checkout
        /// </summary>
        /// <remarks>
        /// If the document plugin supports locking and the requesting user is the one who checked out the document, 
        /// then any content saved since the checkout should be discarded and the checkout state reset. 
        /// The content will be as before checkout. 
        /// <para/>
        /// Calls by other users should result in failure and no state change � except if the calling user has the right to force an undo
        /// <para/>
        /// If the document plugin does not support locking or versioning, then this call should perform no action.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo UndoCheckoutDocument(IDocumentInfo documentInfo, string[] allowedReturnTypes)
        {            
            _checkoutHelper.UndoCheckout(documentInfo);

            return SoArc2Helper.CreateReturnInfo(true, string.Empty, string.Empty, ReturnType.None, string.Empty,
                string.Empty);            
        }


        /// <summary>
        /// Get the list of current versions for the given document
        /// </summary>
        /// <remarks>
        /// The list should not include an �in-work� version, if the document is currently checked out � only 
        /// versions visible and accessible to any authorized user.
        /// <para/>
        /// If the document plugin does not support versioning, then this call should return an empty array.
        /// </remarks>
        /// <param name="documentInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type.</param>
        /// <returns>Array of objects describing the existing, committed versions for this document</returns>
        public VersionInfo[] GetVersionList(IDocumentInfo documentInfo)
        {
            throw new InvalidOperationException();
        }

        #endregion

        #region Travel


        /// <summary>
        /// Start a Travel (offline) session. This method is called at a time when both the central and local storage
        /// systems are available, and should copy or otherwise prepare for an offline session. 
        /// </summary>
        /// <remarks>
        /// While offline, the following document archive items need to be available:
        /// <list type="bullet">
        /// <item><description>All templates, in all language variants</description></item>
        /// <item><description>All documents for the current user, in the current period</description></item>
        /// <item><description>All documents for the current user, in the previous period</description></item>
        /// </list>
        /// A period is half a year. In May this would mean the Jul-Dec + Jan-Jun. Since there may be <b>many</b> templates,
        /// caching them between travel sessions is highly recommended, almost mandatory; otherwise template/document copying
        /// may be the major time consumer when going on travel.
        /// </remarks>
        /// <param name="associateId">ID of associate who is the document owner</param>
        /// <param name="localArchiveRoot">ROot directory of local archive. This is a value that is only known to the 
        /// Travel system in the Windows client, so it has to be passed in as a parameter</param>
        /// <param name="estimate">Callback to set the expected number of items to copy, to scale the progress bar</param>
        /// <param name="step">Callback to advance the progress bar by one step</param>
        /// <returns></returns>
        public ReturnInfo GoTravel(int associateId, string localArchiveRoot, ProgressEstimateCallback estimate, ProgressStepCallback step)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                // locate all templates in so_arc, in all languages
                var templateRoot = ConfigFile.Documents.TemplatePath;
                var templateDirs = CultureDataFormatter.GetSuperOfficeLanguages().Union(new[] { "" }).
                        Select(p => Path.Combine(templateRoot, p)).
                        Where(p => Directory.Exists(p)).
                        ToArray();
                var templateFiles = templateDirs.SelectMany(p => Directory.GetFiles(p)).ToArray();

                // locate all documents in so_arc, in the associate's current and previous period; main archive path only
                // due to an ancient, uncorrectable error the first "half" is 7 months, which also means we can't just go back
                // 6 months from any date to get into the previous period... thus the rather involved calculations here!
                var initials = AssociateCache.GetCurrent().GetAssociateName(associateId);
                var documentRoot = Path.Combine(ConfigFile.Documents.ArchivePath, initials);
                int thisYear = DateTime.Today.Year;
                int thisHalf = DateTime.Today.Month <= 7 ? 1 : 2;
                int previousYear = thisHalf == 2 ? thisYear : thisYear - 1;
                int previousHalf = thisHalf == 1 ? 2 : 1;
                var thisPeriod = Path.Combine(documentRoot, string.Format("{0}.{1}", thisYear, thisHalf));
                var previousPeriod = Path.Combine(documentRoot, string.Format("{0}.{1}", previousYear, previousHalf));

                // the period directories don't actually have to exists, as opposed to the template root
                var documentFiles = new List<string>();
                if (Directory.Exists(thisPeriod))
                    documentFiles.AddRange(Directory.GetFiles(thisPeriod));
                if (Directory.Exists(previousPeriod))
                    documentFiles.AddRange(Directory.GetFiles(previousPeriod));

                // custom archives - here we have wildcard directory names
                var globalCustomArchiveDirectories = Directory.EnumerateDirectories(ConfigFile.Documents.ArchivePath, "* Custom Archives");
                var personalCustomArchiveDirectories = Directory.EnumerateDirectories(documentRoot, "* Custom Archives");
                var globalCustomArchives = globalCustomArchiveDirectories.SelectMany(d => Directory.GetFiles(d)).ToList();
                var personalCustomerArchives = personalCustomArchiveDirectories.SelectMany(d => Directory.GetFiles(d)).ToList();

                // give the global estimate, now that we know what we have
                if (estimate != null)
                    estimate(templateFiles.Length + documentFiles.Count + globalCustomArchives.Count + personalCustomerArchives.Count);

                // transform to local paths
                var localTemplateRoot = Path.Combine(localArchiveRoot, "TEMPLATE");
                var localDocumentRoot = Path.Combine(localArchiveRoot, initials);

                var localTemplateFiles = templateFiles.Select(d => d.Replace(templateRoot, localTemplateRoot)).ToArray();
                var localDocumentFiles = documentFiles.Select(d => d.Replace(documentRoot, localDocumentRoot)).ToArray();

                var localGlobalCustomArchives = globalCustomArchives.Select(d => d.Replace(ConfigFile.Documents.ArchivePath, localArchiveRoot)).ToArray();
                var localPersonalCustomArchives = personalCustomerArchives.Select(d => d.Replace(ConfigFile.Documents.ArchivePath, localArchiveRoot)).ToArray();

                // Check/create directories as needed
                var localTemplateDirectories = localTemplateFiles.Select(f => Path.GetDirectoryName(f)).Distinct();
                var localDocumentDirectories = localDocumentFiles.Select(f => Path.GetDirectoryName(f)).Distinct();
                var localGlobalCustomArchiveDirectories = localGlobalCustomArchives.Select(f => Path.GetDirectoryName(f)).Distinct();
                var localPersonalCustomArchiveDirectories = localPersonalCustomArchives.Select(f => Path.GetDirectoryName(f)).Distinct();

                foreach (var dir in localTemplateDirectories.Union(localDocumentDirectories).Union(localGlobalCustomArchiveDirectories).Union(localPersonalCustomArchiveDirectories))
                    ArchiveTempFileProvider.EnsureDirectoryExists(new DirectoryInfo(dir));

                // copy files
                var centralFiles = templateFiles.Union(documentFiles).Union(globalCustomArchives).Union(personalCustomerArchives).ToArray();
                var localFiles = localTemplateFiles.Union(localDocumentFiles).Union(localGlobalCustomArchives).Union(localPersonalCustomArchives).ToArray();

                for (int i = 0; i < centralFiles.Length; ++i)
                {
                    var central = centralFiles[i];
                    var local = localFiles[i];
                    if (!File.Exists(local) || File.GetLastWriteTimeUtc(central) > File.GetLastWriteTimeUtc(local))
                        File.Copy(central, local, overwrite: true);
                    if (step != null)
                        step();
                }

                return new ReturnInfo { Success = true };
            }
        }

        /// <summary>
        /// End a Travel (offline) session. This method is called at a time when both the central and local storage
        /// systems are available, and should update any documents whose content has been changed locally, into the central storage.
        /// Templates cannot be changed locally and should not be copied back!
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="associateId">ID of associate who is the document owner</param>
        /// <param name="centralArchiveRoot">Root directory of <b>central!</b> archive. This is a value that is only known to the 
        /// Travel system in the Windows client at this time, so it has to be passed in as a parameter (ArchivePath points to the local archive)</param>
        /// <param name="estimate">Callback to set the expected number of items to copy, to scale the progress bar</param>
        /// <param name="step">Callback to advance the progress bar by one step</param>
        /// <returns></returns>
        public ReturnInfo HomeComing(int associateId, string centralArchiveRoot, ProgressEstimateCallback estimate, ProgressStepCallback step)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {
                // locate all documents in local archive - irrespective of periods, since we may have been gone for a while and crossed into new period(s)
                var initials = AssociateCache.GetCurrent().GetAssociateName(associateId);

                var localArchiveRoot = ConfigFile.Documents.ArchivePath;    // yes, really: at this point we're seeing the Local archive
                                                                            // ... but only "see" directories that have the year.period name structure; DON'T take Travel, Scripts and other possible junk
                var localDirs = Directory.GetDirectories(Path.Combine(localArchiveRoot, initials)).
                    Where(d =>
                    {
                        var lastParts = Path.GetFileName(d).Split('.');
                        int year, half;
                        return lastParts.Length == 2 && lastParts[0].Length == 4 && lastParts[1].Length == 1 &&
                            int.TryParse(lastParts[0], out year) && int.TryParse(lastParts[1], out half) &&
                            (half == 1 || half == 2);
                    }).ToArray();

                var localFiles = localDirs.SelectMany(d => Directory.GetFiles(d)).ToArray();

                // also bring home any changed Custom Archive settings, but only personal ones
                var localCustomArchiveDirectories = Directory.EnumerateDirectories(Path.Combine(localArchiveRoot, initials), "* Custom Archives").ToList();
                var localCustomArchives = localCustomArchiveDirectories.SelectMany(d => Directory.EnumerateFiles(d)).ToList();

                foreach (var centralDir in localDirs.Union(localCustomArchiveDirectories).Select(d => d.Replace(localArchiveRoot, centralArchiveRoot)))
                    ArchiveTempFileProvider.EnsureDirectoryExists(new DirectoryInfo(centralDir));

                if (estimate != null)
                    estimate(localFiles.Length + localCustomArchives.Count);

                foreach (var localFile in localFiles.Union(localCustomArchives))
                {
                    var centralFile = localFile.Replace(localArchiveRoot, centralArchiveRoot);
                    if (!File.Exists(centralFile) || File.GetLastWriteTimeUtc(localFile) > File.GetLastWriteTimeUtc(centralFile))
                        File.Copy(localFile, centralFile, overwrite: true);
                    if (step != null)
                        step();
                }

                return new ReturnInfo { Success = true };
            }
        }


        #endregion

        /// <summary>
        /// Create a default document based on the given documentType. Called when creating a new template.
        /// </summary>
        /// <param name="documentTypeKey">Id for a document type. NULL or blank if no types are supported.</param>
        /// <param name="documentTemplateInfo">Document template info</param>
        /// <returns>Extref/Filename for new template. This value is written to the template's Filename property.
        /// Return NULL if no change, or if no document created.</returns>
        public TemplateInfo CreateDefaultDocumentTemplate(int documentTypeKey, IDocumentTemplateInfo documentTemplateInfo)
        {
            // we must initialize a file here, because this place is the only place we 
            // KNOW that we must conduct a duplicate-check!
            var noData = new byte[0];
            var noDataStream = new MemoryStream(noData);
            const string noLanguage = null;
            return SaveDocumentTemplateStream(documentTemplateInfo, noDataStream, noLanguage, runDuplicateCheck: true);
        }

        /// <summary>
        /// Get a list of supported document template types. 
        /// </summary>
        /// <returns>An dictionary of key=display-name for supported document types for template. Empty dictionary if no document types supported.</returns>
        public Dictionary<int, string> GetSupportedDocumentTypesForDocumentTemplates()
        {
            // SoArc does not support document types - return empty dictionary
            return new Dictionary<int, string>();
        }


        /// <summary>
        /// Get the values of certain properties, for a given document template
        /// </summary>
        /// <remarks>
        /// Each document can have a number of properties associated with it. A set of standard properties
        /// is defined in the <see cref="SuperOffice.CRM.Documents.Constants.Properties"/> class. Ideally, retrieving properties should
        /// be a lightweight operation.
        /// <para/>
        /// Note that 'properties' are a one-way mechanism where the document plugin provides information about
        /// the document or certain aspects of it. This is not the same as document-specific
        /// metadata, which is handled by the <see cref="LoadMetaData"/> and <see cref="SaveMetaData"/>
        /// methods.
        /// </remarks>        
        /// <param name="documentTemplateInfo">Document template record from the SuperOffice database</param>
        /// <param name="requestedProperties">Array of property strings, for which values are requested</param>
        /// <returns>Dictionary of name=value pairs, where the name is one of the requested property strings, and the value
        /// is the value of that property for the given document.</returns>
        public Dictionary<string, string> GetDocumentTemplateProperties(IDocumentTemplateInfo templateInfo, string[] requestedProperties)
        {
            var result = new Dictionary<string, string>(requestedProperties.Length);
            foreach (string prop in requestedProperties)
            {
                switch (prop)
                {
                    case Constants.Properties.PreferredOpen:
                        result[prop] = Constants.Values.Stream;
                        break;

                    case Constants.Properties.FileName:
                        result[prop] = templateInfo.ExternalReference;
                        break;

                    default:
                        result[prop] = null;
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// Get a URL referring to the given document template:  "file:////fileserver/soarc/template/file.ext"
        /// </summary>
        /// <remarks>
        /// Document plugins may support document access via URLs. This call is used to retrieve a url that 
        /// will give the specified access to the document. This URL will be passed to the ultimate client 
        /// (most probably a browser, but could be a text editor application), and control will not return to NetServer.
        /// <para/>
        /// The string returned here should be a fully resolved URL that can be given directly to the editor application.
        /// </remarks>
        /// <param name="documentTemplateInfo">The document template info from database</param>        
        /// <param name="writeableUrl">If true, then the request URL should allow the document editor to write content
        /// back to the repository; otherwise, a url that does not support writeback should be supplied
        /// if possible.</param>
        /// <param name="languageCode">Language variation on the template. May be ignored by the plugin, or used to keep language specific versions of the template.</param>
        /// <returns>URL that gives access to the template: "file:////fileserver/soarc/template/file.ext"</returns>
        public string GetDocumentTemplateUrl(IDocumentTemplateInfo documentTemplateInfo, bool writeableUrl, string languageCode)
        {
            string path = SoArc2Helper.GetDocumentTemplatePath(documentTemplateInfo, languageCode);
            Uri uri = new Uri(path);
            return uri.AbsoluteUri; // file:////fileserver/share/dir/file.ext
        }


        /// <summary>
        /// Get the list of languages supported by the given template, not including the default (blank) language.
        /// </summary>
        /// <remarks>Used when populating the dropdown list in the admin client or the document dialog.</remarks>
        /// <param name="documentTemplateInfo">The template we are curious about</param>
        /// <returns>Array of ISO codes: ("en-US", "nb-NO", "fr")</returns>
        public string[] GetDocumentTemplateLanguages(IDocumentTemplateInfo documentTemplateInfo)
        {
            using (new DocumentArchiveFileImpersonationContext())
            {

                var fileName = documentTemplateInfo.ExternalReference;

                string[] files;
                try
                {
                    files = Directory.GetFiles(ConfigFile.Documents.TemplatePath, fileName, SearchOption.AllDirectories);
                }
                catch (Exception ex)
                {
                    SoLogger.LogWarning(ex);

                    files = new string[0];
                }

                var soLangRegex =
                    new Regex(Regex.Escape(ConfigFile.Documents.TemplatePath) + @"\\(\w\w)\\" +
                              Regex.Escape(fileName));

                var result = from f in files
                             let m = soLangRegex.Match(f)
                             let name = CultureDataFormatter.MapSuperOfficeLanguageToCulture(m.Groups[1].Value)
                             where m.Success
                             select name;

                return result.ToArray();
            }
        }

        /// <summary>
        /// Delete a document template, all language variations and all metadata from the repository
        /// </summary>
        /// <param name="documentTemplateInfo">Fully populated document metadata, used to identify the document. Usefully contains ExternalReference and Filename properties.</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types; if this array is
        /// empty then no limits are placed on return type. ("None", "Message", "SoProtocol", "CustomGUI", "Other")</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo DeleteDocumentTemplate(IDocumentTemplateInfo documentTemplateInfo, string[] allowedReturnTypes)
        {
            string path = SoArc2Helper.GetDocumentTemplatePath(documentTemplateInfo, "");
            if (File.Exists(path))
            {
                var languages = GetDocumentTemplateLanguages(documentTemplateInfo);

                foreach (var lang in languages)
                    DeleteDocumentTemplateLanguage(documentTemplateInfo, lang, new string[0]);

                using (new DocumentArchiveFileImpersonationContext())
                {
                    File.Delete(path);
                }
            }
            else
                path = "";

            return new ReturnInfo() { Success = true, ExternalReference = path };
        }

        /// <summary>
        /// Map file path to a document id.
        /// </summary>
        /// <param name="documentPathAndName">"C:\SO_ARC\USER\2014.1\foobar.docx"</param>
        /// <returns>123</returns>
        public int GetDocumentIdFromPath(string documentPathAndName)
        {
            if (string.IsNullOrEmpty(documentPathAndName))
                return 0;

            var paths = SoArc2Helper.GetArchivePaths();  // "c:\so_arc", "d:\soarc2"
            foreach (string path in paths)
            {
                if (documentPathAndName.StartsWith(path, StringComparison.InvariantCultureIgnoreCase))
                {
                    string remainder = documentPathAndName.Substring(path.Length + 1); // "USER\2014.1\foobar.docx"
                    string[] parts = remainder.Split('\\');
                    if (parts.Length == 3)
                    {
                        string user = parts[0]; // "USER"
                        string date = parts[1]; // "2014.1"
                        string file = parts[2]; // "foobar.docx"

                        int associd = SuperOffice.CRM.Cache.AssociateCache.GetCurrent().GetAssociateId(user);

                        DateTime fromDate = DateTime.MinValue;
                        DateTime toDate = DateTime.MinValue;
                        string[] dateParts = date.Split('.');
                        if (dateParts.Length == 2)
                        {
                            int year = 0;
                            int part = 0;
                            int.TryParse(dateParts[0], out year);
                            int.TryParse(dateParts[1], out part);

                            if (part == 1)
                            {
                                fromDate = new DateTime(year, 1, 1);
                                toDate = new DateTime(year, 8, 1);
                            }
                            if (part == 2)
                            {
                                fromDate = new DateTime(year, 8, 1);
                                toDate = new DateTime(year + 1, 1, 1);
                            }

                            var query = new DocumentRow.CustomSearch();
                            var doc = query.TableInfo;
                            query.Restriction = doc.RegisteredAssociateId.Equal(associd)
                                .And(doc.Registered.Between(fromDate, toDate))
                                .And(doc.Name.Equal(file));
                            DocumentRow theDoc = DocumentRow.GetFromCustomSearch(query);
                            if (!theDoc.IsNew && theDoc.DocumentId > 0)
                                return theDoc.DocumentId;
                        }

                    }
                }
            }
            return 0;
        }

        /// <summary>
        /// Delete a specific language variation from the document template
        /// </summary>
        /// <param name="documentTemplateInfo">Fully populated document template metadata used to identity the template.</param>
        /// <param name="languageCode">The language variation to delete</param>
        /// <param name="allowedReturnTypes">Array of names of allowed return types.</param>
        /// <returns>Return value, indicating success/failure and any optional processing to be performed</returns>
        public ReturnInfo DeleteDocumentTemplateLanguage(IDocumentTemplateInfo documentTemplateInfo, string languageCode,
                                                  string[] allowedReturnTypes)

        {
            var invalidFileNameChars = Path.GetInvalidFileNameChars();
            languageCode = invalidFileNameChars.Aggregate(languageCode, (current, ic) => current.Replace(ic, '_'));

            using (new DocumentArchiveFileImpersonationContext())
            {
                string path = SoArc2Helper.GetDocumentTemplatePath(documentTemplateInfo, languageCode);
                bool success = false;

                try
                {
                    File.Delete(path);
                    success = true;
                }
                catch (Exception ex)
                {
                    SoLogger.LogWarning(ex);
                }

                return new ReturnInfo
                {
                    Success = success
                };
            }
        }


        public bool IsNameValid(string name)
        {
            try
            {
                //Reserved folder names.
                //NOTE: I don't like this solution. So_arc should NOT be the place to put log files and data files that has nothing to do with 
                //documents. JTM
                if (name.ToLowerInvariant().StartsWith("temp")
                    || name.ToLowerInvariant().Equals("log")
                    || name.ToLowerInvariant().Equals("data")
                    || name.ToLowerInvariant().StartsWith("backup")
                    || name.ToLowerInvariant().Equals("_cs")
                    || name.ToLowerInvariant().StartsWith("dbupgrade")
                    )
                    return true;

                using (new DocumentArchiveFileImpersonationContext())
                {
                    string path = Path.Combine(SoArc2Helper.GetArchivePath(), name);
                    return Directory.Exists(path);
                }
            }
            catch (Exception ex)
            {
                SoLogger.LogError(ex);
                throw new SoException("Error occurred at checking the associate so_arc path", ex, "Unable to move so_arc location for user.");
            }
        }
    }

}
