using SuperOffice.Configuration;
using SuperOffice.CRM.Data;
using SuperOffice.CRM.Globalization;
using SuperOffice.CRM.Rows;
using SuperOffice.Data;
using SuperOffice.Data.Dictionary;
using SuperOffice.Security.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace SuperOffice.CRM.Documents
{
	#region "Utility & Helper methods"

	/// <summary>
	/// Helper class containing utility methods (e.g to retrieve data from ForeignKey Table)
	/// </summary>
	public static class SoArc2Helper
	{			
		/// <summary>
		/// Path to the main document archive.
		/// </summary>
		/// <returns>"\\server\so_arc"</returns>
		public static string GetArchivePath()
		{
			return ConfigFile.Documents.ArchivePath;
		}

		/// <summary>
		/// Path to the document archives, including the main document archive.
		/// </summary>
		/// <returns>("\\server\so_arc", "\\other\so_arc2")</returns>
		public static string[] GetArchivePaths()
		{
			var paths = new List<string> { GetArchivePath() };
			Action<string> addIfSet = p => { if (!string.IsNullOrWhiteSpace(p)) paths.Add(p); };

			addIfSet(ConfigFile.Documents.ArchivePath1);
			addIfSet(ConfigFile.Documents.ArchivePath2);
			addIfSet(ConfigFile.Documents.ArchivePath3);
			addIfSet(ConfigFile.Documents.ArchivePath4);
			addIfSet(ConfigFile.Documents.ArchivePath5);
			addIfSet(ConfigFile.Documents.ArchivePath6);
			addIfSet(ConfigFile.Documents.ArchivePath7);
			addIfSet(ConfigFile.Documents.ArchivePath8);
			addIfSet(ConfigFile.Documents.ArchivePath9);
			addIfSet(ConfigFile.Documents.ArchivePath10);

			return paths.ToArray();
		}

		/// <summary>
		/// This method will return the physical location of the given document based on the provided IDocumentInfo.
		/// </summary>
		/// <param name="documentInfo">DocumentInfo object containing the document information </param>		
		/// <returns>Full Archive Path</returns>
		public static string GetFullArchivePath(IDocumentInfo documentInfo)
		{
			string archivePath; // this is the path of the document identified by the above documentId and versionId
			string currentDocumentFolder;
			// this is the folder name of the current version of the document identified by documentId 

			currentDocumentFolder = GetCurrentVersionFolderPath(documentInfo);
			var sanitizedFileName = MakeLegalFileName(documentInfo.Name);
        	archivePath = Path.Combine(currentDocumentFolder, sanitizedFileName);
			
			
			// normalize the filename and wash out any illegal stuff
			archivePath = new FileInfo(MakeLegalFileNameAndDirectory(archivePath)).FullName;
			return archivePath;
		}

		/// <summary>
		/// This method will return the physical location of the given document based on the provided IDocumentInfo.
		/// </summary>
		/// <param name="documentRow">DocumentRow object containing the document information </param>
		/// <param name="versionId"></param>
		/// <returns>Full Archive Path</returns>
		public static string GetFullArchivePath(DocumentRow documentRow)
		{
			string archivePath; // this is the path of the document identified by the above documentId and versionId
			string currentDocumentFolder;
			// this is the folder name of the current version of the document identified by documentId 

			currentDocumentFolder = GetCurrentVersionFolderPath(documentRow);
    		archivePath = Path.Combine(currentDocumentFolder, documentRow.Name);

            using (new DocumentArchiveFileImpersonationContext())
			{
				// normalize the filename
				archivePath = new FileInfo(archivePath).FullName;
			}

            return archivePath;
		}

		/// <summary>
		/// Verify that a directory exists, and if not, create all missing folders
		/// </summary>
		/// <param name="dirInfo"></param>
		public static void EnsureDirectoryExists(System.IO.DirectoryInfo dirInfo)
		{
			using (new DocumentArchiveFileImpersonationContext())
			{
				ArchiveTempFileProvider.EnsureDirectoryExists(dirInfo);
			}
		}


		/// <summary>
		/// This will get a unique file name in the given path.
		/// </summary>
		/// <remarks>
		/// this will ensure to return an unique file name for the given location If it finds a file(s)
		/// with the same name it will create a filename with a suffix with a proper index.
		/// e.g It'll create Test[2].docx (if it finds the Test.docx &amp; Test[1].docx in the requested location
		/// </remarks>
		/// <param name="completeFilePath">Complete file path including the file name</param>
		/// <returns>A string to a unique filename with no path which is guaranteed not to exist in the path provided.</returns>
		public static string GetUniqueFileName(string completeFilePath)
		{
			string uniquePath = GetUniqueFilePath(completeFilePath);
			string uniqueName = Path.GetFileName(uniquePath);
			return uniqueName;
		}

		/// <summary>
		/// This will get a unique file name and path in the given path.
		/// </summary>
		/// <remarks>
		/// this will ensure to return an unique file name for the given location If it finds a file(s)
		/// with the same name it will create a filename with a suffix with a proper index.
		/// e.g It'll create Test[2].docx (if it finds the Test.docx &amp; Test[1].docx in the requested location
		/// </remarks>
		/// <param name="completeFilePath">Complete file path including the file name</param>
		/// <returns>A string to a complete filename and path which is guaranteed not to exist.</returns>
		public static string GetUniqueFilePath(string completeFilePath)
		{
			int ifile = 1;
			string uniqueName = string.Empty;

			string fileNameTemplate = Path.GetFileNameWithoutExtension(completeFilePath) + "[{0}]" +
									  Path.GetExtension(completeFilePath);
			string directoryPath = Path.GetDirectoryName(completeFilePath);

			string filename = Path.GetFileName(completeFilePath);

			using (new DocumentArchiveFileImpersonationContext())
			{
				while (string.IsNullOrEmpty(uniqueName))
				{
					if (File.Exists(Path.Combine(directoryPath, filename)))
					{
						if (ifile > 0)
						{
							filename = string.Format(fileNameTemplate, ifile);
							ifile++;
						}
					}
					else
					{
						filename = Path.Combine(directoryPath, filename);
						break;
					}

				}
			}
			return filename;
		}

		/// <summary>
		/// Sanitize a file name (no path); this removes backslash and other dangerous characters
		/// </summary>
		/// <param name="fileNameWithoutPath"></param>
		/// <returns></returns>
		public static string MakeLegalFileName(string fileNameWithoutPath)
		{
			char[] invalidChars = Path.GetInvalidFileNameChars();
			string invalidString = Regex.Escape(new string(invalidChars));
			var fileName = Regex.Replace(fileNameWithoutPath, "[" + invalidString + "]", string.Empty);
			return fileName;
		}

		/// <summary>
		/// Given a suggested file name (typically derived from a document.header), and make it legal;
		/// create directories on the way
		/// </summary>
		/// <remarks>
		/// This is in fact rather complicated. There can be a volume designator, such as q: or \\?\q: at the
		/// beginning of a path - colon is legal there, as is the question mark, but only in these very special
		/// places. Elsewhere the illegal-characters set applies. And we also want to guard against upwards navigation
		/// using \..\ syntax.
		/// </remarks>
		/// <param name="suggestedFullPathWithExtension"></param>
		/// <returns></returns>
		public static string MakeLegalFileNameAndDirectory(string suggestedFullPathWithExtension, bool skipExistenceCheck = false)
		{
			char[] invalidChars = Path.GetInvalidFileNameChars();
			string invalidString = "[" + Regex.Escape(new string(invalidChars)) + "]";
			string invalidStringWithoutColon = "[" + Regex.Escape(new string(invalidChars.Where(c => c != ':').ToArray())) + "]";
			string invalidStringWithoutQuestion = "[" + Regex.Escape(new string(invalidChars.Where(c => c != '?').ToArray())) + "]";

			var parts = suggestedFullPathWithExtension.Split('\\');
			var colonAllowedInPart = -1;
			var questionAllowedInPart = -1;

			// c:\ is legal, c:\a:\abc is not
			if (parts[0].Length == 2 && parts[0][1] == ':')
				colonAllowedInPart = 0;

			// \\?\c:\abc is legal!
			if (parts.Length > 4 && parts[3].Length == 2 && parts[3][1] == ':')
				colonAllowedInPart = 3;
			if (parts.Length > 3 && parts[2].Length == 1 && parts[2][0] == '?')
				questionAllowedInPart = 2;

			// pick apart, wash, put back together again
			var legalisedParts = new string[parts.Length];
			for (int i = 0; i < parts.Length; ++i)
				if (i == colonAllowedInPart)
					legalisedParts[i] = Regex.Replace(parts[i], invalidStringWithoutColon, "");
				else if (i == questionAllowedInPart)
					legalisedParts[i] = Regex.Replace(parts[i], invalidStringWithoutQuestion, "");
				else
					legalisedParts[i] = Regex.Replace(parts[i], invalidString, "");

			// people might try to navigate upwards by introducing .. folders; we don't like that
			bool anyDoubleDots = false;
			do
			{
				anyDoubleDots = false;
				for (int i = 0; i < parts.Length; ++i)
					if (legalisedParts[i] == "..")
					{
						legalisedParts[i] = "|||skipme|||";
						anyDoubleDots = true;
					}
			} while (anyDoubleDots);

			// extract the (now legal) directory
			var retVal = string.Join("\\", legalisedParts.Where(p => p != "|||skipme|||"));
			var fileDirectoryPath = Path.GetDirectoryName(retVal);

			// Check whether the expected file directory is existed, if not create.
			if (!skipExistenceCheck)
				EnsureDirectoryExists(new DirectoryInfo(fileDirectoryPath));

			return retVal;
		}

		/// <summary>
		/// Get the associate name for a given associate id
		/// </summary>
		/// <param name="associateId">Associate Id</param>
		/// <returns>Associate Name</returns>
		public static string GetAssociateName(int associateId)
		{
			AssociateTableInfo associate = TablesInfo.GetAssociateTableInfo();

			PersonRows.CustomSearch searchSql = new PersonRows.CustomSearch();
			searchSql.JoinRestriction.InnerJoin(associate.PersonId.Equal(searchSql.TableInfo.PersonId));
			searchSql.Restriction = associate.AssociateId.Equal(S.Parameter(associateId));
			PersonRow row = searchSql.ToPersonRow();
			return row.Firstname + " " + row.Lastname;
		}

		/// <summary>
		/// Create a ReturnInfo object
		/// </summary>
		/// <param name="success">success/failure status</param>
		/// <param name="externalReference">External Reference</param>
		/// <param name="versionId">Version Id</param>
		/// <param name="type">Return type</param>
		/// <param name="value">Return value</param>
		/// <param name="additionalInfo">Additional Info</param>
		/// <returns>ReturnInfo</returns>
		public static ReturnInfo CreateReturnInfo(bool success, string externalReference, string versionId,
										   ReturnType type, string value, string additionalInfo)
		{
			ReturnInfo returnInfo = new ReturnInfo();
			returnInfo.Success = success;
			returnInfo.ExternalReference = externalReference;
			returnInfo.VersionId = versionId;
			returnInfo.Type = type;
			returnInfo.Value = value;
			returnInfo.AdditionalInfo = additionalInfo;
			return returnInfo;
		}
			       	
		/// <summary>
		/// This is the folder path where the latest document is in 
		/// </summary>
		/// <param name="documentInfo">document id/name/heading</param>
		/// <returns>\\server\so_arc\user\1999.1</returns>
		public static string GetCurrentVersionFolderPath(IDocumentInfo documentInfo)
		{
			string currentDocumentFolder = "";

			string subFolder = documentInfo.Registered.Year.ToString();
			if (documentInfo.Registered.Month <= 7)
				subFolder += ".1";
			else
				subFolder += ".2";

			// impersonate since we are checking if document exists - have to make the name legal as well to prevent errors and hack attempts
			using (new DocumentArchiveFileImpersonationContext())
			{
				foreach (string archivePath in GetArchivePaths())
				{
					currentDocumentFolder = archivePath;
					currentDocumentFolder = Path.Combine(currentDocumentFolder, documentInfo.AssociateLoginName);
					currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);
					string docPath = Path.Combine(currentDocumentFolder, MakeLegalFileName(documentInfo.Name));
					if (File.Exists(docPath))
						return currentDocumentFolder;
				}
			}

			// if no paths match, then create new files in the main SOARC folder
			currentDocumentFolder = GetArchivePath();
			currentDocumentFolder = Path.Combine(currentDocumentFolder, documentInfo.AssociateLoginName);
			currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);

			return currentDocumentFolder;
		}

		/// <summary>
		/// This is the folder path where the latest document is located.
		/// </summary>
		/// <param name="documentRow">document id, name, heading etc</param>
		/// <returns>\\server\so_arc\user\1999.2</returns>
		public static string GetCurrentVersionFolderPath(DocumentRow documentRow)
		{
			AssociateRow associateRow = AssociateRow.GetFromIdxAssociateId(documentRow.RegisteredAssociateId);

			string currentDocumentFolder = "";

			string subFolder = documentRow.Registered.Year.ToString();
			if (documentRow.Registered.Month <= 7)
				subFolder += ".1";
			else
				subFolder += ".2";

			// impersonate since we are checking if document exists
			using (new DocumentArchiveFileImpersonationContext())
			{
				foreach (string archivePath in GetArchivePaths())
				{
					currentDocumentFolder = archivePath;
					currentDocumentFolder = Path.Combine(currentDocumentFolder, associateRow.Name);
					currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);
					string docPath = Path.Combine(currentDocumentFolder, documentRow.Name);
					if (File.Exists(docPath))
						return currentDocumentFolder;
				}
			}
			// if no paths match, then create new files in the main SOARC folder
			currentDocumentFolder = GetArchivePath();
			currentDocumentFolder = Path.Combine(currentDocumentFolder, associateRow.Name);
			currentDocumentFolder = Path.Combine(currentDocumentFolder, subFolder);

			return currentDocumentFolder;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="documentTemplateId"></param>
		/// <param name="languageCode"></param>
		/// <returns></returns>
		internal static string GetDocumentTemplatePath(IDocumentTemplateInfo templateInfo, string languageCode, bool checkIfFileExists = true,
												bool runDuplicateCheck = false)
		{
			// validate input.
			if (templateInfo == null)
			{
#if DEBUG
				// in all known good cases this should not happen.
				// let developers know something's up.
				throw new ArgumentNullException();
#endif
				return null;
			}

			string templateName = templateInfo.ExternalReference;
			string soLang = CultureDataFormatter.MapCultureToSuperOfficeLanguage(languageCode);

			// handle language-documents specificly
			if (!string.IsNullOrEmpty(languageCode) && !string.IsNullOrEmpty(soLang))
			{
				var result = Path.Combine(ConfigFile.Documents.TemplatePath, soLang, templateName);
				return result;
			}

			var templatePath = Path.Combine(ConfigFile.Documents.TemplatePath, templateName);

			// handle new documents specificaly. avoid duplicates.
			if (runDuplicateCheck)
			{
				var result = GetUniqueFilePath(templatePath);
				return result;
			}

			// in all other cases we should ASSERT that the file exists

			if (checkIfFileExists && !File.Exists(templatePath))
			{
#if DEBUG
				// in all known good cases this should not happen.
				// let developers know something's up.
				throw new FileNotFoundException(templatePath);
#endif
				// keep previous behaviour in production. don't change it, as we don't
				// know if any code anywhere relies on it for things we do not know.
				return null;
			}

			return templatePath;
		}   

        #endregion
    }
}
