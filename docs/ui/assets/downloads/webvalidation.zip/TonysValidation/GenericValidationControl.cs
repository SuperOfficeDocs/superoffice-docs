﻿using SuperOffice.DCF.Web.Factory;
using SuperOffice.DCF.Web.UI.Controls;
using System;

namespace SuperOffice.DevNet.Validation
{
    [SuperOffice.DCF.Web.Factory.SoWebObject("ValidationControl")]
    public class ValidationControl : ControlBase, IWebObject
    {
        private bool validated = false;
        protected override void OnLoad(EventArgs e)
        {
            Page.PreRender += new EventHandler(Page_PreRender);
        }

        void Page_PreRender(object sender, EventArgs e)
        {
            if (validated && !IsValid)
            {
                Page.ClientScript.RegisterStartupScript(
                    this.GetType(), 
                    "Validation", 
                    string.Format("Dialog.Information('Validation', '{0}', 'Error');", Tooltip), true);
            }
        }

        public override bool IsValid
        {
            get
            {
                validated = true;
                return base.IsValid;
            }
        }
    }
}