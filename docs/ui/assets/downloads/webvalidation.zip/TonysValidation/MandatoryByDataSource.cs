﻿using SuperOffice.Data;
using SuperOffice.DCF.Web;
using SuperOffice.DCF.Web.Factory;
using SuperOffice.DCF.Web.UI.Validations;
using System.Collections.Generic;
using System.Xml;

namespace SuperOffice.DevNet.Validation
{
    [SuperOffice.DCF.Web.Factory.SoWebObject("MandatoryFieldValidator")]
    public class MandatoryFieldValidator : ValidationBase, IWebObject
    {
        public MandatoryFieldValidator()
        {
            Fields = new Dictionary<string, string>();
        }

        public Dictionary<string, string> Fields { get; set; }


        public override void Initialize(XmlNode config)
        {
            base.Initialize(config);

            XmlNodeList fields = config.SelectNodes("datasource");

            foreach (XmlNode field in fields)
            {
                Fields.Add(field.Attributes["friendlyname"].InnerText, field.InnerText);
            }

        }
        protected override bool _validate(object value, out string validationMessage)
        {
            validationMessage = "";

            List<object> fieldValues = new List<object>();

            DataDispatcher dd = DataDispatcherManager.GetDataDispatcher();
            object dataObject = null;
            var fieldValue = string.Empty;


            foreach (var field in Fields)
            {
                dataObject = null;
                dd.TryGetDataObjectData(field.Value, out dataObject);

                fieldValue = dataObject == null ? string.Empty : dataObject.ToString();

                if (string.IsNullOrWhiteSpace(fieldValue))
                {
                    validationMessage = "The field {0} must not be null or empty!".FormatWith(field.Key);
                    return false;
                }
            }

            return true;
        }
    }
}