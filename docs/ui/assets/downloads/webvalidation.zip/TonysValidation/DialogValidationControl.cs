﻿using SuperOffice.DCF.Web.Factory;
using SuperOffice.DCF.Web.UI.Controls;
using SuperOffice.Util;
using System;
using System.Xml;

namespace Validation
{

    //EXAMPLE USAGE
    /******************************************************************************************
    <control id="ValidateReasonStalled" type="DialogValidationControl">
      <datasource>EntityDataHandler.SaleEntity.ReasonStalled.Id</datasource>
      <validations>
            <validation type="GenericFieldValidator">
                <config>
                    <currentvalue>0</currentvalue>
                    <if-true field="EntityDataHandler.SaleStatus">3</if-true>
                    <if-true field="EntityDataHandler.SaleEntity.Rating.Value">Lost</if-true>
                    <validationmessage>Please supply reason for Lost.</validationmessage>
                </config>
            </validation>
        </validations>
        <config>
            <type>YesNo</type>
            <title>Create FollowUp?<title>
            <message>Because the sale is stalled, do you want to create a follow up?<message>
            <callback>createNewAppointmentCallback<callback>
        </config>
    </control>

    <control id="CreateNewAppointmentCallbackScript" type="SoScriptControl">
        <config>
            <switch value="1" binding="none">
                <case operator="equal" value="1">
                    <![CDATA[
                       function createNewAppointmentCallback(result) {
                           // Check the result value...
                           alert(result);

                       }

                    ]]>
                </case>
            </switch>
        </config>
    </control>
    ******************************************************************************************/
    [SuperOffice.DCF.Web.Factory.SoWebObject("DialogValidationControl")]
    public class DialogValidationControl : ControlBase, IWebObject
    {
        private bool validated = false;

        /// <summary>
        /// Supported Types: Information, YesNo, YesNoCancel, OkCancel
        /// </summary>
        public string DialogType { get; set; }
        public string DialogTitle { get; set; }
        public string DialogMessage { get; set; }
        public string DialogCallback { get; set; }


        public override void Initialize(XmlNode config, string id)
        {
            base.Initialize(config, id);

            DialogType = XmlUtil.GetNodeText(config.SelectSingleNode("type"), string.Empty);
            DialogTitle = XmlUtil.GetNodeText(config.SelectSingleNode("title"), string.Empty);
            DialogMessage = XmlUtil.GetNodeText(config.SelectSingleNode("message"), string.Empty);
            DialogCallback = XmlUtil.GetNodeText(config.SelectSingleNode("callback"), string.Empty);
        }

        protected override void OnLoad(EventArgs e)
        {
            Page.PreRender += new EventHandler(Page_PreRender);
        }

        void Page_PreRender(object sender, EventArgs e)
        {
            if (validated && !IsValid)
            {
                //Default type is case "Information":
                var defaultDialog = string.Format("Dialog.Information('{0}', '{1}', 'Information');", DialogTitle, DialogMessage);

                switch (DialogType)
                {
                    case "YesNo":
                        defaultDialog = string.Format("Dialog.YesNo('{0}', '{1}', 'question', '', {2}, '');", DialogTitle, DialogMessage, DialogCallback);
                        break;
                    case "YesNoCancel":
                        defaultDialog = string.Format("Dialog.YesNoCancel('{0}', '{1}', 'question', '', {2}, '');", DialogTitle, DialogMessage, DialogCallback);
                        break;
                    case "OkCancel":
                        defaultDialog = string.Format("Dialog.OneButtonWithCancelDialog('{0}', '{1}', 'none', {2});", DialogTitle, DialogMessage, DialogCallback);
                        break;
                    default:
                        break;
                }


                Page.ClientScript.RegisterStartupScript(this.GetType(), "DialogValidation", defaultDialog, true);
            }
        }

        public override bool IsValid
        {
            get
            {
                validated = true;
                return base.IsValid;
            }
        }
    }
}