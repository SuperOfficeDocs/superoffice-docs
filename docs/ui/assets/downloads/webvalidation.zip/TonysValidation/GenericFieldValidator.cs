﻿using SuperOffice.Data;
using SuperOffice.DCF.Web;
using SuperOffice.DCF.Web.Factory;
using SuperOffice.DCF.Web.UI;
using SuperOffice.DCF.Web.UI.Validations;
using SuperOffice.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace TonysValidation
{
    [SuperOffice.DCF.Web.Factory.SoWebObject("GenericFieldValidator")]
    public class GenericFieldValidator : ValidationBase, IWebObject
    {
        public GenericFieldValidator()
        {
            Fields = new Dictionary<string, string>();
        }

        public Dictionary<string, string> Fields { get; set; }

        public string Message { get; set; }

        public string CurrentValue { get; set; }


        public override void Initialize(XmlNode config)
        {
            base.Initialize(config);

            XmlNodeList fields = config.SelectNodes("if-true");

            foreach (XmlNode field in fields)
            {
                Fields.Add(field.Attributes["field"].InnerText, field.InnerText);
            }

            CurrentValue = XmlUtil.GetNodeText(config.SelectSingleNode("currentvalue"), string.Empty);
            Message = XmlUtil.GetNodeText(config.SelectSingleNode("validationmessage"), string.Empty);
        }
        protected override bool _validate(object value, out string validationMessage)
        {
            validationMessage = "";

            var validateValue = value == null ? "" : value.ToString();

            List<object> fieldValues = new List<object>();
            DataDispatcher dd = DataDispatcherManager.GetDataDispatcher();
            object obj = null;
            var fieldValue = string.Empty;

            if(validateValue.Equals(CurrentValue, StringComparison.InvariantCultureIgnoreCase))
            {
                foreach (var field in Fields)
                {
                    obj = null;
                    dd.TryGetDataObjectData(field.Key, out obj);

                    fieldValue = obj == null ? string.Empty : obj.ToString();

                    if (field.Value.Equals(fieldValue, StringComparison.InvariantCultureIgnoreCase))
                    {
                        validationMessage = Message;
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
